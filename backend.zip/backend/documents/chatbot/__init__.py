# documents/chatbot/__init__.py
"""
Chatbot bo'limlari
"""

import importlib
import os

CHATBOT_BOLIMLARI = {}

# Barcha .py fayllarni import qilish
for file in os.listdir(os.path.dirname(__file__)):
    if file.endswith('.py') and not file.startswith('__'):
        module_name = file[:-3]  # .py olib tashlash
        try:
            module = importlib.import_module(f'.{module_name}', package=__name__)
            if hasattr(module, 'BOLIM'):
                CHATBOT_BOLIMLARI[module_name] = module.BOLIM
                print(f"  🤖 {module_name}.py yuklandi")
        except Exception as e:
            print(f"  ⚠️ {module_name}.py yuklanmadi: {e}")

print(f"\n  🤖 Chatbot bo'limlari: {len(CHATBOT_BOLIMLARI)} ta")
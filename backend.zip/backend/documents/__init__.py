# documents/__init__.py
"""
Huquqiy AI - Barcha protsessual hujjatlar va chatbot bo'limlari
"""

from .organ import ORGAN_HUJJATLARI
from .fuqaro import FUQARO_HUJJATLARI
from .chatbot import CHATBOT_BOLIMLARI

# Barcha hujjatlar
HAMMA_HUJJATLAR = {**ORGAN_HUJJATLARI, **FUQARO_HUJJATLARI}

print(f"\n📚 ORGAN: {len(ORGAN_HUJJATLARI)} ta hujjat")
print(f"📚 FUQARO: {len(FUQARO_HUJJATLARI)} ta hujjat")
print(f"🤖 CHATBOT: {len(CHATBOT_BOLIMLARI)} ta bo'lim")
print(f"📊 JAMI: {len(HAMMA_HUJJATLAR)} ta hujjat\n")
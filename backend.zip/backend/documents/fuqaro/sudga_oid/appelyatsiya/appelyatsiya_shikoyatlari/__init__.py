"""
Bo'lim hujjatlarini avtomatik yig'adi.
Yangi .py fayl qo'shilsa — avtomatik ulanadi.
"""
import os
import importlib

HUJJATLAR = {}

_dir = os.path.dirname(__file__)
for _fname in os.listdir(_dir):
    if _fname.endswith('.py') and not _fname.startswith('_'):
        _modname = _fname[:-3]
        try:
            _mod = importlib.import_module(f'.{_modname}', package=__name__)
            if hasattr(_mod, 'HUJJATLAR'):
                HUJJATLAR.update(_mod.HUJJATLAR)
        except Exception as e:
            print(f"XATO: {_fname} — {e}")

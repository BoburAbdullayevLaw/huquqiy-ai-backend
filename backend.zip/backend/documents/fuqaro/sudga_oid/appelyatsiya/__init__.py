"""Appelyatsiya va kassatsiya — barcha bo'limlarni yig'adi"""
import importlib

HUJJATLAR = {}
BOLIMLAR = {}

_submodules = [
    ("appelyatsiya_shikoyatlari", "Appelyatsiya shikoyatlari"),
    ("kassatsiya_shikoyatlari",   "Kassatsiya shikoyatlari"),
    ("etiroznomalar",             "E'tiroznomalar"),
    ("boshqa_shikoyatlar",        "Boshqa shikoyatlar"),
]

for _mod_name, _nomi in _submodules:
    try:
        _mod = importlib.import_module(f'.{_mod_name}', package=__name__)
        _docs = getattr(_mod, 'HUJJATLAR', {})
        HUJJATLAR.update(_docs)
        BOLIMLAR[_mod_name] = {"nomi": _nomi, "hujjatlar": _docs}
    except Exception as e:
        print(f"XATO {_mod_name}: {e}")

# 2_1_nusxa_berish/iqtisodiy_sudga_hujjat_nusxasi.py
"""
Hujjatlarning nusxasini berish to‘g‘risida Iqtisodiy ishlar bo‘yicha sudiga ariza
"""

HUJJATLAR = {
    "FQ-NB-001": {
        "nomi": "Hujjatlarning nusxasini berish to‘g‘risida Iqtisodiy ishlar bo‘yicha sudiga ariza",
        "jpk": "Iqtisodiy protsessual kodeksi 42-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Hujjatlarning nusxasini berish to‘g‘risida Iqtisodiy ishlar bo‘yicha sudiga ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik ishlari bo‘yicha sudi nomi", "type": "text",
             "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI TASHKILOT
            {"id": "tashkilot_nomi", "label": "Ariza bergan tashkilotning nomi, tashkiliy huquqiy shakli",
             "type": "text", "required": True},
            {"id": "mansabdor_lavozimi", "label": "Imzo quyishga vakolatli bo‘lgan mansabdor shaxsning lavozimi",
             "type": "text", "required": True},
            {"id": "mansabdor_fio", "label": "Imzo quyishga vakolatli bo‘lgan mansabdor shaxsning F.I.O.", "type": "text",
             "required": True},
            {"id": "tashkilot_manzil", "label": "Ariza bergan tashkilotning joylashgan manzili", "type": "text",
             "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "qanoatlantirilgan_sana", "label": "Daʼvogarning daʼvo talabi qanoatlantirilgan sana", "type": "date",
             "required": True},
            {"id": "davogar_nomi", "label": "Daʼvogar tashkilotning tashkiliy huquqiy shakli va nomi", "type": "text",
             "required": True},
            {"id": "davo_mazmuni", "label": "Ish bo‘yicha davogarning daʼvo arizasi mazmuni", "type": "text",
             "required": True},

            # SHIKOYAT TURI
            {"id": "shikoyat_turi", "label": "Apellyatsiya yoki kassatsiya shikoyati", "type": "select",
             "options": ["apellyatsiya", "kassatsiya"], "required": True},
            {"id": "yuqori_sud_nomi",
             "label": "Apellyatsiya yoki kassatsiya shikoyati yo‘naltirilayotgan viloyat sudi nomi yoki Toshkent shahri, Qoraqalpog‘iston Respublikasi sudi",
             "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Iqtisodiy ishlar boʻyicha
                                                            {sud_nomi}ga

Manzil: {tashkilot_manzil}

{tashkilot_nomi}
{tashkilot_nomi} {mansabdor_lavozimi} {mansabdor_fio}dan



                                                              A R I Z A

                                                (Hujjatlarning nusxasini berish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {qanoatlantirilgan_sana} kuni iqtisodiy ishlari boʻyicha {sud_nomi} sudi tomonidan daʼvogar {davogar_nomi}ning tashkilotimizga nisbatan {davo_mazmuni} haqidagi iqtisodiy ish koʻrib chiqilib, daʼvogarning daʼvo talabi qanoatlantirilgan.

Men mazkur hal qiluv qaroridan norozi boʻlib {shikoyat_turi} tartibida {yuqori_sud_nomi}ga shikoyat keltirayotganligim sababli Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 42-moddasiga asosan mazkur iqtisodiy ish hujjatlarining nusxasini berishingizni soʻrayman.



                                                              {tashkilot_nomi}
                                                              {mansabdor_lavozimi}

                                                              _________________
                                                                   (imzo)

                                                              {mansabdor_fio}

                                                              {ariza_sana} yil.
***
"""
    }
}
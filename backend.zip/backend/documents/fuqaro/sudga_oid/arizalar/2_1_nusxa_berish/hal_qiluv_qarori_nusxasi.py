# 2_1_nusxa_berish/hal_qiluv_qarori_nusxasi.py
"""
Hal qiluv qarorining nusxasini berish toʻgʻrisida ariza
"""

HUJJATLAR = {
    "FQ-NB-003": {
        "nomi": "Hal qiluv qarorining nusxasini berish toʻgʻrisida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 270-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Hal qiluv qarorining nusxasini berish toʻgʻrisida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, arizachi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan sud nomi (sudning sohasi: fuqarolik, iqtisodiy, maʼmuriy ishlar boʻyicha)", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZACHI MA'LUMOTLARI
            {"id": "arizachi_fio", "label": "Arizachining F.I.O.", "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Arizachiga nisbatan meros mulkni taqsimlash haqida sudga daʼvo qilgan daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "ish_berilgan_sana", "label": "Arizachiga nisbatan meros mulkni taqsimlash haqidagi ishni koʻrib chiqish uchun berilgan sana", "type": "date", "required": True},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

{arizachi_fio}dan



                                                              A R I Z A

                                                (Hal qiluv qarorining nusxasini berish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {ish_berilgan_sana} yilda {sud_nomi} tomonidan daʼvogar {davogar_fio}ning menga nisbatan meros mulkni taqsimlash haqidagi ishi koʻrib chiqilib, qaror qabul qilingan.

Hozirgi kunga qadar men sudning hal qiluv qaroridan nusxa olmaganligim sababli Oʻzbekiston Respublikasi Fuqarolik Protsessual Kodeksining 270-moddasiga asosan mazkur ish yuzasidan chiqarilgan hal qiluv qaroridan nusxa berishingizni soʻrayman.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# 2_1_nusxa_berish/fuqarolik_sudiga_hujjat_nusxasi.py
"""
Hujjatlarning nusxasini berish to‘g‘risida Fuqarolik ishlari bo‘yicha sudiga ariza
"""

HUJJATLAR = {
    "FQ-NB-002": {
        "nomi": "Hujjatlarning nusxasini berish to‘g‘risida Fuqarolik ishlari bo‘yicha sudiga ariza",
        "jpk": "Fuqarolik protsessual kodeksi 40-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Hujjatlarning nusxasini berish to‘g‘risida Fuqarolik ishlari bo‘yicha sudiga ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik ishlari bo‘yicha sudi nomi", "type": "text",
             "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI SHAXS
            {"id": "arizachi_manzil", "label": "Ariza bergan shaxsning yashash manzili", "type": "text",
             "required": True},
            {"id": "arizachi_fio", "label": "Ariza bergan shaxsning F.I.O.", "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "qanoatlantirilgan_sana", "label": "Daʼvogarning daʼvo talabi qanoatlantirilgan sana", "type": "date",
             "required": True},
            {"id": "davogar_fio", "label": "Ish bo‘yicha davogarning F.I.O.", "type": "text", "required": True},
            {"id": "ish_mazmuni", "label": "Ishning qisqacha mazmuni", "type": "text", "required": True},

            # SHIKOYAT TURI
            {"id": "shikoyat_turi", "label": "Apellyatsiya yoki kassatsiya shikoyati", "type": "select",
             "options": ["apellyatsiya", "kassatsiya"], "required": True},
            {"id": "viloyat_nomi",
             "label": "Apellyatsiya yoki kassatsiya shikoyati yo‘naltirilayotgan viloyat nomi (Toshkent shahri)",
             "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                                (Hujjatlarning nusxasini berish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {qanoatlantirilgan_sana} kuni fuqarolik ishlari boʻyicha {sud_nomi} sudi tomonidan daʼvogar {davogar_fio}ning menga nisbatan {ish_mazmuni} haqidagi fuqarolik ishi koʻrib chiqilib, daʼvogarning daʼvo talabi qanoatlantirilgan.

Men mazkur hal qiluv qaroridan norozi boʻlib {shikoyat_turi} tartibida fuqarolik ishlari boʻyicha {viloyat_nomi} sudiga shikoyat keltirayotganligim sababli Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 40-moddasiga asosan mazkur fuqarolik ishi hujjatlarining nusxasini berishingizni soʻrayman.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
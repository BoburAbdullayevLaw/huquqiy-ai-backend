# 2_3_davoni_taminlash/davoni_taminlash_chorasini_ozgartirish.py
"""
Daʼvoni taʼminlash chorasini oʻzgartirish toʻgʻrisida ariza
"""

HUJJATLAR = {
    "FQ-DT-003": {
        "nomi": "Daʼvoni taʼminlash chorasini oʻzgartirish toʻgʻrisida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 108-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Daʼvoni taʼminlash chorasini oʻzgartirish toʻgʻrisida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan sud nomi (sudning sohasi: fuqarolik, iqtisodiy, maʼmuriy ishlar boʻyicha)", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana (yil, oy, kun)", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_fio", "label": "Ariza beruvchining F.I.O.", "type": "text", "required": True},
            {"id": "arizachi_manzil", "label": "Ariza beruvchining yashash manzili", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Ish boʻyicha daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "taminlash_sana", "label": "Daʼvoni taʼminlash toʻgʻrisida qaror qabul qilingan sana", "type": "date", "required": True},

            # XATLANGAN AVTOMOBIL
            {"id": "xatlangan_rusum", "label": "Xatlangan avtomashinaning rusumi", "type": "text", "required": True},
            {"id": "xatlangan_davlat_raqam", "label": "Xatlangan avtomashinaning davlat raqam belgisi", "type": "text", "required": True},
            {"id": "mib_nomi", "label": "Avtomashinani xatlab, roʻyxatga olgan MIB boʻlimi nomi (tuman MIB boʻlimi)", "type": "text", "required": True},

            # SOTIB OLGAN SHAXS
            {"id": "sotib_olgan_fio", "label": "Xatlangan avtomashinani sotib olgan shaxsning F.I.O.", "type": "text", "required": True},

            # YANGI AVTOMOBIL
            {"id": "yangi_davlat_raqam", "label": "Xatlangan avtomashina oʻrniga xatlanishi soʻralayotgan avtomashinaning davlat raqam belgisi", "type": "text", "required": True},
            {"id": "yangi_rusum", "label": "Xatlangan avtomashina oʻrniga xatlanishi soʻralayotgan avtomashina rusumi", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                      (daʼvoni taʼminlash chorasini oʻzgartirish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, daʼvogar {davogar_fio} menga nisbatan qarz summasini undirish haqidagi daʼvo ariza bilan sudga murojaat qilgan.

Daʼvoni taʼminlatish maqsadida {sud_nomi} sudining {taminlash_sana} dagi ajrimi bilan mening nomimga rasmiylashtirilgan {xatlangan_rusum} rusumli davlat raqam belgisi {xatlangan_davlat_raqam} boʻlgan avtomashinam MIB {mib_nomi} boʻlimi tomonidan roʻyxatga olindi.

Ushbu avtomashinani men kelishuv asosida fuqaro {sotib_olgan_fio}ga sotganman, biroq uning nomiga oʻtkazib bermaganman, chunki avtomashinani boʻlib toʻlash sharti bilan berganman.

Mening nomimda boshqa davlat raqami {yangi_davlat_raqam} boʻlgan {yangi_rusum} rusumli avtomashinam mavjud.

Shu sababli Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 108-moddasiga asosan daʼvoni taʼminlash chorasini oʻzgartirishingizni soʻrayman.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# 2_3_davoni_taminlash/yoqolgan_sud_ishini_tiklash.py
"""
Yo‘qolgan sud ishini yuritishni tiklash to‘g‘risida ariza
"""

HUJJATLAR = {
    "FQ-DT-002": {
        "nomi": "Yo‘qolgan sud ishini yuritishni tiklash to‘g‘risida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 340-345-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Yo‘qolgan sud ishini yuritishni tiklash to‘g‘risida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza beruvchining yashash manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Ariza beruvchining F.I.O.", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar_nomi", "label": "Fuqarolik ish bo‘yicha da’vogar tashkilotning nomi va tashkiliy huquqiy shakli",
             "type": "text", "required": True},
            {"id": "javobgar_nomi", "label": "Fuqarolik ish bo‘yicha javobgar tashkilotning nomi va tashkiliy huquqiy shakli",
             "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Da’vo ariza mazmuni", "type": "text", "required": True},
            {"id": "sudya_fio", "label": "Fuqarolik ishni ko‘rib chiqayotgan sudyaning F.I.O.", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Arizaga ilova qilingan hujjatlar ro‘yxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari bo‘yicha
                                                            {sud_nomi} sudiga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                                Yo‘qolgan sud ishini tiklash to‘g‘risida



Fuqarolik ishlari bo‘yicha {sud_nomi} sudiga da’vogar {davogar_nomi} javobgar {javobgar_nomi}ga nisbatan {davo_mazmuni} to‘g‘risidagi da’vo arizasi bilan murojaat qilgan.

Mazkur ish sudya {sudya_fio}ning yurituviga berilgan. Ushbu ishni ko‘rib chiqish boshlangan. Biroq keyinchalik sud ushbu ish yo‘qolganligini, uni tiklash to‘g‘risida taraflar ariza berishi mumkinligi bildirildi.

O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 340-moddasiga ko‘ra, yo‘qolgan sud ishini yuritish sud tomonidan ishda ishtirok etuvchi shaxslarning, prokurorning arizasiga binoan, shuningdek sudning tashabbusiga ko‘ra tiklanishi mumkin.

Yo‘qolgan sud ishini yuritish to‘liq yoki uning sud fikriga ko‘ra tiklanishi zarur bo‘lgan qismi tiklanadi. Sudning hal qiluv qarori yoki ish yuritishni tugatish to‘g‘risidagi ajrimi, agar ular ish yuzasidan chiqarilgan bo‘lsa, tiklanishi shart.

Mazkur Kodeksning 341-moddasiga ko‘ra, yo‘qolgan sud ishini yuritishni tiklash to‘g‘risidagi ariza ishni ko‘rib chiqqan sudga beriladi. Arizada ishga doir batafsil ma’lumotlar bo‘lishi kerak.

Yuqoridagilardan kelib chiqib, O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 340-345-moddalariga asoslanib,



                                                              SO‘RAYMAN:



Da’vogar {davogar_nomi}ning javobgar {javobgar_nomi}ga nisbatan {davo_mazmuni} to‘g‘risidagi da’vo arizasi bo‘yicha yuritilib, yo‘qolgan fuqarolik ishini tiklashingizni.



Ilova: {ilova}



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
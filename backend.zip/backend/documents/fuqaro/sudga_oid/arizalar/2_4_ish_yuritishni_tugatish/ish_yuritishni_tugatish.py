# 2_4_ish_yuritishni_tugatish/ish_yuritishni_tugatish.py
"""
Ish yurituvni tugatish to‘g‘risida ariza (Fuqarolik sudi)
"""

HUJJATLAR = {
    "FQ-IT-001": {
        "nomi": "Ish yurituvni tugatish to‘g‘risida ariza (Fuqarolik sudi)",
        "jpk": "Fuqarolik protsessual kodeksi 42, 43, 124, 125, 157-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish yurituvni tugatish to‘g‘risida ariza (Fuqarolik sudi)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza beruvchining manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Ariza beruvchi shaxsning F.I.O.", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Ish boʻyicha javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Daʼvo ariza mazmuni", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                      Fuqarolik ish boʻyicha ish yuritishni tugatish toʻgʻrisida



Fuqarolik ishlari boʻyicha {sud_nomi} sudining ish yurituvida javobgar {javobgar_fio}ga nisbatan {davo_mazmuni} haqidagi daʼvo arizam yuzasidan yuritilgan fuqarolik ishi mavjud.

Bugungi kunga kelib, daʼvo arizamda qayd etilgan nizo yuzasidan javobgar bilan oʻrtamizdagi kelishmovchiliklar bartaraf etilgan.

Oʻzbekiston Respublikasi Fuqarolik protsessual Kodeksining 124-moddasiga koʻra, daʼvogar arz qilingan talablaridan voz kechgan va sud bu voz kechishni qabul qilgan boʻlsa ish yuritish tugatiladi.

Mazkur kodeksning 125-moddasiga koʻra, ish yuritish sudning ajrimi bilan tugatiladi. Agar ish yuritish ish sudga taalluqli boʻlmaganligi sababli tugatilsa va nizoni hal etish boshqa davlat organining vakolatiga taalluqli boʻlsa, sud arizachining qaysi organga murojaat qilishi kerakligini koʻrsatishi shart.

Men yuqoridagilardan kelib chiqqan holda javobgar {javobgar_fio}ga nisbatan boʻlgan daʼvo talablarimdan voz kechaman.

Daʼvo talablaridan voz kechishning huquqiy oqibatlari menga sud tomonidan tushuntirilgan.

Yuqoridagilardan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 42, 43, 157-moddasiga asoslanib, meni javobgar {javobgar_fio}ga nisbatan {davo_mazmuni} toʻgʻrisidagi daʼvo talablarimdan voz kechganligimni qabul qilib, ish yuritishni tugatishingizni soʻrayman.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# 2_4_ish_yuritishni_tugatish/kelishuv_bitimini_tasdiqlash.py
"""
Kelishuv bitimini tasdiqlash toʻgʻrisida ariza
"""

HUJJATLAR = {
    "FQ-IT-002": {
        "nomi": "Kelishuv bitimini tasdiqlash toʻgʻrisida ariza",
        "jpk": "Iqtisodiy protsessual kodeksi 42, 130-133-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Kelishuv bitimini tasdiqlash toʻgʻrisida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan iqtisodiy sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana (kun, oy, yil)", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza beruvchining manzili", "type": "text", "required": True},
            {"id": "arizachi_nomi",
             "label": "Ariza beruvchi yuridik shaxs nomi yoki yakka tartibdagi tadbirkorning F.I.O. (masalan: 'Nur' MJCH yoki YATT A.Aliyev)",
             "type": "text", "required": True},
            {"id": "arizachi_rahbar_fio",
             "label": "Ariza beruvchi yuridik shaxs rahbarining yoki yakka tartibdagi tadbirkorning F.I.O.", "type": "text",
             "required": True},

            # ISH MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Ish boʻyicha javobgar tashkilotning tashkiliy huquqiy shakli va nomi",
             "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Daʼvo ariza mazmuni", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Iqtisodiy ishlar boʻyicha
                                                            {sud_nomi}ga

Manzil: {arizachi_manzil}

{arizachi_nomi}dan



                                                              A R I Z A

                                                kelishuv bitimini tasdiqlash toʻgʻrisida



Iqtisodiy ishlar boʻyicha {sud_nomi} sudining ish yurituvida mening javobgar {javobgar_nomi}ga nisbatan {davo_mazmuni} haqidagi daʼvo arizam yuzasidan yuritilgan iqtisodiy ishi mavjud.

Men oʻz daʼvo arizamda {davo_mazmuni}ni soʻraganman.

Ishni sudda koʻrish davomida javobgar men bilan kelishib, daʼvo arizamda koʻrsatilgan talablarimni ixtiyoriy ravishda qanoatlantirdi. Biz bu toʻgʻrida kelishuv bitimi tuzdik.

Javobgar bilan kelishuv bitimini ixtiyoriy ravishda tuzdik, kelishuv bitimi mazmuni bizga tushunarli.

Menga kelishuv bitimi tuzish oqibatlari sud tomonidan tushuntirildi. Mazkur kelishuv bitimining tuzilishi boshqa shaxslarning huquq va manfaatlariga daxl qilmaydi.

Yuqoridagilarga koʻra hamda Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 42, 130-133-moddalariga asoslanib, men bilan javobgar {javobgar_nomi} oʻrtasida mazkur iqtisodiy ish yuzasidan tuzilgan kelishuv bitimini tasdiqlashni va iqtisodiy ishni ish yuritishdan tugatishni soʻrayman.



Ilova:
1. Ariza nusxasi
2. Kelishuv bitimi nusxasi



                                                              {arizachi_rahbar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
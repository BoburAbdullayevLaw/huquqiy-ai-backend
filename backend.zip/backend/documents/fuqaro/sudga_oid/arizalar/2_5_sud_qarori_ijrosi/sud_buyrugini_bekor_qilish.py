# 2_5_sud_qarori_ijrosi/sud_buyrugini_bekor_qilish.py
"""
Sud buyrug‘ini bekor qilish to‘g‘risida ariza
"""

HUJJATLAR = {
    "FQ-SI-001": {
        "nomi": "Sud buyrug‘ini bekor qilish to‘g‘risida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 3, 4, 170, 181, 189-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sud buyrug‘ini bekor qilish to‘g‘risida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, arizachi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZACHI MA'LUMOTLARI
            {"id": "arizachi_manzil", "label": "Arizachining yashash manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Arizachining F.I.O.", "type": "text", "required": True},
            {"id": "arizachi_telefon", "label": "Arizachining telefon raqami", "type": "text", "required": True},
            {"id": "arizachi_email", "label": "Arizachining E-mail manzili", "type": "email", "required": False},

            # SUD BUYRUG'I MA'LUMOTLARI
            {"id": "buyruq_sud_nomi", "label": "Sud buyrugʻi qabul qilgan sud nomi", "type": "text", "required": True},
            {"id": "buyruq_sana", "label": "Sud buyrugʻi qabul qilingan sana", "type": "date", "required": True},
            {"id": "buyruq_raqami", "label": "Qabul qilingan sud buyrugʻining raqami", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugulgan_sana",
             "label": "Sud buyrugʻiga asosan foydasiga moddiy taʼminot undirish belgilangan bolaning tugʻilgan sanasi",
             "type": "date", "required": True},
            {"id": "bola_fio",
             "label": "Sud buyrugʻiga asosan foydasiga moddiy taʼminot undirish belgilangan bolaning F.I.O.",
             "type": "text", "required": True},

            # ARIZA BERGAN SHAXS
            {"id": "arizachi2_fio", "label": "Sud buyrugʻi chiqarilishi toʻgʻrisida ariza bergan shaxsning F.I.O.",
             "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan

Telefon: {arizachi_telefon}
E-mail: {arizachi_email}



                                                              ARIZA

                                                (sud buyrugʻini bekor qilish haqida)



Fuqarolik ishlari boʻyicha {buyruq_sud_nomi} sudining {buyruq_sana} dagi {buyruq_raqami}-sonli sud buyrugʻiga asosan mendan {bola_tugulgan_sana} da tugʻilgan voyaga yetmagan {bola_fio} ismli bolaning moddiy taʼminoti uchun aliment undirish belgilanib, {arizachi2_fio}ning arizasi qanoatlantirilgan. Men ushbu sud buyrugʻi qabul qilingan sud jarayonida qatnashmaganman.

Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 170-moddasiga koʻra, sud buyrugʻi nizosiz talablar boʻyicha sud muhokamasi oʻtkazmasdan beriladigan sud hujjatidir.

Men va sud buyrugʻi qabul qilinishida arizachi sifatida qatnashgan {arizachi2_fio} oʻrtamizda {bola_tugulgan_sana} da tugʻilgan voyaga yetmagan {bola_fio}ga otalikni belgilash masalasida nizo mavjud. Men {bola_fio}ni oʻz farzandim deb bilmayman.

Fuqarolik protsessual kodeksining 181-moddasiga koʻra, qarzdor arz qilingan talabga qarshi eʼtirozlarini buyruqni bergan sudga beradi. Aliment undirish toʻgʻrisidagi sud buyrugʻi ijro ishini yuritish boʻyicha undiruv tugaguniga qadar undiruvchining arizasiga koʻra bekor qilinishi mumkin. Bunday holda sudya sud buyrugʻini bekor qilib, bu haqida ajrim chiqaradi.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual Kodeksining 3, 4, 170, 181, 189-moddalariga asosan



                                                              SOʻRAYMAN:



Fuqarolik ishlari boʻyicha {buyruq_sud_nomi} sudining {buyruq_sana} dagi {arizachi2_fio} foydasiga {bola_tugulgan_sana} da tugʻilgan {bola_fio} ismli bolaning moddiy taʼminoti uchun aliment undirish haqidagi {buyruq_raqami}-sonli sud buyrugʻini bekor qilishingizni.



Ilova:
1. Sud buyrugʻi nusxasi.
2. Arizamni asoslovchi hujjatlar.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
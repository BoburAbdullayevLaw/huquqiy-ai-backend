# 2_5_sud_qarori_ijrosi/sud_buyrugi_dublikati_iqtisodiy.py
"""
Sud buyrug‘i dublikatini berish to‘g‘risida iqtisodiy sudga ariza
"""

HUJJATLAR = {
    "FQ-SI-002": {
        "nomi": "Sud buyrug‘i dublikatini berish to‘g‘risida iqtisodiy sudga ariza",
        "jpk": "Iqtisodiy protsessual kodeksi 341-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sud buyrug‘i dublikatini berish to‘g‘risida iqtisodiy sudga ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan iqtisodiy sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_nomi", "label": "Ariza beruvchi yuridik shaxsning nomi, tashkiliy-huquqiy shakli", "type": "text",
             "required": True},
            {"id": "arizachi_vakil_fio", "label": "Ariza beruvchi yuridik shaxs vakilining F.I.O.", "type": "text",
             "required": True},

            # SUD BUYRUG'I MA'LUMOTLARI
            {"id": "buyruq_sana", "label": "Sud buyrugʻi qabul qilingan sana", "type": "date", "required": True},
            {"id": "javobgar", "label": "Ish boʻyicha javobgar", "type": "text", "required": True},
            {"id": "buyruq_mazmuni", "label": "Sud buyrugʻining qisqacha mazmuni", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Iqtisodiy ishlar boʻyicha
                                                            {sud_nomi} sudiga

{arizachi_nomi} vakili
{arizachi_vakil_fio}dan



                                                              A R I Z A

                                          (sud buyrugʻining dublikatini berish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {buyruq_sana} kuni iqtisodiy ishlar boʻyicha {sud_nomi} sudi tomonidan {arizachi_nomi} foydasiga javobgar {javobgar}dan {buyruq_mazmuni} haqida sud buyrugʻi chiqarilgan.

Ushbu sud buyrugʻi menga berilgan edi. Lekin men ushbu sud buyrugʻini yoʻqotib qoʻyganman.

Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 341-moddasiga koʻra, sud buyrugʻi yoʻqotilgan taqdirda, uni bergan sud undiruvchining arizasiga koʻra sud buyrugʻining dublikatini berishi mumkin.

Sud buyrugʻining dublikatini berish toʻgʻrisidagi ariza sud buyrugʻini ijroga taqdim etish uchun belgilangan muddat oʻtguniga qadar berilishi mumkin, bundan sud buyrugʻi davlat ijrochisi yoki ijroni amalga oshiruvchi boshqa shaxs tomonidan yoʻqotilgan va bu haqda undiruvchiga sud buyrugʻini ijroga taqdim etish uchun belgilangan muddat oʻtganidan soʻng maʼlum boʻlgan hollar mustasno. Sud buyrugʻining dublikatini berish toʻgʻrisidagi ariza sudga kelib tushgan kundan eʼtiboran bir oylik muddatda sud majlisida koʻrib chiqiladi.

Undiruvchi, qarzdor sud majlisining vaqti va joyi toʻgʻrisida ariza kelib tushgan kundan eʼtiboran besh kundan kechiktirmay chiqarilgan sud ajrimi orqali xabardor qilinadi. Sud majlisining vaqti va joyi toʻgʻrisida tegishli tarzda xabardor qilingan mazkur shaxslarning kelmaganligi, arizani koʻrib chiqish uchun toʻsqinlik qilmaydi. Arizani koʻrish natijalari boʻyicha ajrim chiqariladi, uning koʻchirma nusxasi undiruvchi va qarzdorga yuboriladi.

Yuqoridagilardan kelib chiqqan holda Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 341-moddasiga asosan sud buyrugʻining dublikatini berishingizni soʻrayman.



                                                              {arizachi_vakil_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
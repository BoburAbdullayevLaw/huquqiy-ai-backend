# 2_5_sud_qarori_ijrosi/hal_qiluv_qarori_ijrosini_kechiktirish_fuqarolik.py
"""
Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida Fuqarolik ishlari boʻyicha ariza
"""

HUJJATLAR = {
    "FQ-SI-004": {
        "nomi": "Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida Fuqarolik ishlari boʻyicha ariza",
        "jpk": "Fuqarolik protsessual kodeksi 454-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida Fuqarolik ishlari boʻyicha ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik ishlari boʻyicha sud nomi", "type": "text",
             "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza bergan shaxsning yashash manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Ariza bergan shaxsning F.I.O.", "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "qaror_sana", "label": "Daʼvo arizani qanoatlantirish toʻgʻrisida hal qiluv qarori qabul qilingan sana",
             "type": "date", "required": True},
            {"id": "davogar_fio", "label": "Ish boʻyicha daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Daʼvo ariza mazmuni", "type": "text", "required": True},

            # Ijro ma'lumotlari
            {"id": "mib_bolimi", "label": "Sud qarori boʻyicha ijro ishi yuritayotgan MIB boʻlimi (tuman nomi)",
             "type": "text", "required": True},
            {"id": "qaror_mazmuni", "label": "Sudning hal qiluv qarori mazmuni (pul summasi yoki boshqa mol-mulklar)",
             "type": "text", "required": True},
            {"id": "davlat_boji", "label": "Davlat boji miqdori", "type": "text", "required": True},

            # Kechiktirish sababi
            {"id": "kechiktirish_sababi", "label": "Sud qarori ijrosini kechiktirish uchun sabab sifatida keltirilayotgan asoslar",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilinadigan hujjatlar roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                (Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {qaror_sana} kuni fuqarolik ishlari boʻyicha {sud_nomi}ning {davogar_fio} menga nisbatan {davo_mazmuni} haqidagi daʼvo arizasi boʻyicha fuqarolik ishi koʻrib chiqilib, daʼvogarning daʼvo talabi qanoatlantirilgan.

Hozirda menga mazkur fuqarolik ishi yuzasidan chiqarilgan hal qiluv qarori ijrosini taʼminlash maqsadida MIB {mib_bolimi} boʻlimi tomonidan mendan daʼvogarning foydasiga {qaror_mazmuni} undirish, davlat boji uchun {davlat_boji} soʻm undirish lozimligi haqida ogohlantirish xati kelgan.

Bugungi kunda {kechiktirish_sababi}

Yuqoridagilarga asosan va Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 454-moddasiga asosan hal qiluv qarori ijrosini kechiktirishingizni soʻrayman.



Ilova: {ilova}



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
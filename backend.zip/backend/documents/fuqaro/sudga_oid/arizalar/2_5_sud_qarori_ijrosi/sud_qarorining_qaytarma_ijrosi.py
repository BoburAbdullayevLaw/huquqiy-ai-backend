# 2_5_sud_qarori_ijrosi/sud_qarorining_qaytarma_ijrosi.py
"""
Sud qarorining qaytarma ijrosi to‘g‘risida ariza
"""

HUJJATLAR = {
    "FQ-SI-003": {
        "nomi": "Sud qarorining qaytarma ijrosi to‘g‘risida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 458, 459-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sud qarorining qaytarma ijrosi to‘g‘risida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza imzolangan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_fio", "label": "Ariza beruvchining F.I.O.", "type": "text", "required": True},
            {"id": "arizachi_manzil", "label": "Ariza beruvchining manzili", "type": "text", "required": True},
            {"id": "arizachi_telefon", "label": "Ariza beruvchining telefon raqami", "type": "text", "required": True},

            # BIRINCHI SUD MA'LUMOTLARI
            {"id": "birinchi_sana", "label": "Ariza beruvchiga nisbatan fuqarolik sudi ishi ko‘rilgan sana",
             "type": "date", "required": True},
            {"id": "birinchi_sud_nomi", "label": "Fuqarolik ishi ko‘rilgan sudning nomi", "type": "text",
             "required": True},
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "ish_predmeti", "label": "Ariza beruvchiga nisbatan ko‘rib chiqilgan fuqarolik sud ishining predmeti",
             "type": "text", "required": True},

            # KASSATSIYA MA'LUMOTLARI
            {"id": "ajrim_sana", "label": "Sudlov hayʼati ajrimi chiqarilgan sana", "type": "date", "required": True},
            {"id": "bekor_qilingan_sud_nomi", "label": "Hal qiluv qarori bekor qilingan sudning nomi", "type": "text",
             "required": True},
            {"id": "bekor_qilingan_sana", "label": "Hal qiluv qarori qabul qilingan sana", "type": "date",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Ariza beruvchi: {arizachi_fio}
Manzil: {arizachi_manzil}
Telefon: {arizachi_telefon}



                                                              A R I Z A

                                                (Sud qarorining qaytarma ijrosi toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {birinchi_sana} kuni fuqarolik ishlari boʻyicha {birinchi_sud_nomi} sudi tomonidan daʼvogar {davogar_fio}ning menga nisbatan {ish_predmeti} haqidagi fuqarolik ishi koʻrib chiqilib, daʼvogarning daʼvo talabi qanoatlantirilgan.

Mazkur fuqarolik ishi yuzasidan chiqarilgan hal qiluv qaroridan norozi boʻlib keltirgan kassatsiya tartibidagi shikoyatim Oʻzbekiston Respublikasi Oliy sudi fuqarolik ishlari sudlov hayʼatining {ajrim_sana} dagi ajrimiga koʻra fuqarolik ishlari boʻyicha {bekor_qilingan_sud_nomi} tumanlararo sudining {bekor_qilingan_sana} dagi hal qiluv qarori bekor qilinib, ish yangidan koʻrish uchun birinchi instansiya sudiga yuborilgan.

Birinchi instansiya sudining hal qiluv qarori bilan daʼvo arizasini qanoatlantirish rad etilgan.

Shu sababli, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 458-moddasiga asosan ijro etilgan sud hujjati oʻzgartirilgan yoki bekor qilingan va ish yangidan koʻrib chiqilganidan keyin talablarni qanoatlantirishni toʻliq yoki qisman rad etish toʻgʻrisida hal qiluv qarori qabul qilingan yoki ish yuritishni tugatish toʻgʻrisida yoxud arizani koʻrmasdan qoldirish toʻgʻrisida ajrim chiqarilgan taqdirda, oʻzgartirilgan yoki bekor qilingan sud hujjati boʻyicha javobgardan daʼvogarning foydasiga undirilgan narsalarning barchasi javobgarga qaytarib berilishi kerak (hal qiluv qarorining qaytarma ijrosi).

Shularni inobatga olib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 459-moddasi talablariga asosan sud hujjatining qaytarma ijrosi toʻgʻrisidagi masalani koʻrib chiqishingizni soʻrayman.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
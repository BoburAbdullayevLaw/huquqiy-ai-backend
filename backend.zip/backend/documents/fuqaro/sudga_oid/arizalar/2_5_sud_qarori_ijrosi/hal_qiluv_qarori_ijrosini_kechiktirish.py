# 2_5_sud_qarori_ijrosi/hal_qiluv_qarori_ijrosini_kechiktirish.py
"""
Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida ariza
"""

HUJJATLAR = {
    "FQ-SI-005": {
        "nomi": "Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 454-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan sud nomi (fuqarolik, iqtisodiy, maʼmuriy ishlar boʻyicha)", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza beruvchining yashash manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Ariza beruvchining F.I.O.", "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "qaror_sana", "label": "Hal qiluv qarori qabul qilingan sana", "type": "date", "required": True},
            {"id": "qaror_sud_nomi", "label": "Hal qiluv qarorini qabul qilgan sud nomi (fuqarolik, iqtisodiy, maʼmuriy ishlar boʻyicha)", "type": "text", "required": True},
            {"id": "davogar_fio", "label": "Ish boʻyicha daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Daʼvogarning daʼvo arizasi mazmuni", "type": "text", "required": True},

            # Ijro ma'lumotlari
            {"id": "mib_bolimi", "label": "Hal qiluv qarori ijrosini taʼminlayotgan MIB boʻlimi nomi", "type": "text", "required": True},
            {"id": "undiriladigan_narsa", "label": "Hal qiluv qarorida daʼvogarning foydasiga nima undirish belgilangan", "type": "text", "required": True},
            {"id": "davlat_boji", "label": "Undirilishi belgilangan davlat boji miqdori", "type": "text", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Arizaga asos sifatida ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                (Sudning hal qiluv qarori ijrosini kechiktirish toʻgʻrisida)



Beraman ushbu arizani shu haqdakim, {qaror_sana} kuni {qaror_sud_nomi} sudi tomonidan daʼvogar {davogar_fio}ning menga nisbatan {davo_mazmuni} haqidagi fuqarolik ishi koʻrib chiqilib, daʼvogarning daʼvo talabi qanoatlantirilgan.

Hozirda menga mazkur ish yuzasidan chiqarilgan hal qiluv qarori ijrosini taʼminlash maqsadida {mib_bolimi} boʻlimidan daʼvogarning foydasiga {undiriladigan_narsa} undirish, davlat boji uchun {davlat_boji} soʻm toʻlash lozimligi haqida ogohlantirish xati kelgan.

Bugungi kunda ushbu pullarni toʻlashga imkoniyatim yoʻq, chunki oilaviy ahvolim ogʻir, oʻzim hech qayerda ishlamayman, kam taʼminlangan oilalar hisobida turaman, shu sababli Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 454-moddasiga asosan hal qiluv qarori ijrosini kechiktirishingizni soʻrayman.



Ilova: {ilova}



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
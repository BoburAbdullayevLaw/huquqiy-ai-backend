# 2_2_davo_talablarini_ozgartirish/davodan_voz_kechish.py
"""
Daʼvodan voz kechilganligi sababli ish yuritishni tugatish toʻgʻrisida ariza
"""

HUJJATLAR = {
    "FQ-DT-001": {
        "nomi": "Daʼvodan voz kechilganligi sababli ish yuritishni tugatish toʻgʻrisida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 44, 226-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Daʼvodan voz kechilganligi sababli ish yuritishni tugatish toʻgʻrisida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana (kun, oy, yil)", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza beruvchi shaxsning yashash manzili", "type": "text",
             "required": True},
            {"id": "arizachi_fio", "label": "Ariza beruvchi shaxsning F.I.O.", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Ish bo‘yicha javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Daʼvo ariza mazmuni", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                      daʼvodan voz kechilganligi sababli ish yuritishni tugatish toʻgʻrisida



Fuqarolik ishlari boʻyicha {sud_nomi} sudining ish yurituvida javobgar {javobgar_fio}ga nisbatan {davo_mazmuni} haqidagi daʼvo arizam yuzasidan yuritilgan fuqarolik ishi mavjud.

Bugungi kunga kelib, daʼvo arizamda qayd etilgan nizo yuzasidan javobgar bilan oʻrtamizdagi kelishmovchiliklar bartaraf etilgan.

Shu sababli, javobgar {javobgar_fio}ga nisbatan boʻlgan daʼvo talablarimdan voz kechaman.

Daʼvo talablaridan voz kechishning huquqiy oqibatlari menga sud tomonidan tushuntirilgan.

Yuqoridagilardan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 44, 226-moddasiga asoslanib, meni javobgar {javobgar_fio}ga nisbatan {davo_mazmuni} toʻgʻrisidagi daʼvo talablarimdan voz kechganligimni qabul qilib, ish yuritishni tugatishingizni soʻrayman.



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
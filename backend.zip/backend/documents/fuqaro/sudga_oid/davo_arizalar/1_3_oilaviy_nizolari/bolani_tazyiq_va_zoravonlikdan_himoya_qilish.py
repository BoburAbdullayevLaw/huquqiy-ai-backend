# 1_3_oilaviy_nizolari/bolani_tazyiq_va_zoravonlikdan_himoya_qilish.py
"""
Bolaning tazyiq va zo‘ravonlikdan himoya qilish to‘g‘risida ariza
"""

HUJJATLAR = {
    "FQ-ON-006": {
        "nomi": "Bolaning tazyiq va zo‘ravonlikdan himoya qilish to‘g‘risida ariza",
        "jpk": "Bola huquqlari kafolatlari to‘g‘risidagi qonun, BMT Bola huquqlari konvensiyasi",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Bolaning tazyiq va zo‘ravonlikdan himoya qilish to‘g‘risida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda Bola huquqlari bo‘yicha vakil nomi va ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # ARIZACHI BOLA MA'LUMOTLARI
            {"id": "bola_manzil", "label": "Bolaning yashash manzili", "type": "text", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_telefon", "label": "Bolaning telefon raqami", "type": "text", "required": True},
            {"id": "bola_tugilgan_sana", "label": "Bolaning tug‘ilgan vaqti", "type": "date", "required": True},

            # BIRGA YASHAYOTGAN SHAXSLAR
            {"id": "birga_yashovchilar",
             "label": "Bola birgalikda yashayotgan shaxslar (ota-onasi, qarindoshlari yoki boshqa shaxslar)",
             "type": "textarea", "required": True},

            # ZO'RAVONLIK QILAYOTGAN SHAXSLAR
            {"id": "zoravon_shaxslar", "label": "Bolaga zo‘ravonlik, tazyiq o‘tkazayotgan shaxslar", "type": "textarea",
             "required": True},

            # ARIZA SANASI
            {"id": "ariza_sana", "label": "Ariza yozilgan sana", "type": "date", "required": True},
        ],
        "shablon": """
***
                                                            Bola huquqlari bo‘yicha vakil nomiga

{bola_manzil}da yashovchi
{bola_fio}dan
Telefon: {bola_telefon}



                                                              A R I Z A

                                          tazyiq va zo‘ravonlikdan himoya qilish to‘g‘risida



Men, {bola_tugilgan_sana} da tug‘ilgan {bola_fio} {bola_manzil}da {birga_yashovchilar} bilan birgalikda yashayman.

Biroq {zoravon_shaxslar} tomonidan menga doimiy ravishda turli ruhiy va jismoniy bosimlar, tazyiq o‘tkazib kelinmoqda.

Shunga ko‘ra, bola sifatidagi huquqlarimni himoya qilish maqsadida menga amaliy yordam ko‘rsatishingizni so‘rayman.



                                                              {bola_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
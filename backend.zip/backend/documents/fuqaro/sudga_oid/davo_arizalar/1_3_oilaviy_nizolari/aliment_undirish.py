# 1_3_oilaviy_nizolari/aliment_undirish.py
"""
Aliment undirish haqida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-007": {
        "nomi": "Aliment undirish haqida da'vo arizasi",
        "jpk": "Oila Kodeksi 117-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Aliment undirish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "fhydo_nomi", "label": "Nikohni qayd etgan FHDYO bo'limi nomi", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Nikoh qayd etilgan sana", "type": "date", "required": True},
            {"id": "nikoh_raqami", "label": "Nikoh dalolatnoma raqami", "type": "text", "required": True},

            # ALIMENT UCHUN ASOSLAR
            {"id": "aliment_asoslari",
             "label": "Aliment undirishga asos bo'lgan holatlar (mehnatga layoqatsizlik, homiladorlik, 3 yoshgacha bola borligi, 18 yoshgacha nogiron bola borligi, bolalikdan I guruh nogironiga qarash)",
             "type": "textarea", "required": True},

            # TUG'ILGAN YILI
            {"id": "javobgar_tugilgan_sana", "label": "Javobgarning tug'ilgan sanasi", "type": "date", "required": True},

            # ALIMENT SUMMASI
            {"id": "aliment_summa", "label": "Talab qilinayotgan oylik aliment summasi", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            E-mail: {davogar_email}
                                                            
                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                                Aliment undirish haqida



Men va javobgar oʻrtamizdagi qonuniy nikoh {fhydo_nomi} tomonidan {nikoh_sana} kuni {nikoh_raqami}-son bilan qayd etilgan.

{aliment_asoslari}

Javobgar meni moddiy taʼminlamayapti.

Oʻrtamizda aliment toʻlash toʻgʻrisida kelishuv mavjud emas.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Oila Kodeksining 117-moddasiga asosan



                                                              SOʻRAYMAN:



Moddiy taʼminotim uchun {javobgar_tugilgan_sana} da tugʻilgan javobgar {javobgar_fio} dan har oyda pul bilan toʻlanadigan qatʼiy {aliment_summa} soʻm summada aliment undirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Nikoh qayd etilganligi haqida guvohnoma
3. Aliment undirishga asos boʻluvchi holatlarni tasdiqlovchi hujjatlar
4. Ishonchnoma nusxasi (daʼvo ariza ishonchli vakil tomonidan berilgan taqdirda)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
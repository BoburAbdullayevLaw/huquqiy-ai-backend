# 1_3_oilaviy_nizolari/otalikni_belgilash_va_aliment.py
"""
Otalikni belgilash va aliment undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-017": {
        "nomi": "Otalikni belgilash va aliment undirish to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 62, 96, 99-moddalar, Oliy sud Plenumi 8-sonli qarori, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Otalikni belgilash va aliment undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_tugilgan_sana", "label": "Javobgarning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "javobgar_tugilgan_joy", "label": "Javobgarning tug'ilgan joyi (shahar, tuman)", "type": "text",
             "required": True},
            {"id": "javobgar_millati", "label": "Javobgarning millati", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # MUNOSABATLAR TARIXI
            {"id": "tanishtirgan_sana", "label": "Tanishgan sana (yil, oy)", "type": "text", "required": True},
            {"id": "birga_yashash_boshlangan_sana", "label": "Birga yashash boshlangan sana (yil)", "type": "text",
             "required": True},
            {"id": "birga_yashash_tugagan_sana", "label": "Ajralishgan sana (yil, kun)", "type": "text", "required": True},
            {"id": "ajralish_sababi", "label": "Ajralish sababi", "type": "textarea", "required": True},
            {"id": "mfy_nomi", "label": "Mahalla fuqarolar yig'ini nomi", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_sana", "label": "Bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_guvohnoma_raqami", "label": "Tug'ilganlik haqida guvohnoma raqami", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_sana", "label": "Tug'ilganlik haqida guvohnoma berilgan sana", "type": "date",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}
E-mail: {davogar_email}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}
E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                    Otalikni belgilash va aliment undirish to'g'risida



Men {davogar_fio} javobgar {javobgar_fio} bilan {tanishtirgan_sana} da tanishib, kеlajakda oila qurishni maqsad qildik.

{birga_yashash_boshlangan_sana} yildan boshlab javobgar {javobgar_fio} bilan qonuniy nikohsiz mening хonadonimda doimiy birgalikda oila qurib yashay boshladik.

{bola_tugilgan_sana} kuni {bola_fio} ismli farzandimiz tugʻildi.

Javobgar {javobgar_fio} bilan oʻzaro kelishmovchiligimiz yuzaga kelib, {birga_yashash_tugagan_sana} dan beri birga yashamaymiz. Chunki {ajralish_sababi}.

Javobgar {javobgar_fio} bilan oʻrtamizda qonuniy nikoh rasmiylashtirilmaganligi va javobgar oʻz bоlasiga nisbatan otalikni tan olmaganligi tufayli bolamga FHDYO boʻlimi tomonidan yolgʻiz ona sifatida mening familiyam bilan {bola_guvohnoma_sana} kuni №{bola_guvohnoma_raqami} sonli tugʻilish guvohnomasi rasmiylashtirildi. Holbuki, ushbu holat oʻz navbatida bola manfaatlariga taʼsir qilib, uni oʻz otasidan taʼminot olishga boʻlgan huquqlaridan mahrum qilmoqda.

Qolaversa, bolam tugʻilganidan soʻng, javobgar {javobgar_fio} kelib bizdan xabar olmaydi. Hatto, javobgar {javobgar_fio}ning bolam va men bilan birgalikda tushgan fotosuratlari ham menda mavjud.

Oʻzbekiston Respublikasi Oliy sudi Plenumining 2011 yil 25 noyabrdagi "Sudlar tomonidan otalikni belgilashga oid ishlarni koʻrishda qonunchilikning qoʻllanilishi toʻgʻrisida"gi 8-sonli qarorining 8-bandiga koʻra, javobgarning bolaning onasi bilan birgalikda yashaganliklari va umumiy roʻzgʻor yuritganliklari oilaviy munosabatlarga xos boʻlgan holatlar (homila paydo boʻlgan vaqtda va bola tugʻilgunga qadar bir turar-joyda yashash, umumiy budjet yuritish, birgalikda ovqatlanish, oʻzaro gʻamxoʻrlik, umumiy foydalanish uchun mol-mulk sotib olish va h.k.lar) mavjudligi bilan tasdiqlanadi.

Binobarin, mening vajlarim oilaviy muhitimizdan xabardor boʻlgan {mfy_nomi} MFYning dalolatnomasi bilan tasdiqlanadi.

Oʻzbekiston Respublikasi Oila kodeksining 62-moddasi 1-qismiga koʻra, oʻzaro nikohda boʻlmagan ota-onadan bola tugʻilgan taqdirda, ota-onaning birgalikdagi arizasi yoki bola otasining arizasi boʻlmagan hollarda otalik sud tartibida belgilanishi mumkin.

Voyaga yetmagan {bola_fio} ismli bolam mening qaramogʻimda tarbiyalanib kelmoqda. Javobgar {javobgar_fio} esa oʻz iхtiyori bilan {bola_fio} ismli bolamga nisbatan otalikni tan olish toʻgʻrisida FHDYO boʻlimiga murojaat qilmasdan kelayotganligi va uning taʼminoti uchun menga doimiy moddiy yordam bermasdan kelayotganligi tufayli sudga ushbu mazmundagi daʼvo arizasi bilan murojaat qilishga majbur boʻldim.

Oʻzbekiston Respublikasi Oila kodeksining 96-moddasiga asosan, ota-ona voyaga yetmagan bolalariga taʼminot berishi shart. Voyaga yetmagan bolalariga taʼminot berish majburiyatini iхtiyoriy ravishda bajarmagan ota (ona)dan sudning hal qiluv qaroriga yoki sud buyrugʻiga asosan aliment undiriladi.

Yuqoridagilarga koʻra va Oʻzbekiston Respublikasi Oliy sudi Plenumining 2011 yil 25 noyabrdagi 8-sonli qarori, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalari, Oʻzbekiston Respublikasi Oila kodeksining 62, 96, 99-moddalariga asoslanib,



                                                              SOʻRAYMAN:



1. Javobgar {javobgar_tugilgan_sana} da {javobgar_tugilgan_joy}da tugʻilgan, millati {javobgar_millati}, {javobgar_manzil} manzilida yashovchi {javobgar_fio} ning {bola_tugilgan_sana} da tugʻilgan {bola_fio} ismli bolamga nisbatan otaligini belgilashingizni.

2. Javobgar {javobgar_fio} dan mening foydamga voyaga yetmagan {bola_tugilgan_sana} da tugʻilgan {bola_fio} ismli farzandimning moddiy taʼminoti uchun javobgarning har oydagi ish haqi va boshqa turdagi barcha daromadlarining 1/4 qismi miqdorida (lekin undiriladigan aliment miqdori qonun hujjatlari bilan belgilangan eng kam ish haqining 75 foizidan kam boʻlmagan miqdorda) farzandim voyaga etgunga qadar aliment undirishingizni.



Ilova:
1) Daʼvo ariza nusxasi
2) Pasport nusxalari
3) Bolaning tugʻilganlik guvohnomasi nusxasi
4) Bolaning sogʻligʻi toʻgʻrisida tibbiy maʼlumotnoma
5) Mahalla fuqarolar yigʻini maʼlumotnomasi
6) Mahalla dalolatnomasi
7) Fotosuratlar



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
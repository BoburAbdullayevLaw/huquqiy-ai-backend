# 1_3_oilaviy_nizolari/bola_tarbiyasi_huquqi.py
"""
Bolani tarbiyalash huquqini u bilan alohida yashagan holda amalga oshirish tartibi toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ON-003": {
        "nomi": "Bolani tarbiyalash huquqini u bilan alohida yashagan holda amalga oshirish tartibi toʻgʻrisida daʼvo arizasi",
        "jpk": "Oila Kodeksi 71, 72, 73, 76, 78-moddalar, Konstitutsiya 77-modda, Oliy sud Plenumi 23-sonli qarori, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Bolani tarbiyalash huquqini u bilan alohida yashagan holda amalga oshirish tartibi toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
7. Farzandlar soni 4 taga mo'ljallangan, kerakli maydonlarni to'ldiring.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning e-mail (pochta) manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning e-mail manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Qonuniy nikohdan oʻtilgan sana", "type": "date", "required": True},
            {"id": "guvohnoma_sana", "label": "Guvohnoma berilgan sana", "type": "date", "required": True},
            {"id": "guvohnoma_raqami", "label": "Guvohnoma raqami", "type": "text", "required": True},

            # AJRALISH SABABI
            {"id": "kelishmovchilik_sababi", "label": "Kelishmovchiliklarning sababi", "type": "textarea",
             "required": True},
            {"id": "alohida_yashash_boshlanishi", "label": "Alohida yashash sanasining boshlanishi", "type": "date",
             "required": True},

            # 1-FARZAND
            {"id": "farzand1_tugilgan_sana", "label": "1-farzandining tugʻilgan sanasi", "type": "date",
             "required": False},
            {"id": "farzand1_fio", "label": "1-Bolaning F.I.O.", "type": "text", "required": False},
            {"id": "farzand1_guvohnoma_sana", "label": "1-Tugʻilganlik toʻgʻrisida guvohnoma berilgan sana",
             "type": "date", "required": False},
            {"id": "farzand1_guvohnoma_raqami", "label": "1-Tugʻilganlik toʻgʻrisida guvohnoma raqami", "type": "text",
             "required": False},
            {"id": "farzand1_yoshi", "label": "1-Farzandning toʻliq yoshi", "type": "text", "required": False},

            # 2-FARZAND
            {"id": "farzand2_tugilgan_sana", "label": "2-farzandining tugʻilgan sanasi", "type": "date",
             "required": False},
            {"id": "farzand2_fio", "label": "2-Bolaning F.I.O.", "type": "text", "required": False},
            {"id": "farzand2_guvohnoma_sana", "label": "2-Tugʻilganlik toʻgʻrisda guvohnoma berilgan sana",
             "type": "date", "required": False},
            {"id": "farzand2_guvohnoma_raqami", "label": "2-Tugʻilganlik toʻgʻrisida guvohnoma raqami", "type": "text",
             "required": False},
            {"id": "farzand2_yoshi", "label": "2-Farzandining toʻliq yoshi", "type": "text", "required": False},

            # 3-FARZAND
            {"id": "farzand3_tugilgan_sana", "label": "3-farzandining tugʻilgan sanasi", "type": "date",
             "required": False},
            {"id": "farzand3_fio", "label": "3-Bolaning F.I.O.", "type": "text", "required": False},
            {"id": "farzand3_guvohnoma_sana", "label": "3-Tugʻilganlik toʻgʻrisida guvohnoma berilgan sana",
             "type": "date", "required": False},
            {"id": "farzand3_guvohnoma_raqami", "label": "3-Tugʻilganlik toʻgʻrisida guvohnoma raqami", "type": "text",
             "required": False},
            {"id": "farzand3_yoshi", "label": "3-Farzandning toʻliq yoshi", "type": "text", "required": False},

            # 4-FARZAND
            {"id": "farzand4_tugilgan_sana", "label": "4-farzandining tugʻilgan sanasi", "type": "date",
             "required": False},
            {"id": "farzand4_fio", "label": "4-Bolaning F.I.O.", "type": "text", "required": False},
            {"id": "farzand4_guvohnoma_sana", "label": "4-Tugʻilganlik toʻgʻrisda guvohnoma berilgan sana",
             "type": "date", "required": False},
            {"id": "farzand4_guvohnoma_raqami", "label": "4-Tugʻilganlik toʻgʻrisida guvohnoma raqami", "type": "text",
             "required": False},
            {"id": "farzand4_yoshi", "label": "4-Farzandning toʻliq yoshi", "type": "text", "required": False},

            # TAVSIFNOMA
            {"id": "tavsifnoma", "label": "Daʼvogar tomonidan farzandlariga nisbatan axloqiy va maʼnaviy rivojlanishiga taʼsir qiluvchi qoʻpol, inson qadr-qimmatini kamsituvchi, haqorat qiluvchi yoki uni majburlovchi noxush holatlar kuzatilmaganligi toʻgʻrisidagi tavsifnoma, MFY va boshqalar maʼlumotnomalar",
             "type": "textarea", "required": True},

            # UCHRASHUV TARTIBI
            {"id": "uchrashuv_tartibi", "label": "Farzandning taʼlim va tarbiya olishidagi ishtiroki va uchrashib turishi uchun oʻz xohishiga koʻra qaysi tartibda boʻlishining qisqacha bayoni",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova hujjatlari", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            E-mail: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            E-mail: {javobgar_email}



Daʼvo mazmuni: Bolani tarbiyalash huquqini u bilan alohida yashagan holda amalga oshirish tartibi toʻgʻrisida



                                                            DAʼVO ARIZASI



Oʻzbekiston Respublikasi Konstitutsiyasining 77-moddasiga asosan, ota-onalar va ularning o‘rnini bosuvchi shaxslar o‘z farzandlarini voyaga yetguniga qadar boqishi, ularning tarbiyasi, ta’lim olishi, sog‘lom, to‘laqonli va har tomonlama kamol topishi xususida g‘amxo‘rlik qilishga majburdirlar.

Oila kodeksining 71-moddasiga koʻra, ota-ona oʻz bolalariga nisbatan teng huquq va majburiyatlarga egadirlar, hamda 73-moddasiga muvofiq, ota-ona oʻz bolalarini tarbiyalash huquqiga ega va tarbiyalashi shart. Ota-ona oʻz bolalarining tarbiyasi va kamoloti uchun javobgardir. Ular oʻz bolalarining sogʻligʻi, jismoniy, ruhiy, maʼnaviy va axloqiy kamoloti haqida gʻamxoʻrlik qilishlari shart.

Men {davogar_fio} javobgar {javobgar_fio} bilan {nikoh_sana} da qonuniy nikohdan oʻtganmiz. Nikohimiz tuzilganligi haqida {guvohnoma_sana} yilda № {guvohnoma_raqami} sonli guvohnoma berilgan.

Birgalikdagi turmushimizdan 
{f" {farzand1_tugilgan_sana} da tugʻilgan {farzand1_fio} ismli," if farzand1_fio else ""}
{f" {farzand2_tugilgan_sana} da tugʻilgan {farzand2_fio} ismli," if farzand2_fio else ""}
{f" {farzand3_tugilgan_sana} da tugʻilgan {farzand3_fio} ismli," if farzand3_fio else ""}
{f" {farzand4_tugilgan_sana} da tugʻilgan {farzand4_fio} ismli" if farzand4_fio else ""} farzandlarimiz bor.

Farzandlarimizga 
{f" {farzand1_guvohnoma_sana} da № {farzand1_guvohnoma_raqami}," if farzand1_guvohnoma_raqami else ""}
{f" {farzand2_guvohnoma_sana} da № {farzand2_guvohnoma_raqami}," if farzand2_guvohnoma_raqami else ""}
{f" {farzand3_guvohnoma_sana} da № {farzand3_guvohnoma_raqami}," if farzand3_guvohnoma_raqami else ""}
{f" {farzand4_guvohnoma_sana} da № {farzand4_guvohnoma_raqami}" if farzand4_guvohnoma_raqami else ""} tugʻilganligi haqida guvohnomalar berilgan.

Javobgar {javobgar_fio} bilan {kelishmovchilik_sababi} sababli birga yashamaymiz.

{alohida_yashash_boshlanishi} dan boshlab javobgar {javobgar_fio} bilan er-xotinlik munosabatlari tugatilib, alohida-alohida yashab kelmoqdamiz.

Farzandimning tarbiyasi, taʼlimi olishi, moddiy taʼminoti va bolaning doimiy yashash joyi yuzasidan javobgar {javobgar_fio} bilan kelishuvga erisha olmadik. Hozirda 
{f"{farzand1_fio}," if farzand1_fio else ""}
{f"{farzand2_fio}," if farzand2_fio else ""}
{f"{farzand3_fio}," if farzand3_fio else ""}
{f"{farzand4_fio}" if farzand4_fio else ""} ismli farzandlarim javobgar bilan yashab kelmoqda.

Hozirda javobgar farzandlarim 
{f"{farzand1_fio}," if farzand1_fio else ""}
{f"{farzand2_fio}," if farzand2_fio else ""}
{f"{farzand3_fio}," if farzand3_fio else ""}
{f"{farzand4_fio}" if farzand4_fio else ""} bilan muloqot qilishda qarshilik koʻrsatib, mening bolani tarbiyalash borasidagi huquqlarimni buzmoqda.

Men tomonimdan farzandimga nisbatan otalik huquqini amalga oshirishga jismoniy va ruhiy holati, axloqiy va maʼnaviy rivojlanishi taʼsir qiluvchi qoʻpol, inson qadr-qimmatini kamsituvchi, haqorat qiluvchi yoki uni majburlovchi noxush holatlar kuzatilmagan. Ushbu holatlarni {tavsifnoma} kabi hujjatlar ham tasdiqlaydi.

{f"{farzand1_fio}," if farzand1_fio else ""}
{f"{farzand2_fio}," if farzand2_fio else ""}
{f"{farzand3_fio}," if farzand3_fio else ""}
{f"{farzand4_fio}" if farzand4_fio else ""} ismli 
{f"{farzand1_yoshi}," if farzand1_yoshi else ""}
{f"{farzand2_yoshi}," if farzand2_yoshi else ""}
{f"{farzand3_yoshi}," if farzand3_yoshi else ""}
{f"{farzand4_yoshi}" if farzand4_yoshi else ""} yoshga toʻlgan farzandlarim javobgarga nisbatan menga koʻproq bogʻlanib qolganligi, axloqiy va boshqa shaxsiy fazilatlarim, farzandlarimning tarbiyasi va rivojlanishi uchun qulay sharoitga (daʼvogarning oilaviy ahvoli, moddiy sharoiti, ish vaqti, kasbi) ega ekanligim sababli farzandlarimning taʼlim va tarbiya olishidagi ishtirokim va uchrashib turish uchun quyidagicha tartib oʻrnatishni lozim deb hisoblayman.

{uchrashuv_tartibi}

Oʻzbekiston Respublikasi Oliy sudi Plenumining 1998-yildagi "Bolalar tarbiyasi bilan bogʻliq boʻlgan nizolarni hal qilishda sudlar tomonidan qonunlarni qoʻllash amaliyoti toʻgʻrisida"gi 23-sonli qarorining 7-bandi oltinchi va yettinchi xatboshilariga asosan, boladan alohida yashayotgan ota-onaning huquqidan kelib chiqqan holda u bilan koʻrishishda, shuningdek voyaga yetmaganning shu ota-ona bilan koʻrishish huquq va manfaatlarini himoya qilish zaruratidan kelib chiqib, sud har bir aniq ishning holatlarini inobatga olib hal qiluv qarorining xulosa qismida koʻrishish tartibini (vaqti, joyi, koʻrishish davomiyligi va h.k) bayon etishi belgilangan.

Bola bilan ota-onaning koʻrishish tartibini belgilashda bolaning jismoniy va ruhiy sogʻligʻi, uning axloqiy kamolotiga taʼsir qiladigan holatlar, bolaning yoshi va sogʻligʻining holati, bolaning ota (ona)ga bogʻliqligi va boshqa holatlar inobatga olinadi. Belgilangan koʻrishish tartibi bolaning manfaatiga javob berishi va ijro etish imkoniyati mavjud ekanligi keltirilgan.

Oila Kodeksining 78-moddasida nizo chiqqan taqdirda, ota-ona oʻz huquqlarini himoya qilish uchun sudga murojaat qilishga haqli. Bu talablarni koʻrishda sud bolani ota-onasiga qaytarish uning manfaatlariga zid degan xulosaga kelsa, bolaning fikrini hisobga olgan holda ota-onaning daʼvosini rad qilishga haqli.

Qayd qilingan holatlar va qonun talabidan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189-191-moddalari, Oʻzbekiston Respublikasi Oila kodeksining 71, 72, 73, 76, 78-moddalariga, hamda Oʻzbekiston Respublikasi Oliy sudi Plenumining 1998-yil 11-sentyabrdagi 23-sonli "Bolalar tarbiyasi bilan bogʻliq boʻlgan nizolarni hal qilishda sudlar tomonidan qonunlarni qoʻllash amaliyoti toʻgʻrisida"gi qarorining 7-bandiga asosan,



                                                            SOʻRAYMAN:



Farzandlarim 
{f"{farzand1_fio}," if farzand1_fio else ""}
{f"{farzand2_fio}," if farzand2_fio else ""}
{f"{farzand3_fio}," if farzand3_fio else ""}
{f"{farzand4_fio}" if farzand4_fio else ""} larning taʼlim va tarbiya olishida ishtirok etishim uchun {uchrashuv_tartibi} ular bilan uchrashib turishimni belgilashingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
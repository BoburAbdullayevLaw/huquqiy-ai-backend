# 1_3_oilaviy_nizolari/ota_ona_huquqini_cheklash.py
"""
Ota (ona)lik huquqini cheklash to‘g‘risida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ON-005": {
        "nomi": "Ota (ona)lik huquqini cheklash to‘g‘risida daʼvo arizasi",
        "jpk": "Oila kodeksi 83-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ota (ona)lik huquqini cheklash to‘g‘risida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "fhydo_nomi", "label": "Nikoh qayd qilingan FHDYO organi nomi", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Nikoh qayd qilingan vaqt", "type": "date", "required": True},
            {"id": "nikoh_raqami", "label": "Nikohni qayd etish dalolatnomasi raqami", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_sana", "label": "Bolaning tugʻilgan vaqti", "type": "date", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_guvohnoma_raqami", "label": "Bolaga berilgan tugʻilganlik toʻgʻrisidagi guvohnoma raqami",
             "type": "text", "required": True},
            {"id": "bola_guvohnoma_fhydo", "label": "Bolaga tugʻilganlik toʻgʻrisidagi guvohnoma bergan FHDYO nomi",
             "type": "text", "required": True},

            # CHEKLASH ASOSLARI
            {"id": "cheklash_asoslari", "label": "Ota-onalik huquqini cheklash uchun asoslar", "type": "textarea",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilinayotgan hujjatlar", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}
Elektron pochta: {davogar_email}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}
Elektron pochta: {javobgar_email}



                                                              DAʼVO ARIZA

                                                (Ota (ona)lik huquqini cheklash to‘g‘risida)



Men va javobgar o‘rtamizdagi qonuniy nikoh {fhydo_nomi} tomonidan {nikoh_sana} kuni {nikoh_raqami}-son bilan qayd etilgan.

Birgalikdagi turmushimizdan {bola_tugilgan_sana} kuni tugʻilgan {bola_fio} ismli (tugʻilganlik haqida guvohnoma {bola_guvohnoma_raqami}, {bola_guvohnoma_fhydo} tomonidan berilgan) farzandimiz bor.

Hozirgi kunda oilaviy kelishmovchiliklar sababli farzandimiz javobgar {javobgar_fio}ning qaramogʻida. Men javobgarning farzand tarbiyasida ishtirok etishini hohlamayman. Javobgar {javobgar_fio}ning bolam ta’lim va tarbiyasi uchun xavfli holatlari bor.

Bolam {bola_fio}ni javobgar {javobgar_fio}ning tarbiyasida qoldirish {cheklash_asoslari} kabi noxush holatlarni keltirib chiqaradi.

Javobgar {javobgar_fio} farzandim {bola_fio}ni moddiy jihatdan ham ta’minlamaydi. Bolamning ta’lim va tarbiyasi bilan hozirgi kunga qadar o‘zim shug‘ullanib kelayapman.

Shahar vasiylik va homiylik kengashi tomonidan taraflarning ahvoli o‘rganilib, javobgarning bugungi kunda bola tarbiyasida ishtirok eta olmasligi sababli uning huquqini cheklash lozimligi to‘g‘risida xulosa berilgan.

Yuqoridagilarni inobatga olib, O‘zbekiston Respublikasi Oila kodeksining 83-moddasi talablaridan kelib chiqib,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio}ning {bola_tugilgan_sana} kuni tugʻilgan {bola_fio} ismli farzandimga nisbatan ota(onalik) huquqini cheklashingizni.



Ilova: {ilova}



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)
***
"""
    }
}
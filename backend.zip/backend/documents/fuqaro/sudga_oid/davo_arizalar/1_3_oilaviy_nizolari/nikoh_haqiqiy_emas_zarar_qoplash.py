# 1_3_oilaviy_nizolari/nikoh_haqiqiy_emas_zarar_qoplash.py
"""
Nikoh haqiqiy emas deb topilganligi sababli zararni qoplash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-025": {
        "nomi": "Nikoh haqiqiy emas deb topilganligi sababli zararni qoplash to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 56-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Nikoh haqiqiy emas deb topilganligi sababli zararni qoplash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Nikoh qayd etilgan sana (kun, oy, yil)", "type": "date", "required": True},
            {"id": "nikoh_fhydo", "label": "Nikoh qayd etilgan FHDYO bo'limi (tuman, shahar)", "type": "text",
             "required": True},
            {"id": "nikoh_raqami", "label": "Nikoh qayd etish raqami", "type": "text", "required": True},

            # FARZANDLAR
            {"id": "farzandlar_soni", "label": "Farzandlar soni", "type": "text", "required": True},
            {"id": "farzandlar_bor", "label": "Farzandlar bormi", "type": "select", "options": ["bor", "yo'q"],
             "required": True},

            # NIKOHNI HAQIQIY EMAS DEB TOPISH
            {"id": "haqiqiy_emas_sud_nomi", "label": "Nikohni haqiqiy emas deb topgan sud nomi", "type": "text",
             "required": True},
            {"id": "haqiqiy_emas_sana", "label": "Nikohni haqiqiy emas deb topish to'g'risidagi sud qarori sanasi",
             "type": "date", "required": True},

            # MODDIY ZARAR
            {"id": "moddiy_zarar_summa",
             "label": "To'y va boshqa marosimlar uchun qilingan xarajatlar summasi", "type": "text", "required": True},

            # MA'NAVIY ZARAR
            {"id": "manaviy_zarar_summa", "label": "Ma'naviy zarar summasi", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                        Nikoh haqiqiy emas deb topilganligi sababli zararni qoplash to'g'risida



Javobgar {javobgar_fio} bilan men {nikoh_sana} kuni {nikoh_fhydo} FHDYO boʻlimida {nikoh_raqami}-son bilan qayd etilgan qonuniy nikohdan oʻtib turmush qurganmiz.

Turmushimiz davrida oʻrtamizda {farzandlar_soni} nafar farzandimiz {farzandlar_bor}.

Men bilan javobgar {javobgar_fio} oʻrtamizdagi nikoh fuqarolik ishlari boʻyicha {haqiqiy_emas_sud_nomi} sudining {haqiqiy_emas_sana} dagi hal qiluv qarori bilan haqiqiy emas deb topildi.

Men javobgar {javobgar_fio} ga uylanish uchun toʻy va boshqa marosimlar uchun jami {moddiy_zarar_summa} soʻmlik sarf-xarajatlar qilganman.

Bundan tashqari, javobgar {javobgar_fio}ning aybi bilan oʻrtamizdagi nikoh haqiqiy emas deb topildi, natijada men oilam, qoʻni-qoʻshni va mahalla fuqarolari oldida sharmanda boʻldim, obroʻyimga putur yetdi, oqibatda {manaviy_zarar_summa} soʻm maʼnaviy zarar koʻrdim.

Yuqoridagilarga asosan hamda Oʻzbekiston Respublikasi Oila kodeksining 56-moddasiga asosan,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} bilan men oʻrtamizda {nikoh_sana} kuni {nikoh_fhydo} FHDYO boʻlimida {nikoh_raqami}-son bilan qayd etilgan nikoh haqiqiy emas deb topilganligi sababli menga javobgardan {moddiy_zarar_summa} soʻm moddiy va {manaviy_zarar_summa} soʻm maʼnaviy zarar undirib berishingizni.



Ilova:
1) Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
2) Daʼvo ariza nusxasi
3) Pasport nusxasi
4) Nikoh guvohnomasi nusxasi
5) Nikohni haqiqiy emas deb topish toʻgʻrisidagi sud qarori nusxasi
6) Yashash joyidagi MFY tomonidan berilgan maʼlumotnomalar
7) Daʼvo talabini asoslovchi boshqa hujjatlar



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
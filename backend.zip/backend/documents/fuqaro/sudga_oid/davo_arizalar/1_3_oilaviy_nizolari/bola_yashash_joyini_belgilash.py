# 1_3_oilaviy_nizolari/bola_yashash_joyini_belgilash.py
"""
Bolaning yashash joyini belgilash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-018": {
        "nomi": "Bolaning yashash joyini belgilash to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 73-75-moddalar, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Bolaning yashash joyini belgilash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Nikoh tuzilgan sana", "type": "date", "required": True},
            {"id": "nikoh_guvohnoma_yil", "label": "Nikoh guvohnomasi berilgan yil", "type": "text", "required": True},
            {"id": "nikoh_guvohnoma_raqami", "label": "Nikoh guvohnomasi raqami", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_yil", "label": "Bolaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_guvohnoma_yil", "label": "Tug'ilganlik haqida guvohnoma berilgan yil", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_raqami", "label": "Tug'ilganlik haqida guvohnoma raqami", "type": "text",
             "required": True},

            # AJRALISH SABABI
            {"id": "ajralish_sababi", "label": "Ajralish sababi", "type": "textarea", "required": True},
            {"id": "ajralish_sana", "label": "Ajralishgan sana (yil)", "type": "text", "required": True},

            # JAVOBGARNING SALBIY TOMONLARI
            {"id": "javobgar_salbiy_holatlari",
             "label": "Javobgarning bola ta'lim va tarbiyasiga salbiy ta'sir ko'rsatadigan holatlari",
             "type": "textarea", "required": True},

            # TASDIQLOVCHI FAKTLAR
            {"id": "tasdiqlovchi_faktlar",
             "label": "Mazkur holatlarni tasdiqlovchi faktlar (MFY ma'lumotnomalari, fotosuratlar va boshqalar)",
             "type": "textarea", "required": True},

            # DA'VOGARNING UY MANZILI
            {"id": "davogar_uy_manzili", "label": "Da'vogarning uy manzili", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                                                                Fuqarolik ishlari boʻyicha
                                                                                                {sud_nomi}ga
                                    
                                                                                                Daʼvogar: {davogar_fio}
                                                                                                Manzil: {davogar_manzil}
                                                                                                Telefon: {davogar_telefon}
                                                                                                E-mail: {davogar_email}
                                                                                                
                                                                                                Javobgar: {javobgar_fio}
                                                                                                Manzil: {javobgar_manzil}
                                                                                                Telefon: {javobgar_telefon}
                                                                                                E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                    Bolaning yashash joyini belgilash to'g'risida



Men {davogar_fio} va javobgar {javobgar_fio} bilan {nikoh_sana} kuni qonuniy nikohdan oʻtganmiz. Nikohimiz tuzilganligi haqida {nikoh_guvohnoma_yil} yilda № {nikoh_guvohnoma_raqami} sonli guvohnoma berilgan.

Birgalikdagi turmushimizdan {bola_tugilgan_yil} yilda tugʻilgan {bola_fio} ismli farzandimiz bor. {bola_fio} ismli farzandimizga {bola_guvohnoma_yil} yilda № {bola_guvohnoma_raqami} tugʻilganligi haqida guvohnoma berilgan.

Javobgar {javobgar_fio} bilan oʻzaro kelishmovchiliklar sababli birga yashamaymiz. Chunki {ajralish_sababi}.

{ajralish_sana} yildan boshlab javobgar {javobgar_fio} bilan er-xotinlik munosabatlari tugatilgan.

Farzandimning tarbiyasi, taʼlimi olishi, moddiy taʼminoti va bolaning doimiy yashash joyi yuzasidan javobgar {javobgar_fio} bilan kelishuvga erisha olmadik.

{bola_fio} ismli farzandim turli joylarda javobgar {javobgar_fio} bilan yashab kelmoqda. Javobgar {javobgar_fio}ning doimiy yashash joyi yoʻq. Bu holat {bola_tugilgan_yil} yilda tugʻilgan {bola_fio} ismli farzandim uchun taʼlim va tarbiyasi uchun {javobgar_salbiy_holatlari} kabi salbiy holatlarni keltirib chiqarmoqda.

Mazkur holatlarni quyidagi faktlar ham tasdiqlaydi: {tasdiqlovchi_faktlar}.

Javobgar {javobgar_fio}ga nisbatan farzandimning mehr yoʻqligi, farzandim bilim olishi, oila bagʻrida mehr bilan tarbiyalanishi uchun harakat qilaman. Mening uy-joyimda farzandim uchun barcha imkoniyatlar mavjud. Hozirda javobgar {javobgar_fio} farzandim {bola_fio} bilan birga yashashimga qarshilik koʻrsatib, bolaga boʻlgan huquqlarimni buzmoqda.

Oʻzbekiston Respublikasi Oila kodeksining 73-moddasiga asosan ota-ona oʻz bolalarini tarbiyalash huquqiga ega va tarbiyalashi shart. Ota-ona oʻz bolalarining tarbiyasi va kamoloti uchun javobgardir. Ular oʻz bolalarining sogʻligʻi, jismoniy, ruhiy, maʼnaviy va axloqiy kamoloti haqida gʻamxoʻrlik qilishlari shart.

Javobgarning xatti-harakatlari farzandimning jismoniy va ruhiy sogʻligʻiga, axloqiy kamolotiga salbiy taʼsir koʻrsatadi.

Qayd qilingan holatlar va qonun talabidan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalari, Oʻzbekiston Respublikasi Oila kodeksining 73-75-moddasiga asosan,



                                                              SOʻRAYMAN:



{bola_tugilgan_yil} yil tugʻilgan {bola_fio} ismli farzandimning yashash joyi sifatida oʻzimning nomimda boʻlgan {davogar_uy_manzili} manzilidagi uy-joyni deb belgilab berishingizni.



Ilova:
- Nikoh tuzilganligi haqidagi guvohnoma nusxasi
- Bolaning tugʻilganligi toʻgʻrisidagi guvohnoma nusxasi
- Daʼvogarning daromadlari haqidagi maʼlumotnoma
- Javobgarning daromadlari haqidagi maʼlumotnoma
- Daʼvo ariza nusxasi
- Davlat boji toʻlanganligi toʻgʻrisida kvitansiya



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
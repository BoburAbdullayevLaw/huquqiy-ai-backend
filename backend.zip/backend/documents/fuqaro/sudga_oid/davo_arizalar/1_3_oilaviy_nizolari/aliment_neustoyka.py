# 1_3_oilaviy_nizolari/aliment_neustoyka.py
"""
Aliment bo‘yicha neustoykani undirish to‘g‘risida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ON-002": {
        "nomi": "Aliment bo‘yicha neustoykani undirish to‘g‘risida daʼvo arizasi",
        "jpk": "Oila Kodeksi 96, 142-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Aliment bo‘yicha neustoykani undirish to‘g‘risida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "fxdyo_nomi", "label": "Daʼvogar va javobgar o‘rtasida nikohni qayd etgan FXDYO bo‘limi nomi",
             "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Daʼvogar va javobgar o‘rtasida nikoh qayd etilgan sana", "type": "date",
             "required": True},
            {"id": "nikoh_raqami", "label": "Daʼvogar va javobgar o‘rtasidagi nikohning qayd (registratsiya) raqami",
             "type": "text", "required": True},

            # FARZAND MA'LUMOTLARI
            {"id": "farzand_tugilgan_sana", "label": "Daʼvogar va javobgarning farzandi tug‘ilgan sana", "type": "date",
             "required": True},
            {"id": "farzand_fio", "label": "Daʼvogar va javobgarning farzandining F.I.O.", "type": "text",
             "required": True},
            {"id": "guvohnoma_seriya", "label": "Tug‘ilganlik haqidagi guvohnomaning seriyasi, raqami", "type": "text",
             "required": True},

            # ALIMENT SUD QARORI
            {"id": "aliment_sud_nomi", "label": "Aliment undirish to‘g‘risida qaror qabul qilgan sud nomi",
             "type": "text", "required": True},
            {"id": "aliment_sud_sana", "label": "Aliment undirish to‘g‘risida qaror qabul qilingan sana", "type": "date",
             "required": True},
            {"id": "aliment_sud_hujjati", "label": "Aliment undirish to‘g‘risidagi sud hujjati nomi", "type": "text",
             "required": True,
             "placeholder": "Sud buyrug‘i, ajrim yoki hal qiluv qarori"},

            # QARZDORLIK DAVRI
            {"id": "tolanmaslik_boshlangan_sana",
             "label": "Javobgar tomonidan aliment to‘lovlarini to‘lamaslik holati boshlangan sana", "type": "date",
             "required": True},
            {"id": "tolanmaslik_oxirgi_sana", "label": "Aliment to‘lovlari to‘lanmasdan kelingan davrning oxirgi kuni",
             "type": "date", "required": True},

            # SUMMALAR
            {"id": "qarzdorlik_miqdori", "label": "To‘lanmagan aliment pullari bo‘yicha qarzdorlik miqdori",
             "type": "text", "required": True},
            {"id": "neustoyka_summa", "label": "To‘lanmagan aliment qarzdorligi yuzasidan hisoblangan neustoyka summasi",
             "type": "text", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizasiga ilova qilinadigan hujjatlar ro‘yxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari bo‘yicha {sud_nomi} sudiga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron pochta: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron pochta: {javobgar_email}



                                                            DA’VO ARIZA

                                                Aliment bo‘yicha neustoykani undirish to‘g‘risida



Men va javobgar o‘rtamizdagi nikoh {fxdyo_nomi} tomonidan {nikoh_sana} kuni {nikoh_raqami}-son bilan qayd etilgan.

Birgalikdagi turmushimizdan {farzand_tugilgan_sana} da tug‘ilgan {farzand_fio} ismli (tug‘ilganlik haqida guvohnoma {guvohnoma_seriya}) farzandimiz bor.

Fuqarolik ishlari bo‘yicha {aliment_sud_nomi} sudining {aliment_sud_sana} dagi {aliment_sud_hujjati}ga asosan javobgardan voyaga yetmagan farzandim {farzand_fio} ning moddiy ta’minoti uchun aliment undirish belgilangan.

Javobgar {tolanmaslik_boshlangan_sana} kunidan {tolanmaslik_oxirgi_sana} kuniga qadar bo‘lgan davrda aliment to‘lamasdan kelmoqda. Ushbu davrda aliment bo‘yicha qarzdorlik {qarzdorlik_miqdori} so‘mni tashkil etadi.

O‘zbekiston Respublikasi Oila Kodeksining 96-moddasiga ko‘ra, ota-ona voyaga yetmagan bolalariga ta’minot berishi shart. Voyaga yetmagan bolalariga ta’minot berish majburiyatini ixtiyoriy ravishda bajarmagan ota (ona)dan sudning hal qiluv qaroriga yoki sud buyrug‘iga asosan aliment undiriladi.

Mazkur Kodeksning 142-moddasiga ko‘ra, aliment to‘lash to‘g‘risidagi kelishuvga muvofiq aliment to‘lashi shart bo‘lgan shaxsning aybi bilan qarz vujudga kelgan bo‘lsa, aybdor shaxs ushbu kelishuvda belgilangan tartibda javobgar bo‘ladi.

Sudning hal qiluv qaroriga ko‘ra aliment to‘lashi shart bo‘lgan shaxsning aybi bilan qarz vujudga kelgan bo‘lsa, aybdor shaxs kechiktirilgan har bir kun uchun to‘lanmay qolgan aliment summasining o‘ndan bir foizi miqdorida aliment oluvchiga neustoyka to‘laydi.

Aliment oluvchi aliment o‘z vaqtida to‘lanmaganligida aybdor aliment to‘lashi shart bo‘lgan shaxsdan aliment to‘lash majburiyatlarini o‘z vaqtida bajarmaganlik oqibatida yetkazilgan barcha zararlarning neustoyka bilan qoplanmagan qismini undirishga ham haqlidir.

Yuqoridagilarga ko‘ra, O‘zbekiston Respublikasi Oila Kodeksining 96, 142-moddalariga hamda O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan



                                                            SO‘RAYMAN:



Javobgar {javobgar_fio} dan farzandim {farzand_fio} ning moddiy ta’minoti uchun undirilishi belgilangan aliment bo‘yicha yuzaga kelgan {qarzdorlik_miqdori} so‘m qarzdorlik o‘z vaqtida to‘lanmaganligi sababli {neustoyka_summa} so‘m miqdorida neustoyka undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
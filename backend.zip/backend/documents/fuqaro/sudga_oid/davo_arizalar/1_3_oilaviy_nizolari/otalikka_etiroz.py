# 1_3_oilaviy_nizolari/otalikka_etiroz.py
"""
Otalikka e'tiroz bildirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-016": {
        "nomi": "Otalikka e'tiroz bildirish to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 58-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Otalikka e'tiroz bildirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_sana", "label": "Bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_guvohnoma_seriya", "label": "Tug'ilganlik haqida guvohnoma seriyasi", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_raqami", "label": "Tug'ilganlik haqida guvohnoma raqami", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_fhydo", "label": "Tug'ilganlik haqida guvohnoma bergan FHDYO bo'limi",
             "type": "text", "required": True},

            # E'TIROZ ASOSLARI
            {"id": "etiroz_asoslari",
             "label": "Otalikka e'tiroz bildirish uchun asoslar (bolaning otasi emasligi haqidagi dalillar, DNK ekspertizasi natijalari va boshqalar)",
             "type": "textarea", "required": True},
        ],
        "shablon": """
***
                                                                                        Fuqarolik ishlari boʻyicha
                                                                                        {sud_nomi}ga
                            
                                                                                        Daʼvogar: {davogar_fio}
                                                                                        Manzil: {davogar_manzil}
                                                                                        Telefon: {davogar_telefon}
                                                                                        E-mail: {davogar_email}
                                                                                        
                                                                                        Javobgar: {javobgar_fio}
                                                                                        Manzil: {javobgar_manzil}
                                                                                        Telefon: {javobgar_telefon}
                                                                                        E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                                Otalikka e'tiroz bildirish to'g'risida



Men va javobgar oʻrtasida fuqarolik holati dalolatnomalarini yozish organida {bola_tugilgan_sana} kuni tugʻilgan {bola_fio} ismli bolaning tugʻilganligi haqidagi qayd etilgan.

{bola_fio} ismli bolaning tugʻilganlik haqidagi guvohnomasida (seriyasi {bola_guvohnoma_seriya} N {bola_guvohnoma_raqami}, {bola_guvohnoma_fhydo} tomonidan berilgan) uning otasi deb men koʻrsatilganman.

Biroq, {etiroz_asoslari}. Shuning uchun men bolaning otasi emasman.

Oʻzbekiston Respublikasi Oila Kodeksining 58-moddasiga koʻra, ota-onalik qayd etilgan shaxs yozuvdagi ota-onalikka eʼtiroz bildirishga haqli.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Oila Kodeksining 58-moddasiga asosan



                                                              SOʻRAYMAN:



{bola_fio} ismli bolaning tugʻilganlik haqidagi guvohnomasidagi meni otaligim haqidagi yozuvni haqiqiy emas deb topishingizni va uni oʻzgartirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Tugʻilganlik haqida guvohnoma nusxasi
3. Otalikka eʼtiroz bildirishga asos boʻlgan dalillar (DNK ekspertizasi va boshqalar)
4. Ishonchnoma nusxasi (daʼvo ariza ishonchli vakil tomonidan berilgan taqdirda)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
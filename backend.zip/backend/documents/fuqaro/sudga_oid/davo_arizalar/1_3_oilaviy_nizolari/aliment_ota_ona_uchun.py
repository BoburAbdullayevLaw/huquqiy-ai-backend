# 1_3_oilaviy_nizolari/aliment_ota_ona_uchun.py
"""
Ota-onani ta'minlash uchun aliment undirish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ON-001": {
        "nomi": "Ota-onani ta'minlash uchun aliment undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Oila Kodeksi 109, 110-moddalar, Konstitutsiya 80-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ota-onani ta'minlash uchun aliment undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # TURMUSH O'RTOG'I
            {"id": "turmush_ortogi_fio", "label": "Daʼvogarning turmush o‘rtog‘ining F.I.O.", "type": "text",
             "required": True},
            {"id": "turmush_qurgan_sana", "label": "Daʼvogar va uning turmush o‘rtog‘i turmush qurgan sana",
             "type": "date", "required": True},
            {"id": "farzandlar_soni", "label": "Daʼvogar va turmush o‘rtog‘ining farzandlari soni", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Arizaga ilova qilinayotgan hujjatlar ro‘yxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi} sudiga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            E-mail: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            E-mail: {javobgar_email}



Daʼvo mazmuni: Mening ta’minotim uchun farzandim {javobgar_fio} dan aliment to‘lovlari undirish to‘g‘risida



                                                            DA’VO ARIZA

                                                Ota-onani ta’minlash uchun aliment undirish to‘g‘risida



Men va turmush o‘rtog‘im {turmush_ortogi_fio} {turmush_qurgan_sana} kuni turmush qurganmiz. Birgalikdagi turmushimizdan {farzandlar_soni} nafar farzandimiz bor. Biz farzandlarimizni moddiy tomondan to‘liq ta’minlab, voyaga yetkazganmiz. Farzandlarimiz mehnatga layoqatli bo‘lib, mehnat faoliyati bilan shug‘ullanib kelishadi.

Hozirgi kunda men va turmush o‘rtog‘im {turmush_ortogi_fio} mehnatga layoqatsizmiz. Shu sababli moddiy ta’minotga muhtojmiz.

Farzandimiz {javobgar_fio} dan ixtiyoriy ravishda bizni moddiy jihatdan ta’minlashini so‘ragan bo‘lsakda, bizni moddiy jihatdan ta’minlamasdan, o‘zining farzandlik burchini bajarmasdan kelmoqda.

O‘zbekiston Respublikasi Konstitutsiyasining 80-moddasiga ko‘ra, voyaga yetgan mehnatga layoqatli farzandlar o‘z ota-onalari haqida g‘amxo‘rlik qilishga majburdirlar.

O‘zbekiston Respublikasi Oila Kodeksining 109-moddasida voyaga yetgan, mehnatga layoqatli bolalar mehnatga layoqatsiz, yordamga muhtoj o‘z ota-onasiga ta’minot berishlari va ular to‘g‘risida g‘amxo‘rlik qilishlari shartligi belgilangan.

Shuningdek, mazkur kodeksning 110-moddasiga ko‘ra, voyaga yetgan, mehnatga layoqatli bolalar o‘z ota-onasiga ixtiyoriy ravishda moddiy yordam berishdan bo‘yin tovlasalar, ta’minot miqdori bolalarning oilaviy va moddiy ahvolini hisobga olgan holda sudning hal qiluv qaroriga asosan belgilanadi.

Voyaga yetgan, mehnatga layoqatli bolalardan aliment undirish nizosi uzil-kesil hal bo‘lguniga qadar sudya shu nizo bo‘yicha vaqtincha to‘lab turilishi lozim bo‘lgan summani ko‘rsatib, ajrim chiqarishi mumkin.

Yuqoridagilarga ko‘ra, O‘zbekiston Respublikasi Oila Kodeksining 109, 110-moddalari hamda O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan



                                                            SO‘RAYMAN:



1. Farzandimiz {javobgar_fio} dan men va turmush o‘rtog‘imning ta’minoti uchun qonunchilikda belgilangan miqdorda aliment undirish to‘g‘risida hal qiluv qarori qabul qilishingizni.

2. Aliment undirish nizosi uzil-kesil hal bo‘lguniga qadar javobgardan bizning ta’minotimiz uchun vaqtincha to‘lab turilishi lozim bo‘lgan summa to‘g‘risida ajrim chiqarishingizni.

3. Mazkur ish ko‘riladigan vaqt va joy haqida mening yashash manzilimga xabar berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.



Izoh: Daʼvo arizaga ish holatiga oid, daʼvo arizani asoslovchi barcha hujjatlar, daʼvo ariza nusxasi taraflarga yuborilganligini, davlat boji to‘langanligini tasdiqlovchi hujjatlar va boshqa hujjatlar ilova qilinishi lozim.
***
"""
    }
}
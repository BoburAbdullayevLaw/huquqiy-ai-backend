# 1_3_oilaviy_nizolari/ota_ona_alohida_yashaganda_bola_yashash_joyi.py
"""
Ota-ona alohida yashagan holda bolalarning yashash joyini belgilash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-021": {
        "nomi": "Ota-ona alohida yashagan holda bolalarning yashash joyini belgilash to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 73-75-moddalar, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ota-ona alohida yashagan holda bolalarning yashash joyini belgilash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Nikoh tuzilgan sana", "type": "date", "required": True},
            {"id": "nikoh_guvohnoma_yil", "label": "Nikoh guvohnomasi berilgan yil", "type": "text", "required": True},
            {"id": "nikoh_guvohnoma_raqami", "label": "Nikoh guvohnomasi raqami", "type": "text", "required": True},

            # AJRALISH MA'LUMOTLARI
            {"id": "ajralish_tartibi", "label": "Ajralish tartibi (sud yoki FHDYO)", "type": "text", "required": True},

            # BOLALAR MA'LUMOTLARI
            {"id": "bola1_tugilgan_yil", "label": "1-bolaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "bola1_fio", "label": "1-bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola1_guvohnoma_yil", "label": "1-bolaning tug'ilganlik guvohnomasi berilgan yil", "type": "text",
             "required": True},
            {"id": "bola1_guvohnoma_raqami", "label": "1-bolaning tug'ilganlik guvohnomasi raqami", "type": "text",
             "required": True},

            {"id": "bola2_tugilgan_yil", "label": "2-bolaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "bola2_fio", "label": "2-bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola2_guvohnoma_yil", "label": "2-bolaning tug'ilganlik guvohnomasi berilgan yil", "type": "text",
             "required": True},
            {"id": "bola2_guvohnoma_raqami", "label": "2-bolaning tug'ilganlik guvohnomasi raqami", "type": "text",
             "required": True},

            # JAVOBGAR TARBIYASIDAGI BOLA
            {"id": "javobgar_tarbiyasidagi_bola", "label": "Javobgar tarbiyasidagi bolaning F.I.O.", "type": "text",
             "required": True},

            # AJRALISH SABABI
            {"id": "ajralish_sababi", "label": "Ajralish sababi", "type": "textarea", "required": True},
            {"id": "ajralish_sana", "label": "Ajralishgan sana (yil)", "type": "text", "required": True},

            # JAVOBGARNING SALBIY TOMONLARI
            {"id": "javobgar_salbiy_holatlari",
             "label": "Javobgarning bola ta'lim va tarbiyasiga salbiy ta'sir ko'rsatadigan holatlari",
             "type": "textarea", "required": True},

            # TASDIQLOVCHI FAKTLAR
            {"id": "tasdiqlovchi_faktlar",
             "label": "Mazkur holatlarni tasdiqlovchi faktlar (MFY ma'lumotnomalari, fotosuratlar va boshqalar)",
             "type": "textarea", "required": True},

            # DA'VOGARNING UY MANZILI
            {"id": "davogar_uy_manzili", "label": "Da'vogarning uy manzili", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                                                Fuqarolik ishlari boʻyicha
                                                                                {sud_nomi}ga
                    
                                                                                Daʼvogar: {davogar_fio}
                                                                                Manzil: {davogar_manzil}
                                                                                
                                                                                Javobgar: {javobgar_fio}
                                                                                Manzil: {javobgar_manzil}



                                                              DA'VO ARIZASI

                        Ota-ona alohida yashagan holda bolalarning yashash joyini belgilash to'g'risida



Men {davogar_fio} va javobgar {javobgar_fio} bilan {nikoh_sana} kuni qonuniy nikohdan oʻtganmiz. Nikohimiz tuzilganligi haqida {nikoh_guvohnoma_yil} yilda № {nikoh_guvohnoma_raqami} sonli guvohnoma berilgan.

Birgalikdagi turmushimizdan {bola1_tugilgan_yil} yilda tugʻilgan {bola1_fio} va {bola2_tugilgan_yil} yilda tugʻilgan {bola2_fio} ismli farzandlarimiz bor. Farzandlarimizga {bola1_guvohnoma_yil} yilda № {bola1_guvohnoma_raqami} va {bola2_guvohnoma_yil} yilda № {bola2_guvohnoma_raqami} tugʻilganlik haqida guvohnomalar berilgan.

Javobgar {javobgar_fio} bilan {ajralish_tartibi} tartibida ajralganman.

Javobgar bilan oʻzaro kelishmovchiliklar sababli birga yashamaymiz. Chunki {ajralish_sababi}.

{ajralish_sana} yildan boshlab javobgar bilan er-xotinlik munosabatlari tugatilgan.

Farzandlarimdan biri – {javobgar_tarbiyasidagi_bola} ismli bolam javobgarning tarbiyasida.

Javobgar tarbiyasidagi farzandimning tarbiyasi, taʼlimi olishi, moddiy taʼminoti va bolaning doimiy yashash joyi yuzasidan javobgar bilan kelishuvga erisha olmadik.

{javobgar_tarbiyasidagi_bola} ismli farzandim turli joylarda javobgar bilan yashab kelmoqda. Bu holat farzandim uchun taʼlim va tarbiyasi uchun {javobgar_salbiy_holatlari} kabi salbiy holatlarni keltirib chiqarmoqda.

Mazkur holatlarni quyidagi faktlar ham tasdiqlaydi: {tasdiqlovchi_faktlar}.

Javobgarga nisbatan farzandimning mehri yoʻqligi, mening tarbiyamdagi farzandimga bogʻlanib qolganligi, farzandim bilim olishi, oila bagʻrida mehr bilan tarbiyalanishi zarur. Mening uy-joyimda farzandim uchun barcha imkoniyatlar mavjud. Hozirda javobgar farzandim bilan birga yashashimga qarshilik koʻrsatib, bolaga boʻlgan huquqlarimni buzmoqda.

Oʻzbekiston Respublikasi Oila kodeksining 73-moddasiga asosan ota-ona oʻz bolalarini tarbiyalash huquqiga ega va tarbiyalashi shart. Ota-ona oʻz bolalarining tarbiyasi va kamoloti uchun javobgardir. Ular oʻz bolalarining sogʻligʻi, jismoniy, ruhiy, maʼnaviy va axloqiy kamoloti haqida gʻamxoʻrlik qilishlari shart.

Qayd qilingan holatlar va qonun talabidan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalari, Oʻzbekiston Respublikasi Oila kodeksining 73-75-moddasiga asosan,



                                                              SOʻRAYMAN:



{javobgar_tarbiyasidagi_bola} ismli farzandimning yashash joyi sifatida oʻzimning nomimda boʻlgan {davogar_uy_manzili} manzilidagi uy-joyni belgilab berishingizni.



Ilova:
- Nikoh tuzilganligi haqidagi guvohnoma nusxasi
- Bolalarning tugʻilganligi toʻgʻrisidagi guvohnoma nusxalari
- Daʼvogarning daromadlari haqidagi maʼlumotnoma
- Javobgarning daromadlari haqidagi maʼlumotnoma
- Daʼvo ariza nusxasi
- Davlat boji toʻlanganligi toʻgʻrisida kvitansiya



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
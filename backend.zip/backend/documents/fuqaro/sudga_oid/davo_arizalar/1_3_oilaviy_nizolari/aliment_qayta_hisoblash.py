# 1_3_oilaviy_nizolari/aliment_qayta_hisoblash.py
"""
Alimentni qayta hisoblash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-010": {
        "nomi": "Alimentni qayta hisoblash to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 99-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Alimentni qayta hisoblash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "fhydo_nomi", "label": "Nikohni qayd etgan FHDYO bo'limi nomi", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Nikoh qayd etilgan sana", "type": "date", "required": True},
            {"id": "nikoh_raqami", "label": "Nikoh dalolatnoma raqami", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_sana", "label": "Bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_guvohnoma_seriya", "label": "Tug'ilganlik haqida guvohnoma seriyasi", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_raqami", "label": "Tug'ilganlik haqida guvohnoma raqami", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_fhydo", "label": "Tug'ilganlik haqida guvohnoma bergan FHDYO bo'limi",
             "type": "text", "required": True},

            # SUD BUYRUG'I MA'LUMOTLARI
            {"id": "buyruq_sud_nomi", "label": "Sud buyrug'ini chiqargan sud nomi", "type": "text", "required": True},
            {"id": "buyruq_sana", "label": "Sud buyrug'i chiqarilgan sana", "type": "date", "required": True},

            # BEKOR QILISH
            {"id": "bekor_qilish_sana", "label": "Sud buyrug'ini bekor qilish haqidagi ajrim sanasi", "type": "date",
             "required": True},
        ],
        "shablon": """
***
                                                                                Fuqarolik ishlari boʻyicha
                                                                                {sud_nomi}ga
                    
                                                                                Daʼvogar: {davogar_fio}
                                                                                Manzil: {davogar_manzil}
                                                                                Telefon: {davogar_telefon}
                                                                                E-mail: {davogar_email}
                                                                                
                                                                                Javobgar: {javobgar_fio}
                                                                                Manzil: {javobgar_manzil}
                                                                                Telefon: {javobgar_telefon}
                                                                                E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                                Alimentni qayta hisoblash to'g'risida



Men va javobgar oʻrtamizdagi qonuniy nikoh {fhydo_nomi} tomonidan {nikoh_sana} kuni {nikoh_raqami}-son bilan qayd etilgan.

Birgalikdagi turmushimizdan {bola_tugilgan_sana} kuni tugʻilgan {bola_fio} ismli (tugʻilganlik haqida guvohnoma {bola_guvohnoma_seriya} {bola_guvohnoma_raqami}, {bola_guvohnoma_fhydo} tomonidan berilgan) farzandimiz bor.

Fuqarolik ishlari boʻyicha {buyruq_sud_nomi} sudining {buyruq_sana} dagi sud buyrugʻiga asosan javobgardan aliment undirish belgilangan edi.

Sud buyrugʻi fuqarolik ishlari boʻyicha {sud_nomi} sudining {bekor_qilish_sana} dagi ajrimiga asosan bekor qilindi.

Hozirgi kunda javobgar farzandimni ixtiyoriy ravishda moddiy taʼminlamayapti.

Javobgar bilan oʻrtamizda farzandimizning moddiy taʼminoti haqida kelishuv mavjud emas.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Oila Kodeksining 99-moddasiga asosan



                                                              SOʻRAYMAN:



{bola_tugilgan_sana} da tugʻilgan javobgar {javobgar_fio} dan {bola_tugilgan_sana} da tugʻilgan {bola_fio} ismli farzandimning moddiy taʼminoti uchun aliment undirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Nikoh qayd etilganligi haqida guvohnoma
3. Tugʻilganlik haqida guvohnoma nusxasi
4. Sud buyrugʻini bekor qilish haqidagi sud ajrimi nusxasi
5. Ishonchnoma nusxasi (daʼvo ariza ishonchli vakil tomonidan berilgan taqdirda)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
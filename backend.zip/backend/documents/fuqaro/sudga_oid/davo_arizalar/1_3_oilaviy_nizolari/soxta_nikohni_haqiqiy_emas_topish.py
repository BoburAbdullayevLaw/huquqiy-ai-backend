# 1_3_oilaviy_nizolari/soxta_nikohni_haqiqiy_emas_topish.py
"""
Soxta nikohni haqiqiy emas deb topish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-024": {
        "nomi": "Soxta nikohni haqiqiy emas deb topish to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 54-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Soxta nikohni haqiqiy emas deb topish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Nikoh qayd etilgan sana (kun, oy, yil)", "type": "date", "required": True},
            {"id": "nikoh_fhydo", "label": "Nikoh qayd etilgan FHDYO bo'limi (tuman, shahar)", "type": "text",
             "required": True},
            {"id": "nikoh_raqami", "label": "Nikoh qayd etish raqami", "type": "text", "required": True},

            # FARZANDLAR
            {"id": "farzandlar_soni", "label": "Farzandlar soni", "type": "text", "required": True},
            {"id": "farzandlar_bor", "label": "Farzandlar bormi", "type": "select", "options": ["bor", "yo'q"],
             "required": True},

            # SOXTA NIKOH SABABLARI
            {"id": "soxta_nikoh_sabablari",
             "label": "Nikohning soxta ekanligi sabablari (oila qurish va birga yashash maqsadi bo'lmaganligi)",
             "type": "textarea", "required": True},
        ],
        "shablon": """
***
                                                                            Fuqarolik ishlari boʻyicha
                                                                            {sud_nomi}ga
                
                                                                            Daʼvogar: {davogar_fio}
                                                                            Manzil: {davogar_manzil}
                                                                            Telefon: {davogar_telefon}
                                                                            
                                                                            Javobgar: {javobgar_fio}
                                                                            Manzil: {javobgar_manzil}
                                                                            Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    Soxta nikohni haqiqiy emas deb topish to'g'risida



Javobgar {javobgar_fio} bilan men {nikoh_sana} kuni {nikoh_fhydo} FHDYO boʻlimida {nikoh_raqami}-son bilan qayd etilgan qonuniy nikohdan oʻtib turmush qurganmiz.

Turmushimiz davrida oʻrtamizda {farzandlar_soni} nafar farzandimiz {farzandlar_bor}.

Men bilan javobgar {javobgar_fio} oila qurish va birga yashash maqsadisiz nikohdan oʻtganligi, {soxta_nikoh_sabablari} bois oʻrtamizdagi nikohni haqiqiy deb boʻlmaydi.

Shu sababli, men va javobgar {javobgar_fio} oʻrtamizda {nikoh_sana} kuni {nikoh_fhydo} FHDYO boʻlimida {nikoh_raqami}-son bilan qayd etilgan nikoh soxta nikoh hisoblanadi.

Yuqoridagilarga asosan hamda Oʻzbekiston Respublikasi Oila kodeksining 54-moddasiga asosan,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} bilan men oʻrtamizda {nikoh_sana} kuni {nikoh_fhydo} FHDYO boʻlimida {nikoh_raqami}-son bilan qayd etilgan soxta nikohni haqiqiy emas deb topishingizni.



Ilova:
1) Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
2) Daʼvo ariza nusxasi
3) Pasport nusxasi
4) Nikoh guvohnomasi nusxasi
5) Yashash joyidagi MFY tomonidan berilgan maʼlumotnomalar
6) Daʼvo talabini asoslovchi boshqa hujjatlar



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {nikoh_sana} yil.
***
"""
    }
}
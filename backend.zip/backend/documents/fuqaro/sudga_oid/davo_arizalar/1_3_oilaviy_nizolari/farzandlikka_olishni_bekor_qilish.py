# 1_3_oilaviy_nizolari/farzandlikka_olishni_bekor_qilish.py
"""
Farzandlikka olishni bekor qilish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-020": {
        "nomi": "Farzandlikka olishni bekor qilish to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 170-173-moddalar, FPK 304-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Farzandlikka olishni bekor qilish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGARLAR MA'LUMOTLARI
            {"id": "javobgar1_fio", "label": "Javobgar 1 (farzandlikka oluvchi) F.I.O.", "type": "text",
             "required": True},
            {"id": "javobgar2_fio", "label": "Javobgar 2 (farzandlikka oluvchi) F.I.O.", "type": "text",
             "required": True},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Nikoh tuzilgan sana", "type": "date", "required": True},
            {"id": "turmush_ortogi_fio", "label": "Marhum turmush o'rtog'ining F.I.O.", "type": "text",
             "required": True},

            # BOLALAR MA'LUMOTLARI
            {"id": "bola1_tugilgan_sana", "label": "1-bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola1_fio", "label": "1-bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola2_tugilgan_sana", "label": "2-bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola2_fio", "label": "2-bolaning F.I.O.", "type": "text", "required": True},

            # TURMUSH O'RTOG'I VAFOTI
            {"id": "vafot_sana", "label": "Turmush o'rtog'ining vafot etgan sanasi", "type": "text", "required": True},
            {"id": "vafot_oy", "label": "Turmush o'rtog'ining vafot etgan oyi", "type": "text", "required": True},

            # FARZANDLIKKA BERISH
            {"id": "hokim_qarori_sana", "label": "Hokim qarori sanasi", "type": "date", "required": True},
            {"id": "hokim_qarori_raqami", "label": "Hokim qarori raqami", "type": "text", "required": True},
            {"id": "farzandlikka_berilgan_bola_fio", "label": "Farzandlikka berilgan bolaning F.I.O.", "type": "text",
             "required": True},
            {"id": "farzandlikka_berilgan_bola_sana", "label": "Farzandlikka berilgan bolaning tug'ilgan sanasi",
             "type": "date", "required": True},

            # FARZANDLIKKA OLISH SABABI
            {"id": "farzandlikka_sababi",
             "label": "Farzandlikka berish sababi (nega bola ta'minlay olmaganligi)", "type": "textarea",
             "required": True},

            # BEKOR QILISH SABABLARI
            {"id": "bekor_qilish_sabablari",
             "label": "Farzandlikka olishni bekor qilish sabablari (farzandlikka oluvchilarning majburiyatlarini bajarmasligi, ularning ajrashishi va boshqalar)",
             "type": "textarea", "required": True},

            # BOLANING YANGI MA'LUMOTLARI
            {"id": "yangi_familiya", "label": "Bekor qilingandan keyin bolaning yangi familiyasi", "type": "text",
             "required": True},
            {"id": "yangi_ota_ismi", "label": "Bekor qilingandan keyin bolaning yangi otasining ismi", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                                                            Fuqarolik ishlari boʻyicha
                                                                                            {sud_nomi}ga
                                
                                                                                            Daʼvogar: {davogar_fio}
                                                                                            Manzil: {davogar_manzil}
                                                                                            Telefon: {davogar_telefon}
                                                                                            E-mail: {davogar_email}
                                                                                            
                                                                                            Javobgarlar: {javobgar1_fio}
                                                                                                         {javobgar2_fio}



                                                              DA'VO ARIZASI

                                    Farzandlikka olishni bekor qilish to'g'risida



Men {davogar_fio} marhum turmush oʻrtogʻim {turmush_ortogi_fio} bilan {nikoh_sana} kuni qonuniy nikohdan oʻtgan holda turmush qurganman. Birgalikdagi turmushimizdan {bola1_tugilgan_sana} kuni tugʻilgan {bola1_fio} va {bola2_tugilgan_sana} kuni tugʻilgan {bola2_fio} ismli farzandlarimiz bor.

Turmush oʻrtogʻim {turmush_ortogi_fio} {vafot_sana} yil {vafot_oy} oyida vafot etgan.

Farzandlarimni taʼminlay olmadim. Chunki {farzandlikka_sababi}.

Javobgarlarning, – {javobgar1_fio} va uning turmush oʻrtogʻi {javobgar2_fio}ning birgalikdagi turmushlaridan farzandlari boʻlmaganligi va ularning oilasini saqlab qolish maqsadida {farzandlikka_berilgan_bola_sana} da tugʻilgan {farzandlikka_berilgan_bola_fio} ismli farzandimni ularga farzandlikka berganman. Javobgarlar mendan bolamni farzandlikka olish vaqtida bolaga oʻzlarining farzandlari qarab, tarbiyalashlarini va asrab-avaylashlarini vaʼda berib, bolani mendan farzandlikka olgan boʻlsalar-da, biroq shu kunga qadar javobgarlar bolamni tarbiyasi bilan shugʻullanmasdan kelmoqdalar. Bu bilan javobgarlar oʻz zimmalariga olgan majburiyatlarini lozim darajada bajarmasdan, bolamning kelajagiga befarq munosabatda boʻlib kelayotganliklari meni havotirga solmoqda.

{bekor_qilish_sabablari}

Bu bilan birga ayni vaqtda, javobgarlar oʻrtasida oʻzaro kelishmovchilik mavjud boʻlib, hozirda ularning qonuniy nikohdan ajrashish toʻgʻrisidagi ishlari sud tomonidan koʻrib chiqilmoqda. Mazkur holatlar bolam qarovsiz qolib, javobgarlarning hech biri bolamga oʻz bolasidek munosabatda boʻlishmayapti.

Shu sababli men oʻz farzandimni bunday holatda qarovsiz, oʻziga begona boʻlgan shaxslar bilan yashashiga, bunday sharoitda kamol topishiga ishonmayman.

Oʻzbekiston Respublikasi Oila kodeksining 170-moddasida farzandlikka olinganning ota-onasi, prokuror, vasiylik va homiylik organlari, voyaga yetmaganlar ishi bilan shugʻullanuvchi komissiyalar, shuningdek oʻn olti yoshga toʻlgan farzandlikka olingan bola farzandlikka olishni sud tartibida bekor qilishni talab etish huquqiga ega ekanligi belgilangan.

Qayd qilingan holatlar va qonun talabidan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 304-moddasi, Oʻzbekiston Respublikasi Oila kodeksining 170-173-moddalariga asosan,



                                                              SOʻRAYMAN:



1. {farzandlikka_berilgan_bola_sana} da tugʻilgan {farzandlikka_berilgan_bola_fio}ni javobgarlar {javobgar1_fio} va {javobgar2_fio}ga farzandlikka berish toʻgʻrisidagi hokim qarorini bekor qilishingizni.

2. Bolamning tugʻilishi toʻgʻrisidagi dastlabki yozuvlarni tiklab, dastlabki dalolatnoma yozuviga asosan bolaning familiyasini "{yangi_familiya}", ismini oʻzgarishsiz, otasining ismini "{yangi_ota_ismi}" – deb oʻzgartirgan holda bolaga tugʻilganlik haqida guvohnoma berishni.



Ilova:
1. Daʼvo ariza nusxasi
2. Davlat boji toʻlanganligi haqidagi toʻlov kvitansiyasi
3. Pasport nusxalari
4. Hokim qarori nusxasi
5. Nikoh tuzilganligi haqidagi guvohnoma nusxasi
6. Farzandlarning tugʻilganlik haqidagi guvohnoma nusxalari
7. Turmush oʻrtogʻining vafot etganligi haqida guvohnoma
8. Yashash joyidan MFY maʼlumotnomalari



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
# 1_3_oilaviy_nizolari/bola_bilan_uchrashuv_tartibi.py
"""
Bola bilan ko'rishib turish tartibini belgilash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-019": {
        "nomi": "Bola bilan ko'rishib turish tartibini belgilash to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 66, 71, 76, 77-moddalar, Oliy sud Plenumi 23-sonli qarori, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Bola bilan ko'rishib turish tartibini belgilash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogarlar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMIZ" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # OTA (DA'VOGAR 1)
            {"id": "ota_fio", "label": "Otaning F.I.O. (da'vogar 1)", "type": "text", "required": True},

            # BOSHQQA QARINDOSHLAR (DA'VOGARLAR)
            {"id": "qarindosh1_fio", "label": "Bobo/buvining F.I.O. (da'vogar 2)", "type": "text", "required": True},
            {"id": "qarindosh2_fio", "label": "Boshqa qarindoshning F.I.O. (da'vogar 3)", "type": "text",
             "required": True},

            # JAVOBGAR (ONA)
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O. (ona)", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_tuzilgan_yil", "label": "Nikoh tuzilgan yil", "type": "text", "required": True},
            {"id": "nikoh_tuzilgan_oy", "label": "Nikoh tuzilgan oy", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_yil", "label": "Bolaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "bola_tugilgan_oy", "label": "Bolaning tug'ilgan oyi", "type": "text", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},

            # AJRALISH MA'LUMOTLARI
            {"id": "ajrashgan_yil", "label": "Ajrashgan yil", "type": "text", "required": True},
            {"id": "ajrashgan_oy", "label": "Ajrashgan oy", "type": "text", "required": True},
            {"id": "ajralish_sana", "label": "Ajralish qarori sanasi", "type": "date", "required": True},

            # AJRALISH SABABI
            {"id": "ajralish_sababi", "label": "Ajralish sababi", "type": "textarea", "required": True},

            # UCHRASHUV TARTIBI
            {"id": "uchrashuv_kuni1", "label": "1-uchrashuv kuni", "type": "text", "required": True},
            {"id": "uchrashuv_boshlanish_soat1", "label": "Uchrashuv boshlanish vaqti", "type": "text",
             "required": True},
            {"id": "uchrashuv_kuni2", "label": "2-uchrashuv kuni", "type": "text", "required": True},
            {"id": "uchrashuv_tugash_soat2", "label": "Uchrashuv tugash vaqti", "type": "text", "required": True},

            # UY MANZILI
            {"id": "davogar_uy_manzil", "label": "Da'vogarlarning uy manzili", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

Daʼvogarlar: {ota_fio}
             {qarindosh1_fio}
             {qarindosh2_fio}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}



                                                              DA'VO ARIZASI

                                    (bola bilan ko'rishib turish tartibini belgilash to'g'risida)



Oila kodeksining 71-moddasiga koʻra, ota-ona oʻz bolalariga nisbatan teng huquq va majburiyatlarga egadirlar.

{ota_fio} {nikoh_tuzilgan_yil} yil {nikoh_tuzilgan_oy} oyida {javobgar_fio} bilan qonuniy nikohdan oʻtgan holda oila qurib, ularning birgalikdagi turmushidan {bola_tugilgan_yil} yil {bola_tugilgan_oy} oyida {bola_fio} ismli farzandlari tugʻilgan. Ular {ajrashgan_yil} yil {ajrashgan_oy} oyiga qadar birgalikda yashab, keyinchalik oʻzaro kelishmovchiliklari tufayli fuqarolik ishlari boʻyicha {sud_nomi} sudining {ajralish_sana} dagi hal qiluv qarori bilan qonuniy nikohdan ajratilib, voyaga yetmagan {bola_fio} onasi {javobgar_fio}ning tarbiyasiga qoldirilgan.

Ayni paytda, javobgar {javobgar_fio} alohida yashamoqda. Chunki {ajralish_sababi}.

Garchand, bizlar voyaga yetmagan {bola_fio}ni sogʻinib, u bilan koʻrishish istagida boʻlsakda, biroq javobgar {javobgar_fio} bola bilan koʻrishib, uni oʻz uyimizga olib kelgan holda tarbiyasida ishtirok etishimizga ixtiyoriy ravishda imkoniyat yaratib bermayapti.

Aslida, yuqoridagi qonun talabiga koʻra, bolani tarbiyalashda ota sifatida {ota_fio} ham teng huquqqa ega boʻlsada, ayni paytda bolaning bevosita javobgar {javobgar_fio} tarbiyasida boʻlishi va bolani muayyan vaqtda oʻz uyimizga olib kelgan taqdirda ham ushbu tenglikdan chekinilgan, yaʼni bunda bolaning onasining tarbiyasida koʻproq boʻlishini yaqqol kuzatish mumkin boʻladi.

Oʻzbekiston Respublikasi Oila kodeksining 76-moddasiga koʻra, boladan alohida yashayotgan ota (ona) bola bilan koʻrishish, uning tarbiyasida ishtirok etish va taʼlim olishi masalasini hal etishda qatnashish huquqiga ega.

Bola bilan birga yashayotgan ota (ona) bolaning ota (ona)si bilan koʻrishishiga, agar bunday koʻrishish bolaning jismoniy va ruhiy sogʻligʻiga, axloqiy kamolotiga zarar keltirmasa, qarshilik qilmasligi kerak.

Mazkur kodeksning 77-moddasiga binoan, bobo, buvi, aka-uka, opa-singil va boshqa yaqin qarindoshlar bola bilan koʻrishib turish huquqiga ega.

Binobarin, yuqoridagi qonun talabiga koʻra daʼvogar {ota_fio} ham ota sifatida javobgar bilan bir qatorda bolaga nisbatan teng huquqqa ega boʻlib hisoblanadi, shuningdek, voyaga yetmagan {bola_fio}ning bobo-buvasi va boshqa yaqin qarindoshlari sifatida bizning ham u bilan koʻrishib uning tarbiyasida ishtirok etishga boʻlgan huquqimiz qonun bilan mustahkamlangan. Javobgarning toʻsqinligi tufayli oʻz huquqlarimizdan sud orqali foydalanishga qaror qilib, ushbu mazmundagi daʼvo arizasi bilan sudga murojaat qilishga majbur boʻlmoqdamiz.

Qayd qilingan holatlar va qonun talabidan kelib chiqib, Oʻzbekiston Respublikasi Oila kodeksining 66, 71, 76, 77-moddalari, Oʻzbekiston Respublikasi Oliy sudi Plenumining 1998 yildagi "Bolalar tarbiyasi bilan bogʻliq boʻlgan nizolarni hal qilishda sudlar tomonidan qonunlarni qoʻllash amaliyoti toʻgʻrisida"gi 23-sonli qaroriga asoslanib,



                                                              SOʻRAYMIZ:



Javobgar {javobgar_fio}ning tarbiyasida boʻlgan voyaga yetmagan {bola_tugilgan_yil} yil {bola_tugilgan_oy} oyida tugʻilgan {bola_fio} ismli bola bilan bizni koʻrishib, uning tarbiyasida ishtirok etish tartibini har haftaning {uchrashuv_kuni1} kuni soat {uchrashuv_boshlanish_soat1} dan {uchrashuv_kuni2} kuni soat {uchrashuv_tugash_soat2} ga qadar oʻz uyimiz, yaʼni {davogar_uy_manzil} manziliga olib ketish sharti bilan belgilab berishingizni.



Ilova:
1) Daʼvo ariza nusxasi
2) Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
3) Nikohdan ajrashish haqidagi sud qarori nusxasi
4) Pasportlar nusxasi
5) Tugʻilganlik haqidagi guvohnomalar nusxasi
6) Voyaga yetmagan bolaning tugʻilish guvohnomasi nusxasi
7) Mahalladan turar joy toʻgʻrisida maʼlumot



                                                              Daʼvogarlar: {ota_fio}
                                                                           _________________
                                                                               (imzo)

                                                                           {qarindosh1_fio}
                                                                           _________________
                                                                               (imzo)

                                                                           {qarindosh2_fio}
                                                                           _________________
                                                                               (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
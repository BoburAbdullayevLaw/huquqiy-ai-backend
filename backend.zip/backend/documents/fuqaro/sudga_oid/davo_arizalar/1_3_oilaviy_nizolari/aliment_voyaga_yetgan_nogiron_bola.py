# 1_3_oilaviy_nizolari/aliment_voyaga_yetgan_nogiron_bola.py
"""
Voyaga yetgan mehnatga layoqatsiz bola uchun aliment undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-013": {
        "nomi": "Voyaga yetgan mehnatga layoqatsiz bola uchun aliment undirish to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 108-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Voyaga yetgan mehnatga layoqatsiz bola uchun aliment undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI (OTA-ONA YOKI QARINDOSH)
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGARNING TUG'ILGAN SANASI VA QARINDOSHLIK DARAJASI
            {"id": "javobgar_tugilgan_sana", "label": "Javobgarning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "javobgar_qarindoshlik", "label": "Javobgarning qarindoshlik darajasi (ota, ona, bobo, buvi, aka, uka, opa, singil)",
             "type": "text", "required": True},

            # MEHNATGA LAYOQATSIZLIK SABABI
            {"id": "nogironlik_sababi", "label": "Mehnatga layoqatsizlik sababi", "type": "textarea",
             "required": True},

            # ALIMENT SUMMASI
            {"id": "aliment_summa", "label": "Talab qilinayotgan oylik aliment summasi", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            E-mail: {davogar_email}
                                                            
                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                    Voyaga yetgan mehnatga layoqatsiz bola uchun aliment undirish to'g'risida



Men voyaga yetgan boʻlsamda, {nogironlik_sababi} sababli mehnatga layoqatsizman.

Javobgar {javobgar_tugilgan_sana} da tugʻilgan {javobgar_fio} {javobgar_qarindoshlik} mehnatga layoqatli, lekin meni ixtiyoriy ravishda moddiy taʼminlamayapti.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Oila Kodeksining 108-moddasiga asosan



                                                              SOʻRAYMAN:



{javobgar_tugilgan_sana} da tugʻilgan {javobgar_qarindoshlik} {javobgar_fio} dan moddiy taʼminotim uchun har oyda pul toʻlanadigan {aliment_summa} soʻm qatʼiy summada aliment undirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Mehnatga layoqatsizlikni tasdiqlovchi hujjat
3. Tugʻilganlik haqida guvohnoma nusxasi
4. Ishonchnoma nusxasi (daʼvo ariza ishonchli vakil tomonidan berilgan taqdirda)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
# 1_3_oilaviy_nizolari/mulkni_bolish.py
"""
Mol-mulkni bo'lish haqida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-014": {
        "nomi": "Mol-mulkni bo'lish haqida da'vo arizasi",
        "jpk": "Oila Kodeksi 23-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mol-mulkni bo'lish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "fhydo_nomi", "label": "Nikohni qayd etgan FHDYO bo'limi nomi", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Nikoh qayd etilgan sana", "type": "date", "required": True},
            {"id": "nikoh_raqami", "label": "Nikoh dalolatnoma raqami", "type": "text", "required": True},

            # MULK MA'LUMOTLARI
            {"id": "mulk_sotib_olingan_sana", "label": "Mulk sotib olingan sana", "type": "date", "required": True},
            {"id": "mulk_hujjati", "label": "Mulk huquqini tasdiqlovchi hujjat (oldi-sotdi shartnomasi, uy-joyga nisbatan egalik huquqini belgilash haqida hokim qarori va h.k.)",
             "type": "text", "required": True},
            {"id": "mulk_royxati", "label": "Bo'linishi so'ralayotgan mol-mulklar ro'yxati", "type": "textarea",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}
E-mail: {davogar_email}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}
E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                                Mol-mulkni bo'lish haqida



Men va javobgar oʻrtamizdagi qonuniy nikoh {fhydo_nomi} tomonidan {nikoh_sana} kuni {nikoh_raqami}-son bilan qayd etilgan.

Oʻrtamizda nikoh shartnomasi tuzilmagan. Javobgar bilan nikohimiz davomida {mulk_sotib_olingan_sana} kuni {mulk_hujjati}ga asosan {mulk_royxati} ni sotib olganmiz.

Javobgar bilan birgalikdagi mulkni boʻlish haqida kelishuv mavjud emas.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Oila Kodeksining 23-moddasiga asosan



                                                              SOʻRAYMAN:



{mulk_royxati} ni umumiy birgalikdagi mulk deb topib, ulushimni ajratishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Nikoh qayd etilganligi haqida guvohnoma
3. Davlat boji toʻlanganligini tasdiqlovchi hujjat
4. Mol-mulkka mulk huquqini tasdiqlovchi hujjat nusxasi
5. Ishonchnoma nusxasi (daʼvo ariza ishonchli vakil tomonidan berilgan taqdirda)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
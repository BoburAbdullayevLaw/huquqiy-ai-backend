# 1_3_oilaviy_nizolari/aliment_qatiy_summa.py
"""
Alimentni qat'iy summa da undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-011": {
        "nomi": "Alimentni qat'iy summa da undirish to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 102-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Alimentni qat'iy summa da undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning E-mail manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning E-mail manzili", "type": "email", "required": False},

            # NIKOH MA'LUMOTLARI
            {"id": "fhydo_nomi", "label": "Nikohni qayd etgan FHDYO bo'limi nomi", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Nikoh qayd etilgan sana", "type": "date", "required": True},
            {"id": "nikoh_raqami", "label": "Nikoh dalolatnoma raqami", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_sana", "label": "Bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},
            {"id": "bola_guvohnoma_seriya", "label": "Tug'ilganlik haqida guvohnoma seriyasi", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_raqami", "label": "Tug'ilganlik haqida guvohnoma raqami", "type": "text",
             "required": True},
            {"id": "bola_guvohnoma_fhydo", "label": "Tug'ilganlik haqida guvohnoma bergan FHDYO bo'limi",
             "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "sud_qaror_sud_nomi", "label": "Sud qarorini chiqargan sud nomi", "type": "text", "required": True},
            {"id": "sud_qaror_sana", "label": "Sud qarori qabul qilingan sana", "type": "date", "required": True},
            {"id": "sud_qaror_turi", "label": "Sud qarorining turi (sud buyrug'i, hal qiluv qarori)", "type": "text",
             "required": True},

            # QAT'IY SUMMA ASOSLARI
            {"id": "qatiy_summa_asoslari",
             "label": "Aliment miqdorini qat'iy summada belgilashga asoslar (ish haqi va boshqa daromadning doimo bir xil bo'lmasligi, o'zgarib turishi, daromadning bir qismini natura tarzda olishi, rasman belgilangan ish haqi yoki daromadga ega bo'lmaslik)",
             "type": "textarea", "required": True},

            # YANGI SUMMA
            {"id": "yangi_summa", "label": "Talab qilinayotgan qat'iy aliment summasi", "type": "text",
             "required": True},

            # QAROR KIMGA NISBATAN
            {"id": "qaror_turi", "label": "Qaror kimga nisbatan", "type": "select",
             "options": ["menga nisbatan", "javobgarga nisbatan"], "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}
E-mail: {davogar_email}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}
E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                                Alimentni qat'iy summada undirish to'g'risida



Men va javobgar oʻrtamizdagi qonuniy nikoh {fhydo_nomi} tomonidan {nikoh_sana} kuni {nikoh_raqami}-son bilan qayd etilgan.

Birgalikdagi turmushimizdan {bola_tugilgan_sana} kuni tugʻilgan {bola_fio} ismli (tugʻilganlik haqida guvohnoma {bola_guvohnoma_seriya} {bola_guvohnoma_raqami}, {bola_guvohnoma_fhydo} tomonidan berilgan) farzandimiz bor.

Fuqarolik ishlari boʻyicha {sud_qaror_sud_nomi} sudining {sud_qaror_sana} dagi {sud_qaror_turi}ga asosan {qaror_turi} voyaga yetmagan {bola_tugilgan_sana} da tugʻilgan {bola_fio} ismli farzandimning moddiy taʼminoti uchun aliment undirish belgilangan.

Endilikda {qatiy_summa_asoslari} sababli farzandimni moddiy taʼminoti uchun yetarli miqdorda aliment toʻlay olmayman.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Oila Kodeksining 102-moddasiga asosan



                                                              SOʻRAYMAN:



{bola_tugilgan_sana} da tugʻilgan {qaror_turi} {javobgar_fio} foydasiga {bola_tugilgan_sana} da tugʻilgan {bola_fio} ismli farzandimning moddiy taʼminoti uchun {sud_qaror_sud_nomi} sudining {sud_qaror_sana} dagi {sud_qaror_turi}ga asosan undirilishi belgilangan aliment miqdorini {yangi_summa} soʻm qatʼiy summada belgilashingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Davlat boji toʻlanganligini tasdiqlovchi hujjat (daʼvo ariza qarzdor tomonidan berilganda)
3. Sud qarori nusxasi
4. Aliment miqdorini qatʼiy summada belgilashga asos boʻlgan holatlarni tasdiqlovchi hujjatlar
5. Ishonchnoma nusxasi (daʼvo ariza ishonchli vakil tomonidan berilgan taqdirda)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
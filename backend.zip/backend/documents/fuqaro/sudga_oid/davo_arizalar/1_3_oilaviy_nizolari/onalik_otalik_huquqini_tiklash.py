# 1_3_oilaviy_nizolari/onalik_otalik_huquqini_tiklash.py
"""
Onalik (otalik) huquqini tiklash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ON-022": {
        "nomi": "Onalik (otalik) huquqini tiklash to'g'risida da'vo arizasi",
        "jpk": "Oila Kodeksi 73, 82-moddalar, Oliy sud Plenumi 23-sonli qarori 20-21-bandlar, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Onalik (otalik) huquqini tiklash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},

            # JAVOBGAR (vasiylik organi)
            {"id": "javobgar_nomi", "label": "Javobgar (vasiylik va homiylik organi nomi)", "type": "text",
             "required": True},

            # NIKOH MA'LUMOTLARI
            {"id": "nikoh_sana", "label": "Nikoh tuzilgan sana", "type": "date", "required": True},
            {"id": "turmush_ortogi_fio", "label": "Turmush o'rtog'ining F.I.O.", "type": "text", "required": True},

            # BOLA MA'LUMOTLARI
            {"id": "bola_tugilgan_sana", "label": "Bolaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "bola_fio", "label": "Bolaning F.I.O.", "type": "text", "required": True},

            # HUQUQDAN MAHRUM QILISH SABABI
            {"id": "ta_minlay_olmaslik_sababi",
             "label": "Farzandni ta'minlay olmaslik sababi (huquqdan mahrum qilinishiga olib kelgan holatlar)",
             "type": "textarea", "required": True},

            # DAVLAT MUASSASASIGA JOYLASHTIRISH
            {"id": "hokim_qarori_sana", "label": "Hokim qarori sanasi (bolani muassasaga joylashtirish)", "type": "date",
             "required": True},
            {"id": "hokim_qarori_raqami", "label": "Hokim qarori raqami", "type": "text", "required": True},
            {"id": "muassasa_nomi", "label": "Bola joylashtirilgan muassasa nomi", "type": "text", "required": True},
            {"id": "muassasa_manzili", "label": "Muassasa joylashgan shahar (tuman)", "type": "text", "required": True},

            # SUD QARORLARI
            {"id": "huquqdan_mahrum_qilish_sana",
             "label": "Onalik (otalik) huquqidan mahrum qilish haqidagi sud qarori sanasi", "type": "date",
             "required": True},
            {"id": "aliment_undirish_sana", "label": "Aliment undirish haqidagi sud qarori sanasi", "type": "date",
             "required": True},

            # TIKLASH UCHUN ASOSLAR
            {"id": "tiklash_asoslari",
             "label": "Huquqni tiklash uchun asoslar (qanday sabablar bartaraf etilganligi, yaratilgan sharoitlar)",
             "type": "textarea", "required": True},
        ],
        "shablon": """
***
                                                                                Fuqarolik ishlari boʻyicha
                                                                                {sud_nomi}ga
                    
                                                                                Daʼvogar: {davogar_fio}
                                                                                
                                                                                Javobgar: {javobgar_nomi}



                                                              DA'VO ARIZASI

                                    Onalik (otalik) huquqini tiklash to'g'risida



Oʻzbekiston Respublikasi Oila kodeksining 73-moddasiga muvofiq ota-ona oʻz bolalarini tarbiyalash huquqiga ega va tarbiyalashi shart. Ota-ona oʻz bolalarining tarbiyasi va kamoloti uchun javobgardir. Ular oʻz bolalarining sogʻligʻi, jismoniy, ruhiy, maʼnaviy va axloqiy kamoloti haqida gʻamxoʻrlik qilishlari shartligi belgilangan.

Men {davogar_fio} {nikoh_sana} kuni {turmush_ortogi_fio} bilan qonuniy nikohdan oʻtib turmush qurdim. Birgalikdagi turmushimizdan {bola_tugilgan_sana} kuni {bola_fio} ismli farzandimiz tugʻildi.

Farzandimni yetarlicha taʼminlay olmaganman. Chunki {ta_minlay_olmaslik_sababi}.

{muassasa_manzili} shahridagi vasiylik va homiylik organi tomonidan voyaga yetmagan farzandim {bola_tugilgan_sana} kuni tugʻilgan {bola_fio}ni tuman hokimining {hokim_qarori_sana} dagi {hokim_qarori_raqami}-sonli qarori bilan {muassasa_manzili} shahridagi {muassasa_nomi} ga joylashtirilgan. Chunki mening hovlimda sharoit yetarli emas edi, farzandim qarovsiz qolib ketgan hamda bobo-buvasi bola tarbiyasiga qiynalganligi uchun vasiylik va homiylik organi bolani davlat muassasasiga topshirgan.

Vasiylik va homiylik organi fuqarolik ishlari boʻyicha {sud_nomi} sudining {huquqdan_mahrum_qilish_sana} dagi hal qiluv qaroriga asosan aliment va {aliment_undirish_sana} dagi hal qiluv qaroriga asosan men voyaga yetmagan farzandimga nisbatan onalik huquqidan mahrum qilinganman.

Hozirda {tiklash_asoslari}. Voyaga yetmagan farzandim yashashi uchun qulay sharoitlar yaratdim. Voyaga yetmagan farzandim uchun aliment toʻlab kelayapman va farzandim ahvolidan xabardor boʻlib turaman. Tibbiy koʻrik natijalariga koʻra sogʻlomman va sudlanmaganman. Shuningdek, hozirgi kunda oʻzimga ish topib, yaxshi oylik maosh olaman. Shu sababli men keyingi hayotimni farzandim uchun bagʻishlab, uni oʻzim tarbiya qilmoqchiman.

Oila kodeksining 82-moddasi talabiga koʻra, ota-ona (ulardan biri) oʻz xulq-atvorini, turmush tarzini va (yoki) bola tarbiyasiga boʻlgan munosabatini oʻzgartirgan hollarda ota-onalik huquqi tiklanishi mumkin.

Ota-onalik huquqini tiklash ota-onalik huquqidan mahrum qilingan ota-onaning (ulardan birining) daʼvosiga binoan sud tartibida amalga oshiriladi.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalariga, Oila kodeksining 82-moddasi, Oʻzbekiston Respublikasi Oliy sudi Plenumining 1998 yil 11 sentyabrdagi 23-sonli "Bolalar tarbiyasi bilan bogʻliq boʻlgan nizolarni hal qilishda sudlar tomonidan qonunlarni qoʻllash amaliyoti toʻgʻrisida"gi qarorining 20 va 21-bandlariga asosan,



                                                              SOʻRAYMAN:



Meni {davogar_fio} voyaga yetmagan farzandim {muassasa_manzili} shahridagi {muassasa_nomi} tarbiyalanuvchisi {bola_tugilgan_sana} kuni tugʻilgan {bola_fio}ga nisbatan onalik huquqimni tiklashni.



Ilova:
1) Daʼvo ariza nusxasi
2) Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
3) Pasport nusxasi
4) Bolaning tugʻilganlik guvohnomasi nusxasi
5) Mahalladan turar joy toʻgʻrisida maʼlumot, daʼvogar toʻgʻrisida tavsifnoma
6) Onalik huquqidan mahrum qilinganligi va aliment undirish toʻgʻrisidagi sud qarorlari nusxasi
7) Bolani muassasaga joylashtirilganligi haqidagi hokim qarori nusxasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
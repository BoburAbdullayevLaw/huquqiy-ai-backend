# 1_3_oilaviy_nizolari/nikoh_yoshini_kamaytirish.py
"""
Nikoh yoshini kamaytirish yuzasidan ariza
"""

HUJJATLAR = {
    "FQ-ON-004": {
        "nomi": "Nikoh yoshini kamaytirish yuzasidan ariza",
        "jpk": "Oila kodeksi 15-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Nikoh yoshini kamaytirish yuzasidan ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda hokimlik nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # HOKIMLIK MA'LUMOTLARI
            {"id": "hokimlik_nomi", "label": "Ariza berilayotgan hokimlik nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZACHI MA'LUMOTLARI
            {"id": "arizachi_manzil", "label": "Arizachining yashash manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Arizachining F.I.O.", "type": "text", "required": True},
            {"id": "arizachi_telefon", "label": "Arizachining telefon raqami", "type": "text", "required": False},

            # NIKOHLANUVCHI MA'LUMOTLARI
            {"id": "nikohlanuvchi_fio", "label": "Arizachiga nikohlanuvchi fuqaro F.I.O.", "type": "text",
             "required": True},
            {"id": "nikohlanuvchi_yoshi", "label": "Nikohlanuvchilarning yoshi (kamida 17 yosh boʻlishi lozim)",
             "type": "text", "required": True},

            # NIKOH SABABI
            {"id": "nikoh_sababi", "label": "Nikohlanishga aniq sabablar", "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilinuvchi hujjatlar roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {hokimlik_nomi} hokimligiga

{arizachi_manzil} manzilida yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                                Nikoh yoshini kamaytirish yuzasidan



Men va menga nikohlanuvchi fuqaro {nikohlanuvchi_fio} bilan {nikoh_sababi} holatlari tufayli nikohdan oʻtishimiz lozim. Yoshimiz {nikohlanuvchi_yoshi} da. Amaldagi qonunchilikka koʻra nikohdan oʻtish yoshi 18 yosh etib belgilanganligi tufayli bizning nikohdan oʻtishimizga moneʼlik qilmoqda.

Oʻzbekiston Respublikasining Oila kodeksi 15-moddasida uzrli sabablar boʻlganida, alohida hollarda (homiladorlik, bola tugʻilishi, voyaga yetmagan shaxsning toʻla muomalaga layoqatli deb eʼlon qilinishi (emansipatsiya), nikohga kirishni xohlovchilarning iltimosiga koʻra nikoh davlat roʻyxatidan oʻtkaziladigan joydagi tuman, shahar hokimi nikoh yoshini koʻpi bilan bir yilga kamaytirishi mumkinligi belgilangan.

Yuqoridagi tartibga koʻra bizning nikoh yoshimizni bir yilga kamaytirib berishingizni soʻrayman.



Maʼlumot uchun telefon raqami: {arizachi_telefon}



Ilova: {ilova}



                                                              Arizachi: {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# 1_5_meros/Merosni qabul qilib olish muddatini tiklash to'g'risida da'vo arizasi.py
"""
Merosni qabul qilib olish muddatini tiklash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MR-006": {
        "nomi": "Merosni qabul qilib olish muddatini tiklash to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1140-1-modda, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Merosni qabul qilib olish muddatini tiklash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar, javobgar va manfaatdor shaxs ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O. (amaki)", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},

            # MANFAATDOR SHAXS (NOTARIAL IDORA)
            {"id": "notarial_idora", "label": "Notarial idora nomi", "type": "text", "required": True},
            {"id": "notarial_idora_manzil", "label": "Notarial idora manzili", "type": "text", "required": True},
            {"id": "notarial_idora_raqami", "label": "Notarial idora raqami", "type": "text", "required": True},

            # BOBO VA BUVI
            {"id": "bobo_fio", "label": "Boboning F.I.O.", "type": "text", "required": True},
            {"id": "bobo_vafot_sana", "label": "Boboning vafot etgan sanasi", "type": "date", "required": True},
            {"id": "buvi_fio", "label": "Buvining F.I.O.", "type": "text", "required": True},
            {"id": "buvi_vafot_sana", "label": "Buvining vafot etgan sanasi", "type": "date", "required": True},

            # UY-JOY
            {"id": "uy_joy_manzili", "label": "Uy-joy manzili", "type": "text", "required": True},

            # OTA
            {"id": "ota_fio", "label": "Otaning F.I.O.", "type": "text", "required": True},
            {"id": "ota_vafot_sana", "label": "Otaning vafot etgan sanasi", "type": "date", "required": True},

            # AMAKI
            {"id": "amaki_fio", "label": "Amakining F.I.O.", "type": "text", "required": True},
            {"id": "amma_fio", "label": "Ammaning F.I.O.", "type": "text", "required": True},

            # VASIYATNOMA
            {"id": "ota_vasiyatnoma_sana", "label": "Otaning vasiyatnoma sanasi", "type": "date", "required": True},
            {"id": "ota_vasiyatnoma_raqami", "label": "Otaning vasiyatnoma raqami", "type": "text", "required": True},
            {"id": "ota_vasiyatnoma_idora", "label": "Otaning vasiyatnomasini rasmiylashtirgan notarial idora",
             "type": "text", "required": True},
        ],
        "shablon": """
***
                                                                            Fuqarolik ishlari boʻyicha
                                                                            {sud_nomi}ga
                
                                                                            Daʼvogar: {davogar_fio}
                                                                            Manzil: {davogar_manzil}
                                                                            
                                                                            Javobgar: {javobgar_fio}
                                                                            Manzil: {javobgar_manzil}
                
                                                                            Manfaatdor shaxs: {notarial_idora} {notarial_idora_raqami}-sonli davlat notarial idorasi
                                                                            Manzil: {notarial_idora_manzil}



                                                              DA'VO ARIZASI

                                    Merosni qabul qilib olish muddatini tiklash to'g'risida



Marhum bobom {bobo_fio} {bobo_vafot_sana} kuni va buvim {buvi_fio} {buvi_vafot_sana} kuni vafot etgan boʻlib, ular oʻzlariga tegishli boʻlgan birgalikdagi turmushlari davomida orttirgan {uy_joy_manzili} manzilida joylashgan uy-joyni otam {ota_fio}ga vasiyat qilib qoldirganlar.

Bobom va buvimning ikki nafar {amaki_fio} hamda {amma_fio} ismli farzandlari bor. Otam {ota_fio} merosni qabul qilish masalasida notarial idoraga murojaat qilgan edi. Notarial idora tomonidan meros ishi ochilganidan soʻng otam {ota_fio} toʻsatdan vafot etib, merosni qabul qila olmadilar. Ammo u kishi oʻlimdan oldin barcha mulkini menga vasiyat qilib qoldirgan. Vasiyatnoma {ota_vasiyatnoma_idora} tomonidan {ota_vasiyatnoma_sana} kuni rasmiylashtirilib, reestr kitobiga {ota_vasiyatnoma_raqami} bilan qayd etilgan.

Otamning oʻlimidan soʻng oradan koʻp vaqt oʻtmasdan men moddiy sharoitimni yaxshilash maqsadida ishlash uchun boshqa davlatga ketdim. Oradan ikki yildan ortiq vaqt oʻtganidan soʻng qaytib kelib, harbiy xizmatni oʻtash uchun ketdim. Bir yil harbiy xizmatni oʻtab qaytib kelganimdan soʻng merosni qabul qilib olmoqchi boʻlganimda, amakim {javobgar_fio} merosni rasmiylashtirishimga qarshilik koʻrsatmoqda. Notarial idoraga murojaat qilganimda, men uch yillik muddat davomida merosni qabul qilish huquqimdan foydalanmaganligim sababli, menga merosni qabul qilib olish muddatini tiklash masalasida sudga murojaat qilish huquqim tushuntirildi.

Men merosni qabul qilib olish muddatini uzrli sabablarga koʻra oʻtkazib yuborganman. Mening ikki yildan ortiqroq vaqt mobaynida boshqa davlatda boʻlganligim, u yerdan qaytib kelib harbiy xizmatni oʻtash uchun ketganligimni inobatga olib,

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 1140-1-moddasi talablariga muvofiq,



                                                              SOʻRAYMAN:



Men {davogar_fio} tomonidan oʻtkazib yuborilgan merosni qabul qilib olish muddatini uzrli deb topib, tiklashingizni.



Ilova:
1. Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
2. Pasport nusxasi
3. Bobo va buvining oʻlim guvohnomasi
4. Bobo va buvi tomonidan yozilgan vasiyatnoma
5. Ota tomonidan yozilgan vasiyatnoma
6. Ota va amakining tugʻilganlik haqidagi guvohnoma nusxalari
7. Chet davlatda boʻlganligini isbotlovchi hujjatlar
8. Harbiy xizmatni oʻtaganligi toʻgʻrisida harbiy guvohnoma nusxasi
9. Mahalla fuqarolar yigʻini tomonidan tuzilgan dalolatnoma
10. Turar joy haqida berilgan maʼlumotnoma



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ota_vasiyatnoma_sana} yil.
***
"""
    }
}
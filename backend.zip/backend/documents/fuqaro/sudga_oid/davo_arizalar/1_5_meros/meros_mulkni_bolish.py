# 1_5_meros/meros_mulkni_bolish.py
"""
Meros bo'lgan mol-mulkni bo'lish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MR-007": {
        "nomi": "Meros bo'lgan mol-mulkni bo'lish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1150-modda, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Meros bo'lgan mol-mulkni bo'lish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_tugilgan_yil", "label": "Da'vogarning tug'ilgan yili", "type": "text", "required": True},

            # OTA-ONA
            {"id": "ota_fio", "label": "Otaning F.I.O.", "type": "text", "required": True},
            {"id": "ota_tugilgan_sana", "label": "Otaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "ota_vafot_sana", "label": "Otaning vafot etgan sanasi", "type": "date", "required": True},

            {"id": "ona_fio", "label": "Onaning F.I.O.", "type": "text", "required": True},
            {"id": "ona_tugilgan_sana", "label": "Onaning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "ona_vafot_sana", "label": "Onaning vafot etgan sanasi", "type": "date", "required": True},

            # OTA-ONA NIKOHI
            {"id": "ota_ona_nikoh_sana", "label": "Ota-onaning nikoh sanasi", "type": "date", "required": True},

            # MEROSXO'RLAR
            {"id": "merosxorlar_soni", "label": "Merosxo'rlar soni", "type": "text", "required": True},

            {"id": "opa_fio", "label": "Opaning F.I.O.", "type": "text", "required": True},
            {"id": "opa_tugilgan_sana", "label": "Opaning tug'ilgan sanasi", "type": "date", "required": True},

            {"id": "singil_fio", "label": "Singilning F.I.O.", "type": "text", "required": True},
            {"id": "singil_tugilgan_sana", "label": "Singilning tug'ilgan sanasi", "type": "date", "required": True},

            {"id": "uka_fio", "label": "Ukaning F.I.O.", "type": "text", "required": True},
            {"id": "uka_tugilgan_sana", "label": "Ukaning tug'ilgan sanasi", "type": "date", "required": True},

            # JAVOBGAR
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},

            # MEROS MULKLAR
            {"id": "meros_mulklar", "label": "Meros bo'lib qolgan mol-mulklar ro'yxati", "type": "textarea",
             "required": True},

            # NOTARIAL IDORA
            {"id": "notarial_idora_nomi", "label": "Notarial idora nomi", "type": "text", "required": True},
            {"id": "murojaat_sana", "label": "Notarial idoraga murojaat qilingan sana", "type": "date", "required": True},

            # RAD ETISH
            {"id": "voz_kechish_arizasi", "label": "Merosdan voz kechish haqidagi ariza mavjudligi", "type": "text",
             "required": True},
            {"id": "voz_kechgan_shaxs_fio", "label": "Merosdan voz kechgan shaxsning F.I.O.", "type": "text",
             "required": True},

            # UY-JOY
            {"id": "hokim_qarori_sana", "label": "Hokim qarori sanasi", "type": "date", "required": True},
            {"id": "hokim_qarori_raqami", "label": "Hokim qarori raqami", "type": "text", "required": True},
            {"id": "uy_joy_manzili", "label": "Uy-joy manzili", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                                            Fuqarolik ishlari boʻyicha
                                                                            {sud_nomi}ga
                
                                                                            Daʼvogar: {davogar_fio}



                                                              DA'VO ARIZASI

                                    (Meros boʻlgan mol-mulkni boʻlish toʻgʻrisida)



Men daʼvogar {davogar_fio} {davogar_tugilgan_yil} yilda tugʻilganman.

Otam {ota_fio} {ota_tugilgan_sana} kuni tugʻilib, {ota_vafot_sana} kuni, onam {ona_fio} {ona_tugilgan_sana} kuni tugʻilib, {ona_vafot_sana} kuni vafot etganlar.

Ota-onam {ota_ona_nikoh_sana} kuni qonuniy nikohdan oʻtib, ularning birgalikdagi turmushlaridan {merosxorlar_soni} nafar, yaʼni {opa_tugilgan_sana} kuni tugʻilgan, opam {opa_fio}, oʻzim {davogar_tugilgan_yil} yilda tugʻilganman, {singil_tugilgan_sana} kuni singlim {singil_fio} va {uka_tugilgan_sana} kuni ukam {uka_fio} lar tugʻilgan.

Ota-onamizdan {merosxorlar_soni} nafar farzand merosxoʻrlar hisoblanadi. Ota-onamning birgalikdagi turmushlari davomida orttirgan mulklaridan {meros_mulklar} meros boʻlib qolgan.

Ota-onamning vafotidan soʻng {murojaat_sana} kuni {notarial_idora_nomi} notarial idorasiga merosga boʻlgan huquqni beruvchi guvohnoma berishni soʻrab murojaat qilganman. Biroq, notarial idora merosxoʻrlarni chaqirib ularning fikrini soʻraganida, merosxoʻrlardan biri yaʼni javobgar {javobgar_fio} norozilik bildirganligi sababli notarius merosni boʻlib bera olmasligini, merosxoʻrlar oʻrtasida nizo borligini aytib notarial harakatni amalga oshirishni rad etish toʻgʻrisida qaror chiqarib berdi.

Merosxoʻrlardan biri {voz_kechgan_shaxs_fio}ning ota-onamdan qolgan meros mulkining oʻziga tegishli boʻlgan hissasini olishni xohlamasligi toʻgʻrisidagi notarial tasdiqlangan arizasi mavjud.

Ayni vaqtda nizo merosxoʻr javobgar {javobgar_fio} bilan oʻrtamizda boʻlib, meros mulklarini qonuniy taqsimlash lozim.

Ota-onamizdan bizga meros boʻlib qolgan {hokim_qarori_sana} kungi {hokim_qarori_raqami}-sonli hokim qarori bilan {uy_joy_manzili} manzilida joylashgan uy-joy (umumiy mol-mulk) mavjud.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalariga, Fuqarolik kodeksining 1150-moddasiga asosan,



                                                              SOʻRAYMAN:



1. Nizoli marhum ota-onamdan qolgan umumiy mol-mulkni merosxoʻrlar oʻrtasida teng taqsimlashingizni.

2. Meros mulki boʻlgan menga natura shaklida qoldirishingizni.

3. Sud tomonidan chiqariladigan xarajatlarni taraflar oʻrtasida teng taqsimlashingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
3. Pasportlar nusxasi
4. Meros qoldiruvchilarning oʻlganligi haqida guvohnoma nusxasi
5. Meros mulki meros qoldiruvchiga tegishli ekanligini tasdiqlovchi hujjatlar (yer ajratish toʻgʻrisidagi hokim qarori, kadastr hujjatlari, oldi-sotdi, hadya, ayirboshlash shartnomalari va boshqa hujjatlar)
6. Notarial idoraning merosxoʻrlar oʻrtasida nizo kelib chiqqanligi sababli meros mulkini boʻlishni rad etish haqidagi xati
7. Meros qoldiruvchining merosxoʻrlar va oila aʼzolari haqidagi hujjatlar (nikoh guvohnomasi va bolalarning tugʻilganliklari toʻgʻrisidagi guvohnoma nusxalari)
8. Meros ulushidan notarial tarzda voz kechish ariza nusxasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {murojaat_sana} yil.
***
"""
    }
}
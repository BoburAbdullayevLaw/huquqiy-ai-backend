# 1_5_meros/meros_mulkni_qorishlash.py
"""
Meros mol-mulkning qoʻriqlanishiga oid chora-tadbirlar koʻrish toʻgʻrisidagi ariza
"""

HUJJATLAR = {
    "FQ-MR-002": {
        "nomi": "Meros mol-mulkning qoʻriqlanishiga oid chora-tadbirlar koʻrish toʻgʻrisidagi ariza",
        "jpk": "Notariat toʻgʻrisidagi qonun, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Meros mol-mulkning qoʻriqlanishiga oid chora-tadbirlar koʻrish toʻgʻrisidagi ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori qismida notarius ma'lumotlari, arizachi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # NOTARIAL IDORA TURI
            {"id": "notarial_turi", "label": "Notarial idora turi", "type": "select",
             "options": ["Davlat notarial idorasi", "Xususiy amaliyot bilan shugʻullanuvchi notarius"], "required": True},

            # NOTARIAL IDORA MA'LUMOTLARI
            {"id": "notarial_manzil", "label": "Ariza kiritilayotgan notarial idora manzili (viloyat, tuman, koʻcha, uy)",
             "type": "text", "required": True},
            {"id": "notarial_raqami", "label": "Notarial idora raqami (masalan: 5-son)", "type": "text",
             "required": False},
            {"id": "notarius_fio", "label": "Notarius F.I.O.", "type": "text", "required": True},

            # MEROS ISHI
            {"id": "meros_ish_raqami", "label": "Meros ishining raqami", "type": "text", "required": True},

            # ARIZACHI MA'LUMOTLARI
            {"id": "arizachi_manzil", "label": "Arizachining yashash manzili", "type": "text", "required": True},
            {"id": "arizachi_uy_raqami", "label": "Arizachi doimiy roʻyxatda turgan uy raqami", "type": "text",
             "required": True},
            {"id": "arizachi_fio", "label": "Arizachining F.I.O.", "type": "text", "required": True},
            {"id": "pasport_seriya", "label": "Arizachining pasport seriyasi va raqami", "type": "text",
             "required": True},
            {"id": "pasport_bergan", "label": "Arizachiga pasport bergan IIB hudud", "type": "text", "required": True},
            {"id": "pasport_sana", "label": "Arizachiga pasport berilgan sana", "type": "date", "required": True},

            # ARIZA KELIB TUSHGAN SANA
            {"id": "ariza_kelgan_sana", "label": "Ariza kelib tushgan sana", "type": "date", "required": True},

            # ARIZA TASDIQLANGAN SANA
            {"id": "ariza_tasdiqlangan_sana", "label": "Ariza tasdiqlangan sana", "type": "date", "required": True},

            # VAFOT ETGAN SHAXS
            {"id": "marhum_qarindoshligi", "label": "Vafot etgan shaxsning arizachiga qarindoshligi va F.I.O.",
             "type": "text", "required": True},
            {"id": "marhum_manzil", "label": "Vafot etgan shaxsning yashash manzili", "type": "text", "required": True},
            {"id": "marhum_uy_raqami", "label": "Vafot etgan shaxsning yashagan uy raqami", "type": "text",
             "required": True},
            {"id": "marhum_vafot_sana", "label": "Shaxsning vafot etgan sanasi", "type": "date", "required": True},

            # MEROS MOL-MULK
            {"id": "meros_manzil", "label": "Vafot etgan shaxsning meros sifatida qolgan mol-mulkning joylashgan manzili",
             "type": "text", "required": True},
            {"id": "meros_uy_raqami", "label": "Vafot etgan shaxsning meros sifatida qolgan uyning raqami",
             "type": "text", "required": True},

            # VASIYATNOMA
            {"id": "vasiyatnoma_sana", "label": "Reyestrda qayd qilingan sana", "type": "date", "required": True},
            {"id": "vasiyatnoma_raqami", "label": "Qayd qilingan reyestr raqami", "type": "text", "required": True},
            {"id": "merosxor_fio", "label": "Vafot etgan shaxsning merosxoʻri F.I.O.", "type": "text", "required": True},

            # IZOH (14 YOSHGA TO'LMAGAN BO'LSA)
            {"id": "izoh", "label": "Izoh (agar voyaga yetmagan bo'lsa)", "type": "textarea", "required": False},
        ],
        "shablon": """
***
Ariza kelib tushdi: {ariza_kelgan_sana}

Oʻzbekiston Respublikasi, {notarial_manzil}
{f"{notarial_raqami}-son davlat notarial idorasi notariusi" if notarial_turi == "Davlat notarial idorasi" else "xususiy amaliyot bilan shugʻullanuvchi notarius"} {notarius_fio}ga

Meros ishi № {meros_ish_raqami}



Arizachi: {arizachi_fio}
Manzil: {arizachi_manzil}, {arizachi_uy_raqami}-uy
Pasport: {pasport_seriya}, {pasport_bergan} tomonidan {pasport_sana} yilda berilgan



                                                              A R I Z A



Oʻzbekiston Respublikasi, {arizachi_manzil}

{ariza_tasdiqlangan_sana}



Mening {marhum_qarindoshligi} {marhum_manzil}, {marhum_uy_raqami}-uyda doimiy ravishda yashab kelib, {marhum_vafot_sana} kuni vafot etdi.

Uning oʻlimidan soʻng meros mol-mulk sifatida {meros_manzil}da joylashgan {meros_uy_raqami}-uy qoldi.

{notarial_manzil} {f"{notarial_raqami}-son davlat notarial idorasi notariusi" if notarial_turi == "Davlat notarial idorasi" else "xususiy amaliyot bilan shugʻullanuvchi notarius"} {notarius_fio} tomonidan {vasiyatnoma_sana} kuni {vasiyatnoma_raqami} reyestr raqami bilan qayd qilingan vasiyatnomaga koʻra marhumning merosxoʻri deb {merosxor_fio} tayinlangan.

Yuqorida koʻrsatilgan meros mol-mulkning qoʻriqlanishiga oid chora-tadbirlar koʻrishingizni soʻrayman.



                                                              IMZO: ___________________



{izoh}



Notariusning tasdiqlov yozuvi:
_________________________________________________
_________________________________________________
_________________________________________________



Izoh: otasi qizining nomidan bu haqdagi arizani yozadi, qachonki, qizi 14 yoshga toʻlmagan voyaga yetmagan merosxoʻr boʻlsa.
***
"""
    }
}
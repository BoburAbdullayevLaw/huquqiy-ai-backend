# 1_5_meros/vasiyatnomani_haqiqiy_emas_topish.py
"""
Vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani va vasiyatnomani haqiqiy emas deb topish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-MR-001": {
        "nomi": "Vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani va vasiyatnomani haqiqiy emas deb topish toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 1113, 1118, 1120-1124, 1130-moddalar, Oliy sud Plenumi 5-son qarori 7-band, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani va vasiyatnomani haqiqiy emas deb topish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar, javobgar va uchinchi shaxs ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # UMUMIY MA'LUMOT
            {"id": "farzandlar_soni", "label": "Ota-onaning farzandlari soni (soʻz bilan)", "type": "text",
             "required": True},

            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi va manzili", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},
            {"id": "guvohnoma_sana", "label": "Vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnoma berilgan sana",
             "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR (NOTARIAL IDORA)
            {"id": "notarial_hudud", "label": "Notarial idora joylashgan tuman (shahar) nomi", "type": "text",
             "required": True},
            {"id": "notarial_idora", "label": "Notarial idora (Davlat notarial idorasi notariusi yoki Xususiy amaliyot bilan shugʻullanuvchi notarius F.I.O.)",
             "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Notarial idoraning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Notarial idoraning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Notarial idoraning elektron manzili", "type": "email", "required": False},

            # UCHINCHI SHAXS
            {"id": "uchinchi_fio", "label": "Uchinchi shaxsning F.I.O.", "type": "text", "required": True},
            {"id": "uchinchi_manzil", "label": "Uchinchi shaxsning yashash manzili", "type": "text", "required": True},
            {"id": "uchinchi_telefon", "label": "Uchinchi shaxsning telefon raqami", "type": "text", "required": False},
            {"id": "uchinchi_email", "label": "Uchinchi shaxsning elektron manzili", "type": "email", "required": False},

            # OTA-ONA MA'LUMOTLARI
            {"id": "ota_fio", "label": "Daʼvogarning otasining F.I.O.", "type": "text", "required": True},
            {"id": "ota_tugilgan_sana", "label": "Daʼvogarning otasining tugʻilgan sanasi", "type": "date",
             "required": True},
            {"id": "ona_fio", "label": "Daʼvogarning onasining F.I.O.", "type": "text", "required": True},
            {"id": "ona_tugilgan_sana", "label": "Daʼvogarning onasining tugʻilgan sanasi", "type": "date",
             "required": True},
            {"id": "nikoh_sana", "label": "Meros qoldirgan ota-onaning qonuniy nikohdan oʻtgan sanasi", "type": "date",
             "required": True},
            {"id": "nikoh_guvohnoma", "label": "Meros qoldirgan ota-onaning nikoh guvohnomasi seriyasi va raqami",
             "type": "text", "required": True},

            # FARZANDLAR
            {"id": "farzand1_fio", "label": "Birinchi farzandning F.I.O.", "type": "text", "required": False},
            {"id": "farzand1_tugilgan_sana", "label": "Birinchi farzandning tugʻilgan sanasi", "type": "date",
             "required": False},
            {"id": "farzand2_fio", "label": "Ikkinchi farzandning F.I.O.", "type": "text", "required": False},
            {"id": "farzand2_tugilgan_sana", "label": "Ikkinchi farzandning tugʻilgan sanasi", "type": "date",
             "required": False},
            {"id": "farzand3_fio", "label": "Uchinchi farzandning F.I.O.", "type": "text", "required": False},
            {"id": "farzand3_tugilgan_sana", "label": "Uchinchi farzandning tugʻilgan sanasi", "type": "date",
             "required": False},

            # MULK MA'LUMOTLARI
            {"id": "uy_qurilgan_sana", "label": "Meros mol-mulki hisoblanuvchi uy-joy qurilgan sana", "type": "date",
             "required": True},
            {"id": "uchinchi_uy_qurilgan_sana",
             "label": "Uchinchi shaxs tomonidan meros mol-mulki joylashgan hududda uy-joy qurilgan sana", "type": "date",
             "required": True},
            {"id": "javobgar_uy_qurilgan_sana",
             "label": "Meros qoldirgan uy-joyning bir qismida javobgar uy-joy qurgan sanasi", "type": "date",
             "required": True},
            {"id": "mulk_manzili", "label": "Vasiyatnoma boʻyicha taqdim etilgan mulkning manzili", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {notarial_hudud} tumani (shahri)dagi
                                                            {notarial_idora}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}

                                                            Uchinchi shaxs: {uchinchi_fio}
                                                            Manzil: {uchinchi_manzil}
                                                            Telefon: {uchinchi_telefon}
                                                            Elektron manzil: {uchinchi_email}



Daʼvo mazmuni: {guvohnoma_sana} dagi vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani haqiqiy emas deb topish toʻgʻrisida



                                                            DAʼVO ARIZA



Maʼlumki, Oʻzbekiston Respublikasi Konstitutsiyasining 41-moddasiga koʻra, har bir shaxs mulkdor boʻlishga haqli.

Fuqarolik kodeksining 1113-moddasiga muvofiq meros tarkibiga meros ochilgan paytda meros qoldiruvchiga tegishli boʻlgan koʻchar va koʻchmas mulk, ashyolar, shu jumladan, uning oʻlimidan keyin ham bekor boʻlmaydigan barcha mulkiy huquq va majburiyatlar, xususan, xususiy mulk huquqi, kredit muassasalarida saqlanayotgan omonatlarga boʻlgan huquq, dehqon xoʻjaligi yer uchastkasiga meros qilib qoldiriladigan umrbod egalik qilish huquqi, yer uchastkasini ijaraga olish huquqlari kiradi.

Mening daʼvo ariza kiritishdan asosiy maqsadim, oʻzim tugʻilib oʻsgan ota-onamning uyiga meros huquqiga ega boʻlish hamda undan foydalanishdan iborat.

Otam {ota_fio} {ota_tugilgan_sana} yilda tugʻilgan, onam {ona_fio} esa {ona_tugilgan_sana} yilda tugʻilgan. Ular {nikoh_sana} yilda turmush qurishgan (nikoh guvohnomasi {nikoh_guvohnoma}). Ularning birgalikdagi turmushlaridan {farzandlar_soni} nafar farzandlari bor. 
{f"Birinchi farzand {farzand1_fio}, {farzand1_tugilgan_sana} yilda," if farzand1_fio else ""}
{f"ikkinchi farzand {farzand2_fio}, {farzand2_tugilgan_sana} yilda," if farzand2_fio else ""}
{f"uchinchi farzand {farzand3_fio}, {farzand3_tugilgan_sana} yilda tugʻilgan." if farzand3_fio else ""} Shuningdek, men ham shu oilada tugʻilganman.

Meros mol-mulki hisoblanuvchi uy-joy {uy_qurilgan_sana} yilda marhum otam oʻziga tegishli boʻlgan {mulk_manzili} manzilida joylashgan yer maydonida uy-joy qurgan. Shu manzilning bir qismida {javobgar_uy_qurilgan_sana} yilda javobgar uy-joy qurgan. {uchinchi_uy_qurilgan_sana} yilga kelib shu yer maydonining bir qismida ukam, yaʼni ish boʻyicha uchinchi shaxs {uchinchi_fio} ham uy-joy qurgan.

Javobgar tomonidan {guvohnoma_sana} da vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnoma berilgan boʻlib, otam {uchinchi_fio}ga uy-joyning faqatgina oʻziga tegishli boʻlgan qismini vasiyat qilib qoldirgan. Notarius esa ushbu uy-joyning umumiy mulk ekanligiga va qolgan merosxoʻrlarning ham ushbu uy-joyga nisbatan ulushi borligiga ahamiyat qaratmasdan, uy-joyni butunligicha {uchinchi_fio}ga rasmiylashtirib bergan.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 1120-1124-moddalari talabiga koʻra, fuqaroning oʻziga tegishli mol-mulkni yoki bu mol-mulkka nisbatan huquqini vafot etgan taqdirda tasarruf etish xususidagi xohish-irodasi vasiyat deb eʼtirof qilinadi. Vasiyatnoma shaxsan tuzilishi lozim. Vasiyatnomaning vakil orqali tuzilishiga yoʻl qoʻyilmaydi. Fuqaro oʻzining barcha mol-mulkini yoki uning muayyan qismini qonun boʻyicha merosxoʻrlar doirasiga kiradigan, shuningdek kirmaydigan bir yoki bir necha shaxsga, shu bilan birga yuridik shaxslarga, davlatga yoki fuqarolarning oʻzini oʻzi boshqarish organlariga vasiyat qilishi mumkin.

Fuqarolik Kodeksining 1118-moddasiga koʻra, meros ochilgan paytda hayot boʻlgan fuqarolar, shuningdek meros qoldiruvchining hayotlik paytida homila holida boʻlgan va meros ochilgandan keyin tirik tugʻilgan bolalari vasiyat va qonun boʻyicha merosxoʻr boʻlishlari mumkin. Mazkur modda talabidan kelib chiqqan holda men otamning mol-mulki boʻyicha merosxoʻr hisoblanaman.

Mazkur Kodeksning 1130-moddasida vasiyatnomaning haqiqiy emas deb topilishidan mulkiy oqibatlarga ega boʻladigan shaxsning daʼvosi boʻyicha vasiyatnoma uni tuzish, imzolash va tasdiqlashning ushbu Kodeksda belgilangan tartibi buzilishi natijasida haqiqiy emas deb topilishi mumkinligi, vasiyatnoma haqiqiy emas deb topilgan taqdirda, ushbu vasiyatnomaga binoan merosdan mahrum boʻlgan merosxoʻr umumiy asoslarda meros olish huquqiga ega boʻladi.

Shuningdek, Oliy sud plenumining 2011-yil 20-iyuldagi 5-son "Sudlar tomonidan meros huquqiga oid qonunchilikning qoʻllanilishi toʻgʻrisida"gi qarorining 7-bandiga asosan, vasiyatnoma haqiqiy emas deb topilgan hollarda, unda merosxoʻr tariqasida koʻrsatilgan, biroq tegishli navbatdagi qonun boʻyicha merosxoʻrlar doirasiga kiradigan shaxs umumiy asoslarda qonun boʻyicha vorislik huquqidan mahrum etilmaydi. Bunday hollarda, sud tomonidan haqiqiy emas deb topilgan vasiyatnomaga koʻra merosdan mahrum etilgan qonun boʻyicha merosxoʻr ham umumiy asoslarda vorislik huquqiga ega boʻladi.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189-191-moddalariga, Fuqarolik kodeksining 1120-1124, 1130-moddalariga, hamda Oliy sud plenumining 2011-yil 20-iyuldagi 5-son qarorining 7-bandiga asosan,



                                                            SOʻRAYMAN:



1. {guvohnoma_sana} dagi vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani haqiqiy emas deb topishingizni.

2. Ish koʻrib chiqilishi bilan bogʻliq xarajatlar va davlat bojini javobgardan undirishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
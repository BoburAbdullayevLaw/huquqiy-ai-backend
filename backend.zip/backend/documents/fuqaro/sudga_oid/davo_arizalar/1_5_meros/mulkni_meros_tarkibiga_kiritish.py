# 1_5_meros/mulkni_meros_tarkibiga_kiritish.py
"""
Mol-mulkni meros tarkibiga kiritish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MR-008": {
        "nomi": "Mol-mulkni meros tarkibiga kiritish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1113-1114-moddalar, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mol-mulkni meros tarkibiga kiritish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # OTA-ONA MA'LUMOTLARI
            {"id": "ota_fio", "label": "Otaning F.I.O.", "type": "text", "required": True},
            {"id": "ona_fio", "label": "Onaning F.I.O.", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Ota-onaning nikoh sanasi", "type": "date", "required": True},

            # FARZANDLAR
            {"id": "farzandlar_soni", "label": "Farzandlar soni", "type": "text", "required": True},
            {"id": "farzand1_fio", "label": "1-farzandning F.I.O.", "type": "text", "required": True},
            {"id": "farzand1_tugilgan", "label": "1-farzandning tug'ilgan sanasi", "type": "date", "required": True},
            {"id": "farzand2_fio", "label": "2-farzandning F.I.O.", "type": "text", "required": True},
            {"id": "farzand2_tugilgan", "label": "2-farzandning tug'ilgan sanasi", "type": "date", "required": True},

            # OTA VAFOTI
            {"id": "ota_vafot_sana", "label": "Otaning vafot etgan sanasi", "type": "date", "required": True},

            # BIRINCHI OILA
            {"id": "birinchi_oila", "label": "Otaning birinchi oilasi haqida ma'lumot", "type": "text",
             "required": True},

            # OTA-ONA VAFOTIDAN KEYIN
            {"id": "meros_mulklar", "label": "Meros bo'lib qolgan mulklar", "type": "textarea", "required": True},

            # YANGI MULK
            {"id": "yangi_mulk_turi", "label": "Yangi aniqlangan mulk turi", "type": "text", "required": True},
            {"id": "yangi_mulk_manzili", "label": "Yangi mulkning manzili", "type": "text", "required": True},
            {"id": "yangi_mulk_tuman", "label": "Yangi mulk joylashgan tuman", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                                            Fuqarolik ishlari boʻyicha
                                                                            {sud_nomi}ga
                
                                                                            Daʼvogar: {davogar_fio}
                                                                            Manzil: {davogar_manzil}
                                                                            Telefon: {davogar_telefon}
                                                                            
                                                                            Javobgar: {javobgar_fio}
                                                                            Manzil: {javobgar_manzil}
                                                                            Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Mol-mulkni meros tarkibiga kiritish toʻgʻrisida)



Daʼvo arizamning mazmuni shundan iboratki, otam {ota_fio} va onam {ona_fio} {nikoh_sana} kuni qonuniy nikohdan oʻtib turmush qurgan.

Ularning birgalikdagi turmushlaridan {farzandlar_soni} nafar farzandlari, yaʼni 1. {farzand1_fio} ({farzand1_tugilgan} yilda tugʻilgan), 2. {farzand2_fio} ({farzand2_tugilgan} yilda tugʻilgan) farzandlari bor.

Otam {ota_fio} {ota_vafot_sana} kuni vafot etgan.

Otam {ota_fio}ning birinchi oilasi boʻlib, ular bilan ham birga yashagan: {birinchi_oila}.

Ota-onamning vafotidan soʻng {meros_mulklar} meros boʻlib qoldi, merosxoʻrlar oʻrtasida nizo paydo boʻlganligi sababli ushbu meros mulklardan ulushimizni sud orqali taqsimlashni lozim topdik va bu haqda mazkur sudda koʻrib chiqilayotgan meros mulklarini boʻlish haqidagi fuqarolik ishi boʻyicha bugungi kunda marhum otam {ota_fio}ga tegishli {yangi_mulk_tuman} tumani hududida joylashgan 1 ta {yangi_mulk_turi} meros mulk borligi maʼlum boʻldi.

Ushbu mulkni ham meros tarkibiga kiritilishi lozim deb hisoblayman.

Men otamning qonun boʻyicha birinchi navbatdagi merosxoʻrlaridan biri hisoblanaman. Meros mulklar merosxoʻrlar oʻrtasida oʻzaro kelishuv asosida taqsimlanmadi va bunga erishilmadi.

Shu sababli, ushbu aniqlangan mulkni meros tarkibiga kiritish va undan ham ulush ajratish lozim deb hisoblayman.

Yuqoridagilarga asosan hamda Oʻzbekiston Respublikasi Fuqarolik kodeksining 1113-1114-moddalariga asosan,



                                                              SOʻRAYMAN:



{ota_fio}ga tegishli boʻlgan {yangi_mulk_tuman} tumani hududida joylashgan {yangi_mulk_turi}ni meros tarkibiga kiritishingizni va undan ulush ajratishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Fuqarolik pasport nusxasi
3. Tugʻilganlik toʻgʻrisidagi guvohnoma
4. Meros mulkka tegishli hujjatlar nusxalari
5. Oʻlim toʻgʻrisidagi guvohnoma
6. Yashash joyidan maʼlumotnoma
7. Davlat boji kvitansiyasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ota_vafot_sana} yil.
***
"""
    }
}
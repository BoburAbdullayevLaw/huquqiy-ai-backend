# 1_5_meros/nolojiq_merosxor.py
"""
Noloyiq merosxo'r deb topish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MR-005": {
        "nomi": "Noloyiq merosxo'r deb topish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1119-modda, Oliy sud Plenumi qarori, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Noloyiq merosxo'r deb topish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},

            # TURMUSH O'RTOG'I
            {"id": "turmush_ortogi_fio", "label": "Turmush o'rtog'ining F.I.O.", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Nikoh tuzilgan sana", "type": "date", "required": True},

            # UY-JOY
            {"id": "uy_joy_manzili", "label": "Uy-joy manzili", "type": "text", "required": True},
            {"id": "sotib_olingan_yil", "label": "Uy-joy sotib olingan yil", "type": "text", "required": True},

            # VAFOT
            {"id": "vafot_sana", "label": "Turmush o'rtog'ining vafot etgan sanasi", "type": "date", "required": True},

            # JAVOBGAR
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O. (qayin uka)", "type": "text", "required": True},
            {"id": "javobgar_tugilgan_sana", "label": "Javobgarning tug'ilgan sanasi", "type": "date", "required": True},

            # NOTARIAL IDORA
            {"id": "notarial_idora_nomi", "label": "Notarial idora nomi", "type": "text", "required": True},
            {"id": "notarial_idora_raqami", "label": "Notarial idora raqami", "type": "text", "required": True},
            {"id": "vasiyatnoma_sana", "label": "Vasiyatnoma sanasi", "type": "date", "required": True},

            # MFY
            {"id": "mfy_nomi", "label": "MFY nomi", "type": "text", "required": True},
            {"id": "mfy_rahimi", "label": "MFY raisi F.I.O.", "type": "text", "required": True},
            {"id": "soxta_ma_lumotnoma_sana", "label": "Soxta ma'lumotnoma sanasi", "type": "date", "required": True},
            {"id": "soxta_ma_lumotnoma_raqami", "label": "Soxta ma'lumotnoma raqami", "type": "text", "required": True},
            {"id": "sobiq_turmush_ortogi_fio", "label": "Sobiq turmush o'rtog'i sifatida ko'rsatilgan shaxs F.I.O.",
             "type": "text", "required": True},

            # GUVOHNOMA
            {"id": "guvohnoma_sana", "label": "Meros guvohnomasi berilgan sana", "type": "date", "required": True},

            # JINOYAT ISHI
            {"id": "jinoyat_sud_nomi", "label": "Jinoyat ishlari bo'yicha sud nomi", "type": "text", "required": True},
            {"id": "hukm_sana", "label": "Hukm sanasi", "type": "date", "required": True},
            {"id": "jk_modda", "label": "JK moddasi va qismi", "type": "text", "required": True},

            # FUQAROLIK ISHI
            {"id": "fuqarolik_sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},
            {"id": "hal_qiluv_qarori_sana", "label": "Hal qiluv qarori sanasi", "type": "date", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

Daʼvogar: {davogar_fio}



                                                              DA'VO ARIZASI

                                    (noloyiq merosxoʻr deb topish toʻgʻrisida)



Maʼlumki, Oʻzbekiston Respublikasi Konstitutsiyasining 36-moddasiga koʻra, har bir shaxs mulkdor boʻlishga haqli va meros huquqi qonun bilan kafolatlanadi.

Men daʼvogar {davogar_fio} {nikoh_sana} kuni {turmush_ortogi_fio} bilan qonuniy nikohdan oʻtganman. Birgalikdagi turmushimizdan farzandlarimiz bor. Birgalikdagi turmushimiz davomida {sotib_olingan_yil} yilda {uy_joy_manzili} manzilidagi uy-joyni sotib olganmiz.

Turmush oʻrtogʻim {turmush_ortogi_fio} {vafot_sana} kuni vafot etganlar.

Turmush oʻrtogʻim nizoli uy-joyni qayin ukam javobgar {javobgar_fio} ga {vasiyatnoma_sana} kuni {notarial_idora_nomi} {notarial_idora_raqami}-sonli notarial idora orqali rasmiylashtirilgan vasiyatnoma orqali vasiyat qilganlar. Bu toʻgʻrisida javobgar {javobgar_fio} meni uydan chiqarishga harakat qilganidan soʻng bilganman.

Javobgar {javobgar_fio} oʻziga mazkur uyni vasiyat qilib qoldirilganligidan foydalanib, "{mfy_nomi}" MFY raisi {mfy_rahimi} bilan oldindan kelishib, til biriktirib {soxta_ma_lumotnoma_sana} kuni {soxta_ma_lumotnoma_raqami}-sonli maʼlumotnomaga marhum turmush oʻrtogʻim {turmush_ortogi_fio}ning qonuniy nikohdagi turmush oʻrtogʻi men boʻlsamda, marhum erimning sobiq turmush oʻrtogʻi {sobiq_turmush_ortogi_fio} deb uni {notarial_idora_nomi} notarial idorasiga taqdim qilib, {guvohnoma_sana} kuni "Merosga boʻlgan huquq toʻgʻrisidagi guvohnoma"ni oʻzining nomiga va boshqalarning nomiga rasmiylashtirishga erishgan. Shuningdek uyning barcha hujjatlarini yoqib yuborgan.

Javobgar {javobgar_fio}ning mazkur jinoyati jinoyat ishlari boʻyicha {jinoyat_sud_nomi} sudining {hukm_sana} dagi hukmi bilan oʻz tasdigʻini topgan. Javobgar {javobgar_fio}ga nisbatan JKning {jk_modda} bilan ayb eʼlon qilingan.

Javobgar mazkur harakatlari bilan meni turmush oʻrtogʻimdan qolgan mol-mulkka nisbatan majburiy ulush olish huquqidan mahrum qilishga erishgan va mulkiy huquqlarimni poymol qilgan.

Fuqarolik ishlari boʻyicha {fuqarolik_sud_nomi} sudining {hal_qiluv_qarori_sana} dagi hal qiluv qarori bilan javobgar {javobgar_fio}ga berilgan vasiyat boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnoma haqiqiy emas deb topilgan va sudning qarori qonuniy kuchga ega.

Fuqarolik Kodeksining 1119-moddasining birinchi qismiga koʻra, noloyiq merosxoʻr deb topilishi mumkin boʻlgan shaxslarning vorisligiga oid nizolarni koʻrishda shuni nazarda tutish lozimki, ularning qonuniy kuchga kirgan sud hukmi bilan aniqlangan, vorislikka chaqirilishga imkon yaratgan qonunga xilof harakatlari, faqat bu harakatlar qasddan sodir etilgandagina merosdan mahrum etish uchun asos boʻladi.

Merosxoʻr faqat sudning hal qiluv qaroriga koʻra va faqat merosdan chetlashtirish oʻzi uchun vorislik bilan bogʻliq mulkiy oqibatlar tugʻdiradigan shaxsning daʼvosi boʻyicha noloyiq deb topilishi va merosdan chetlashtirilishi mumkin.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalariga, Fuqarolik kodeksining 1119-moddasiga asosan,



                                                              SOʻRAYMAN:



1. Javobgar {javobgar_tugilgan_sana} kuni tugʻilgan {javobgar_fio}ni marhum turmush oʻrtogʻim {turmush_ortogi_fio} dan qolgan {uy_joy_manzili} manzilidagi uy-joyga nisbatan noloyiq merosxoʻr deb topishingizni hamda merosdan chetlashtirishingizni.

2. Sud xarajatlarini javobgardan undirishingizni.



Ilova:
- Davlat boji toʻlanganligi haqida kvitansiya
- Daʼvo ariza nusxalari
- Pasport nusxasi
- Merosxoʻrlarning tugʻilganlik guvohnomasi nusxasi
- Uy-joyning kadastr hujjatlari va oldi-sotdi shartnomasi nusxasi
- Oʻlim guvohnomasi nusxasi
- Nikoh guvohnomasi nusxasi
- Meros ishiga oid hujjatlar nusxasi
- Hokim qarorlari nusxasi
- Fuqarolik ishlari boʻyicha sudning hal qiluv qarori nusxasi
- Jinoyat ishlari boʻyicha sudning qonuniy kuchda boʻlgan hukmi nusxasi
- MFY maʼlumotnomasi nusxasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
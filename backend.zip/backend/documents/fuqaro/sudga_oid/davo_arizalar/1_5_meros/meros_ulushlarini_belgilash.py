# 1_5_meros/meros_ulushlarini_belgilash.py
"""
Meros bo'yicha ulushlarni belgilash to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MR-009": {
        "nomi": "Meros bo'yicha ulushlarni belgilash to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1134-1141, 1145, 1150-moddalar, FPK 188-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Meros bo'yicha ulushlarni belgilash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Da'vo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Da'vogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # DA'VOGARNING TUG'ILGAN SANASI
            {"id": "davogar_tugilgan_sana", "label": "Da'vogarning tug'ilgan sanasi", "type": "date", "required": True},

            # OTA MA'LUMOTLARI
            {"id": "ota_fio", "label": "Da'vogarning otasining F.I.O.", "type": "text", "required": True},
            {"id": "ota_tugilgan_sana", "label": "Da'vogarning otasining tug'ilgan sanasi", "type": "date",
             "required": True},
            {"id": "ota_vafot_sana", "label": "Da'vogarning otasining vafot etgan sanasi", "type": "date",
             "required": True},

            # ONA MA'LUMOTLARI
            {"id": "ona_fio", "label": "Da'vogarning onasining F.I.O.", "type": "text", "required": True},
            {"id": "ona_tugilgan_sana", "label": "Da'vogarning onasining tug'ilgan sanasi", "type": "date",
             "required": True},
            {"id": "ona_vafot_sana", "label": "Da'vogarning onasining vafot etgan sanasi", "type": "date",
             "required": True},

            # OTA-ONA NIKOHI
            {"id": "ota_ona_nikoh_sana", "label": "Da'vogarning ota-onasining nikohdan o'tgan sanasi", "type": "date",
             "required": True},

            # FARZANDLAR
            {"id": "farzandlar_soni", "label": "Da'vogarning ota-onasining farzandlari soni", "type": "text",
             "required": True},
            {"id": "farzandlar_royxati", "label": "Da'vogarning ota-onasining barcha farzandlarining F.I.O.lari",
             "type": "textarea", "required": True},

            # MEROS MULK
            {"id": "meros_mulk_manzili", "label": "Meros sifatida qolgan uy-joy manzili", "type": "text",
             "required": True},

            # NOTARIAL IDORAGA MUROJAAT
            {"id": "notarial_murojaat_sana",
             "label": "Meros ulushini belgilash uchun notarial idoraga murojaat qilingan sana", "type": "date",
             "required": True},
            {"id": "notarial_idora_nomi", "label": "Murojaat qilingan notarial idora (xususiy notarius) nomi",
             "type": "text", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Da'vo arizaga ilova qilinayotgan hujjatlar ro'yxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                                                Fuqarolik ishlari boʻyicha
                                                                                {sud_nomi} sudiga
                    
                                                                                Daʼvogar: {davogar_fio}
                                                                                Manzil: {davogar_manzil}
                                                                                Telefon: {davogar_telefon}
                                                                                E-mail: {davogar_email}
                                                                                
                                                                                Javobgar: {javobgar_fio}
                                                                                Manzil: {javobgar_manzil}
                                                                                Telefon: {javobgar_telefon}
                                                                                E-mail: {javobgar_email}



                                                              DA'VO ARIZASI

                                    (Meros boʻyicha ulushlarni belgilash toʻgʻrisida)



Men daʼvogar {davogar_fio} {davogar_tugilgan_sana} sanasida tugʻilganman.

Otam {ota_fio} {ota_tugilgan_sana} sanasida tugʻilib, {ota_vafot_sana} sanasida vafot etgan, onam {ona_fio} {ona_tugilgan_sana} sanasida tugʻilib, {ona_vafot_sana} sanasida vafot etganlar.

Ota-onam {ota_ona_nikoh_sana} sanasida qonuniy nikohdan oʻtishib, ular birgalikdagi turmushlaridan {farzandlar_soni} nafar, yaʼni {farzandlar_royxati} farzandli boʻlishgan.

Ota-onamizdan {meros_mulk_manzili} manzilida joylashgan uy-joy biz farzandlarga meros boʻlib qolgan.

Ota-onamning vafotidan soʻng {notarial_murojaat_sana} sanasida {notarial_idora_nomi} notarial idorasiga meros boʻyicha ulushlarimizni belgilab berishni soʻrab murojaat qilganman. Biroq, notarial idora merosxoʻrlarni chaqirib ularning fikrini soʻraganida, merosxoʻrlardan biri yaʼni javobgar {javobgar_fio} norozilik bildirganligi sababli notarius meros boʻyicha ulushlarni belgilab bera olmasligini, merosxoʻrlar oʻrtasida nizo borligini aytib notarial harakatni amalga oshirishni rad etish toʻgʻrisida qaror chiqarib berdi.

Javobgar {javobgar_fio} dan boshqa barcha merosxoʻrlar meros mulki boʻyicha oʻz ulushlariga rozi.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 1134-moddasiga koʻra, qonun boʻyicha merosxoʻrlar vorislikka ushbu Kodeksning 1135–1141-moddalarida nazarda tutilgan navbat tartibida chaqiriladilar.

Shu Kodeksning 1135-moddasiga koʻra, meros qoldiruvchining bolalari (shu jumladan farzandlikka olingan bolalari), eri (xotini) va ota-onasi (farzandlikka oluvchilar) teng ulushlarda qonun boʻyicha birinchi navbatdagi vorislik huquqiga ega boʻladilar. Meros qoldiruvchining vafotidan keyin tugʻilgan bolalari ham birinchi navbatdagi vorislar jumlasiga kiradilar.

Shuningdek, ushbu kodeksning 1145-moddasiga koʻra, merosxoʻr oʻziga tegishli lozim boʻlgan merosni yoki uning bir qismini (ulushini) olish huquqiga, agar u keyinchalik merosdan voz kechmasa, vorislik huquqidan mahrum etilmasa va uni merosxoʻr etib tayinlash toʻgʻrisidagi vasiyat farmoyishi haqiqiy emas deb topilishi natijasida meros olish huquqini yoʻqotmasa, meros ochilgan vaqtdan eʼtiboran ega boʻladi.

Bundan tashqari, mazkur kodeksning 1150-moddasida merosni qabul qilib olgan qonun boʻyicha merosxoʻrlardan istalgan biri merosning taqsimlanishini talab qilishga haqli. Merosni taqsimlash merosxoʻrlarning kelishuviga koʻra oʻzlariga tegishli ulushlarga muvofiq, kelishuvga erishilmagan taqdirda esa, sud tartibida amalga oshiriladi.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188-191-moddalariga, Fuqarolik kodeksining 1135-1141, 1145 hamda 1150-moddalariga asosan,



                                                              SOʻRAYMAN:



Marhum ota-onamning {meros_mulk_manzili} manzilida joylashgan uy-joyiga nisbatan {farzandlar_royxati}larni teng ulushlarda merosxoʻr deb topib, meros boʻyicha ulushlarimizni belgilab berishingizni.



Ilova:
{ilova}



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# 1_5_meros/vasiyatnoma_va_guvohnomani_haqiqiy_emas_topish.py
"""
Vasiyatnoma bo'yicha merosga bo'lgan huquq to'g'risidagi guvohnomani va vasiyatnomani haqiqiy emas deb topish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MR-004": {
        "nomi": "Vasiyatnoma bo'yicha merosga bo'lgan huquq to'g'risidagi guvohnomani va vasiyatnomani haqiqiy emas deb topish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1120-1124, 1130-moddalar, FPK 189-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Vasiyatnoma bo'yicha merosga bo'lgan huquq to'g'risidagi guvohnomani va vasiyatnomani haqiqiy emas deb topish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_tugilgan_yil", "label": "Da'vogarning tug'ilgan yili", "type": "text", "required": True},

            # OTA-ONA MA'LUMOTLARI
            {"id": "ota_fio", "label": "Otaning F.I.O.", "type": "text", "required": True},
            {"id": "ota_tugilgan_yil", "label": "Otaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "ona_fio", "label": "Onaning F.I.O.", "type": "text", "required": True},
            {"id": "ona_tugilgan_yil", "label": "Onaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "nikoh_sana", "label": "Ota-onaning nikoh sanasi", "type": "text", "required": True},

            # AKA-UKALAR
            {"id": "aka_fio", "label": "Akaning F.I.O.", "type": "text", "required": True},
            {"id": "aka_tugilgan_yil", "label": "Akaning tug'ilgan yili", "type": "text", "required": True},
            {"id": "singil_fio", "label": "Singilning F.I.O.", "type": "text", "required": True},
            {"id": "singil_tugilgan_yil", "label": "Singilning tug'ilgan yili", "type": "text", "required": True},

            # UY-JOY MA'LUMOTLARI
            {"id": "oldi_sotdi_sana", "label": "Oldi-sotdi shartnomasi sanasi", "type": "text", "required": True},
            {"id": "eski_kocha", "label": "Eski ko'cha nomi", "type": "text", "required": True},
            {"id": "yangi_kocha", "label": "Yangi ko'cha nomi", "type": "text", "required": True},
            {"id": "uy_qurilgan_yil", "label": "Uy qurilgan yil", "type": "text", "required": True},
            {"id": "davogar_uy_raqami", "label": "Da'vogarning uy raqami (A)", "type": "text", "required": True},
            {"id": "javobgar_uy_raqami", "label": "Javobgarning uy raqami (B)", "type": "text", "required": True},

            # OTA-ONA VAFOTI
            {"id": "ota_vafot_yil", "label": "Otaning vafot etgan yili", "type": "text", "required": True},
            {"id": "ona_vafot_yil", "label": "Onaning vafot etgan yili", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O. (uka)", "type": "text", "required": True},
            {"id": "berilgan_uy_sana", "label": "Uyning javobgarga berilgan yili", "type": "text", "required": True},

            # HOKIM QARORI
            {"id": "hokim_qarori_yil", "label": "Hokim qarori yili", "type": "text", "required": True},
            {"id": "er_maydoni_asosiy", "label": "Asosiy er maydoni (m.kv)", "type": "text", "required": True},
            {"id": "er_maydoni_qoshimcha", "label": "Qo'shimcha er maydoni (m.kv)", "type": "text", "required": True},
            {"id": "er_maydoni_jami", "label": "Jami er maydoni (m.kv)", "type": "text", "required": True},

            # VASIYATNOMA VA GUVOHNOMA
            {"id": "guvohnoma_yil", "label": "Meros guvohnomasi berilgan yil", "type": "text", "required": True},
            {"id": "notarial_idora", "label": "Notarial idora nomi", "type": "text", "required": True},
            {"id": "vasiyatnoma_yil", "label": "Vasiyatnoma yozilgan yil", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}



                                                              DA'VO ARIZASI

          (vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani va vasiyatnomani 
                      haqiqiy emas deb topish toʻgʻrisida)



Maʼlumki, Oʻzbekiston Respublikasi Konstitutsiyasining 36-moddasiga koʻra, har bir shaxs mulkdor boʻlishga haqli va meros huquqi qonun bilan kafolatlanadi.

Otam {ota_fio} {ota_tugilgan_yil} yilda tugʻilgan, onam {ona_fio} esa {ona_tugilgan_yil} yilda tugʻilgan. Ular {nikoh_sana} da qonuniy nikohdan oʻtib oila qurishgan. Ularning birgalikdagi turmushlaridan {aka_tugilgan_yil} yilda akam {aka_fio}, {davogar_tugilgan_yil} yilda men yaʼni {davogar_fio} hamda {singil_tugilgan_yil} yilda singlim {singil_fio} lar tugʻilgan.

{ota_vafot_yil} yilda marhum otam {ota_fio} ga {oldi_sotdi_sana} yildagi oldi-sotdi shartnomasiga koʻra tegishli boʻlgan {eski_kocha} (hozirgi {yangi_kocha}) koʻchasida boʻlgan er maydonida eski uyni buzib, uning yonidan uy-joy qurib bitkazganlar. {uy_qurilgan_yil} yilga qadar shu uy-joyda oilam bilan birga yashab kelganman.

{berilgan_uy_sana} yillarga kelib shu uy-joyning bir qismidan ukam yaʼni javobgar {javobgar_fio} uchun ham uy-joy qurilgan. Ushbu uy-joyda otam va ukam yashab kelgan. Menga tegishli uy manzili {yangi_kocha} koʻchasi {davogar_uy_raqami} A-raqam bilan, ukam {javobgar_fio}ning uyi esa {javobgar_uy_raqami} B-raqam bilan yuritilgan.

{ota_vafot_yil} yilda otam {ota_fio}, {ona_vafot_yil} yilda esa onam {ona_fio} vafot etganlar. {berilgan_uy_sana} yilda oʻzim yashab turgan uy-joyni ukam {javobgar_fio} ga vaqtincha foydalanib turishlik uchun topshirdim. Oʻzim xizmat yuzasidan yashash uchun boshqa viloyatga koʻchib ketganman. Biroq qarilik chogʻida oʻzim tugʻilib oʻsgan ota-onamning uyiga qaytib kelish niyatida boʻlganman.

20{yangi_kocha_sana} yilda shaharga kelganimda ukam {javobgar_fio} yaʼni javobgar menga tegishli uy-joylarni ham qoʻshib, hokimlikdan 20{hokim_qarori_yil} yilda marhum otam {ota_fio} ga {oldi_sotdi_sana} yildagi oldi-sotdi shartnomasiga binoan tegishli boʻlgan {er_maydoni_asosiy} m.kv er maydoniga qoʻshimcha {er_maydoni_qoshimcha} m.kv er maydonini ham qoʻshib, jami {er_maydoni_jami} m.kv er maydoniga oʻzining nomiga foydalanish qarori chiqarib olgan.

Otam oʻziga tegishli er maydonidagi uy-joyni ukam javobgar {javobgar_fio} ga qoldirish haqidagi vasiyatnoma va hokimlikning qaroriga asosan {notarial_idora} davlat notarial idorasi tomonidan {guvohnoma_yil} yilda {javobgar_fio} nomiga umumiy er maydoni {er_maydoni_jami} m.kv er maydonida joylashgan uy-joylarga vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnoma bergan.

Biroq otam {ota_fio} ukam {javobgar_fio} ga faqatgina oʻziga tegishli boʻlgan uy-joyni vasiyat qilib qoldirganlar. Notarius esa ushbu uy-joyning umumiy mulk ekanligiga va qolgan merosxoʻrlarning ham ushbu uy-joyga nisbatan ulushi borligiga ahamiyat qaratmasdan, birgina {oldi_sotdi_sana} yildagi oldi-sotdi shartnomasiga asosan otamga tegishli boʻlgan uy-joyga merosxoʻr sifatida ukam {javobgar_fio} ni koʻrsatib, uy-joyni butunligicha {javobgar_fio}ning nomiga vasiyatnoma asosida merosga boʻlgan huquq toʻgʻrisidagi guvohnoma bergan.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 1120-1124-moddalari talabiga koʻra, fuqaroning oʻziga tegishli mol-mulkni yoki bu mol-mulkka nisbatan huquqini vafot etgan taqdirda tasarruf etish xususidagi xohish-irodasi vasiyat deb eʼtirof qilinadi. Vasiyatnoma shaxsan tuzilishi lozim. Vasiyatnomaning vakil orqali tuzilishiga yoʻl qoʻyilmaydi. Fuqaro oʻzining barcha mol-mulkini yoki uning muayyan qismini qonun boʻyicha merosxoʻrlar doirasiga kiradigan, shuningdek kirmaydigan bir yoki bir necha shaxsga, shu bilan birga yuridik shaxslarga, davlatga yoki fuqarolarning oʻzini oʻzi boshqarish organlariga vasiyat qilishi mumkin.

Hokim qarori esa ushbu uy-joylar aslida kimga tegishli ekanligi va boshqa holatlarni aniqlamasdan chiqarilgan. Shuningdek, {vasiyatnoma_yil} yilda otam {ota_fio} tomonidan qoldirilgan vasiyatnoma ham noqonuniy, chunki otam doimo uy-joyni menga qoldirishni taʼkidlab kelganlar. Biroq vasiyatnoma ukam javobgar {javobgar_fio} nomiga yozilgan.

Vasiyatnoma va uy-joyning rasmiylashtirish bilan bogʻliq hujjatlardan keyingi yillarning oyida xabar topganman. Javobgar ukam bilan oʻzaro kelishib uy-joyni rasmiylashtirmoqchi boʻldik, lekin ukam men va boshqa manfaatdor shaxslarning roziligini olmasdan uy-joyning butun qismini oʻzining nomiga rasmiylashtirib olgan.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189-191-moddalariga, Fuqarolik kodeksining 1120-1124, 1130-moddalariga asosan,



                                                              SOʻRAYMAN:



1. Javobgar {notarial_idora} davlat notarial idorasi tomonidan {guvohnoma_yil} yilda {javobgar_fio}ning nomiga rasmiylashtirilgan va rasmiy reestr kitobida tegishli raqam bilan qayd qilingan vasiyatnoma boʻyicha merosga boʻlgan huquq toʻgʻrisidagi guvohnomani hamda {vasiyatnoma_yil} yilda yozib qoldirilgan javobgar {javobgar_fio}ning vasiyatnomasini haqiqiy emas deb topishingizni.

2. Javobgar {notarial_idora} davlat notarial idorasi tomonidan {guvohnoma_yil} yilda {javobgar_fio}ning nomiga berilgan va rasmiy reestr kitobida tegishli raqam bilan qayd qilingan otam nomlaridan yozilib, imzolangan vasiyatnomadagi imzo va yozuvlar yuzasidan sud-xatshunoslik ekspertizasi tayinlashingizni.

3. Daʼvoni taʼminlash chorasini koʻrib, nizoli uy-joylarni tasarruf etilishining oldini olish maqsadida javobgar {notarial_idora}ning zimmasiga mazkur uy-joylar bilan bogʻliq birorta notarial harakatlarni amalga oshirishini taqiqlashingizni.



Ilova:
- Davlat boji toʻlanganligi haqida kvitansiya
- Daʼvo ariza nusxalari
- Pasport nusxasi
- Merosxoʻrlarning tugʻilganlik guvohnomasi nusxasi
- Uy-joyning kadastr hujjatlari va oldi-sotdi shartnomasi nusxasi
- Oʻlim guvohnomalari nusxasi
- Nikoh guvohnomasi nusxasi
- Meros ishiga oid hujjatlar nusxasi
- Hokim qarorlari nusxasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              20__ yil "___" __________
***
"""
    }
}
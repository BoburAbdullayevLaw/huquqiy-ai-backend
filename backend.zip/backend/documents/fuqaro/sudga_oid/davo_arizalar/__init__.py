"""Da'vo arizalar — barcha bo'limlarni yig'adi"""
import importlib, os
from pathlib import Path

HUJJATLAR = {}
BOLIMLAR = {}

_base = Path(__file__).parent
for _item in _base.iterdir():
    if _item.is_dir() and not _item.name.startswith('_'):
        try:
            _mod = importlib.import_module(f'.{_item.name}', package=__name__)
            _docs = getattr(_mod, 'HUJJATLAR', {})
            HUJJATLAR.update(_docs)
            BOLIMLAR[_item.name] = {"nomi": _item.name, "hujjatlar": _docs}
        except Exception as e:
            print(f"XATO {_item.name}: {e}")

# 1_4_zarar_yetkazish/yongin_natijasida_zarar.py
"""
Yongʻin natijasida yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-005": {
        "nomi": "Yongʻin natijasida yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 985-modda, MJtK 38, 211-moddalar, VMQ 17-band, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Yongʻin natijasida yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # JAMI SUMMA
            {"id": "jami_summa", "label": "Yongʻin natijasida yetkazilgan zararni undirish summasi", "type": "text",
             "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MULK HUQUQI
            {"id": "mulk_huquqi_sana", "label": "Daʼvogarga tegishli boʻlgan xonadonga nisbatan mulk huquqi berilgan sana",
             "type": "date", "required": True},
            {"id": "mulk_shartnoma_turi",
             "label": "Daʼvogarga tegishli boʻlgan xonadonga nisbatan mulk huquqini keltirib chiqargan shartnoma turi (oldi-sotdi, hadya, ayriboshlash, meros va boshqalar)",
             "type": "text", "required": True},

            # YONG'IN HODISASI
            {"id": "yongin_sana", "label": "Yongʻin hodisasi sodir boʻlgan sana", "type": "date", "required": True},
            {"id": "javobgar_uy_manzil", "label": "Javobgarning yashash manzili (yong'in sodir bo'lgan uy)", "type": "text",
             "required": True},

            # SUD QARORI
            {"id": "ma'muriy_sud_nomi", "label": "Yongʻin hodisasi yuzasidan yuritilgan maʼmuriy ishni koʻrib chiqqan sud nomi",
             "type": "text", "required": True},
            {"id": "jarima_miqdori",
             "label": "Maʼmuriy javobgarlikka tortish toʻgʻrisidagi qarorga asosan yetkazilgan zarar uchun belgilangan jarima miqdori",
             "type": "text", "required": True},

            # QO'SHIMCHA MA'LUMOT
            {"id": "qoshimcha_ma'lumot", "label": "Daʼvo arizani asoslovchi qo‘shimcha maʼlumotlar", "type": "textarea",
             "required": False},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilinayotgan hujjatlar ro‘yxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: Yongʻin natijasida yetkazilgan {jami_summa} soʻm zararni undirish toʻgʻrisida



                                                            DAʼVO ARIZA



Men {davogar_manzil} manzilida oila aʼzolarim bilan birga istiqomat qilib kelaman. Ushbu xonadon {mulk_huquqi_sana} da {mulk_shartnoma_turi} shartnomasiga asosan menga tegishli.

{yongin_sana} kuni {javobgar_uy_manzil} manzilida yashovchi qoʻshnim {javobgar_fio}ning uyida yongʻin boʻlib, uning uyi yonib ketdi. Uning uyi yonishi natijasida yongʻin meni uyimga ham oʻtdi. Yongʻin natijasida meni uyimga ham zarar yetdi.

Yongʻin hodisasi yuzasidan yuritilgan maʼmuriy ishni koʻrib chiqqan {ma'muriy_sud_nomi} tuman maʼmuriy sudining qaroriga asosan {javobgar_fio} Oʻzbekiston Respublikasi MJtKning 211-moddasiga asosan maʼmuriy javobgarlikka tortildi.

Sudning qaroriga binoan, javobgarga nisbatan {jarima_miqdori} miqdorida jarima belgilandi.

{qoshimcha_ma'lumot}

Ammo javobgar uyi yonishi natijasida yetkazilgan zararni qoplash haqida umuman oʻylab koʻrgani emas. Men javobgarga yetkazilgan zararni qoplashni soʻrab bir necha marotaba murojaat qilsamda, u rad javobini berib kelmoqda.

Oʻzbekiston Respublikasi MJtKning 38-moddasida maʼmuriy huquqbuzarlik sodir etgan shaxs maʼmuriy huquqbuzarlik oqibatida keltirilgan zararni qoplashi shartligi belgilab qoʻyilgan.

Turar joylarda yongʻin xavfsizligi qoidalarini buzish MJtKning 211-moddasiga asosan javobgarlikka tortilishi belgilangan, unga koʻra fuqarolarga bazaviy hisoblash miqdorining oʻndan bir qismidan bir baravarigacha, mansabdor shaxslarga esa - bir baravaridan uch baravarigacha miqdorda jarima solishga sabab boʻladi.

Oʻzbekiston Respublikasi Vazirlar Mahkamasining "Yongʻinlarni va ularning oqibatlarini hisobga olish, shuningdek yongʻinlarga doir axborotni toʻplash hamda oʻzaro almashish tartibi haqidagi nizomni tasdiqlash toʻgʻrisida" qarorining 17-bandiga asosan, yetkazilgan mulkiy zarar miqdoridan kelib chiqib, yongʻinlar quyidagilarga boʻlinadi:

a) koʻp boʻlmagan miqdorda zarar yetkazgan yongʻin (bazaviy hisoblash miqdorining oʻn baravaridan oʻttiz baravarigacha boʻlgan zarar);

b) ancha miqdorda zarar yetkazgan yongʻin (bazaviy hisoblash miqdorining oʻttiz baravaridan yuz baravarigacha boʻlgan miqdordagi zarar);

v) koʻp miqdorda zarar yetkazgan yongʻin (bazaviy hisoblash miqdorining yuz baravaridan uch yuz baravarigacha boʻlgan miqdordagi zarar);

g) juda koʻp miqdorda zarar yetkazgan yongʻin (bazaviy hisoblash miqdorining uch yuz baravari va undan ortiq boʻlgan miqdor).

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 985-moddasi 1-qismida "Gʻayriqonuniy harakat (harakatsizlik) tufayli fuqaroning shaxsiga yoki mol-mulkiga yetkazilgan zarar, shuningdek yuridik shaxsga yetkazilgan zarar, shu jumladan boy berilgan foyda zararni yetkazgan shaxs tomonidan toʻliq hajmda qoplanishi lozim"ligi nazarda tutilgan.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik kodeksining 985-moddasi hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgar tomonidan yetkazilgan {jami_summa} soʻm moddiy zararni undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
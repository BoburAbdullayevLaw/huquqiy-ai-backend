# 1_4_zarar_yetkazish/sogliqqa_yetkazilgan_zarar.py
"""
Fuqaroning sogʻligʻiga yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-007": {
        "nomi": "Fuqaroning sogʻligʻiga yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Mehnat kodeksi 189-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Fuqaroning sogʻligʻiga yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # JAMI SUMMA
            {"id": "jami_summa", "label": "Ishlab chiqarish jarayonida xodimning sogʻligʻiga yetkazilgan zarar summasi",
             "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI (YURIDIK SHAXS)
            {"id": "javobgar_nomi", "label": "Javobgar yuridik shaxsning toʻliq nomi", "type": "text",
             "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning joylashgan manzili", "type": "text", "required": True},
            {"id": "javobgar_hisob_raqami", "label": "Javobgarning Hisob raqami", "type": "text", "required": False},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_mfo", "label": "Javobgarning MFO raqami", "type": "text", "required": False},
            {"id": "javobgar_oked", "label": "Javobgarning OKED raqami", "type": "text", "required": False},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana",
             "label": "Daʼvogar egallab turgan vazifasida (lavozimida) qachondan buyon ishlab kelgan (ishga qabul qilingan sana)",
             "type": "date", "required": True},
            {"id": "korxona_nomi", "label": "Javobgar korxona nomi", "type": "text", "required": True},
            {"id": "lavozimi", "label": "Daʼvogar ishlab kelgan vazifa (lavozim) nomi", "type": "text",
             "required": True},

            # BAXTSIZ HODISHA
            {"id": "baxtsiz_hodisa_sana", "label": "Ishlab chiqarish jarayonida xodimning sogʻligʻiga zarar yetkazgan baxtsiz hodisa sodir boʻlgan sana",
             "type": "date", "required": True},
            {"id": "hodisa_mazmuni", "label": "Baxtsiz hodisaning qisqacha mazmuni", "type": "textarea",
             "required": True},
            {"id": "mehnat_qobiliyat_foizi", "label": "Daʼvogar baxtsiz hodisa natijasida mehnat qobiliyatining yoʻqotgan foizi",
             "type": "text", "required": True},
            {"id": "rasmiylashtirilgan_hujjatlar", "label": "Baxtsiz hodisa va uning oqibatlari yuzasidan rasmiylashtirilgan hujjatlar nomi",
             "type": "text", "required": True},

            # ZARAR TO'LANMASLIK SABABI
            {"id": "tolanmaslik_sababi", "label": "Sogʻliqqa yetkazilgan zarar toʻlanmasligining sabablari",
             "type": "textarea", "required": True},

            # ZARAR MIQDORI
            {"id": "zarar_summasi", "label": "Daʼvogar sogʻligʻiga yetkazilgan zarar summasi", "type": "text",
             "required": True},

            # DA'VO ASOSI
            {"id": "davo_asosi", "label": "Daʼvo talabiga asos sifatida keltirilgan hujjatlar roʻyxati va ishga oid boshqa holatlar",
             "type": "textarea", "required": True},

            # UNDIRILISHI SO'RALAYOTGAN SUMMA
            {"id": "undiriladigan_summa", "label": "Javobgardan undirilishi soʻralayotgan summa miqdori", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            Hisob raqami: {javobgar_hisob_raqami}
                                                            STIR: {javobgar_stir}
                                                            MFO: {javobgar_mfo}
                                                            OKED: {javobgar_oked}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: Ishlab chiqarish jarayonida {jami_summa} soʻm zararni undirish toʻgʻrisida



                                                            DAʼVO ARIZA



Men {ish_boshlagan_sana} yildan buyon {korxona_nomi} korxonasida {lavozimi} vazifasida ishlab kelganman.

{baxtsiz_hodisa_sana} yilda korxonada {hodisa_mazmuni} sodir boʻlganligi tufayli sogʻligʻimga zarar yetdi. Natijada men mehnat qobiliyatimning {mehnat_qobiliyat_foizi} foizini yoʻqotdim.

Mazkur holat boʻyicha {rasmiylashtirilgan_hujjatlar} kabi hujjatlar rasmiylashtirilgan.

Shunday boʻlsa-da, korxona tomonidan mening sogʻligʻimga yetkazilgan zararni toʻlash {tolanmaslik_sababi} kabi sabablarga asosan kechiktirilib, ijro qilinmasdan kelinmoqda.

Oʻzbekiston Respublikasi Mehnat kodeksining 189-moddasiga koʻra, xodimning sogʻligʻiga (mehnatda mayib boʻlishi, kasb kasalligiga chalinishi yoki u oʻz mehnat vazifalarini bajarish bilan bogʻliq holda sogʻligʻining boshqacha tarzda shikastlanishi) yetkazilgan zararni ish beruvchi toʻliq hajmda toʻlashi shart.

Bugungi kungacha mening sogʻligʻimni tiklashga ketgan xarajatlar {zarar_summasi} soʻmni tashkil qiladi. Daʼvo talabimga {davo_asosi} kabi hujjatlarni asos sifatida keltiraman.

Yuqoridagilarni inobatga olib, Mehnat kodeksining 189-moddasiga asosan



                                                            SOʻRAYMAN:



Javobgardan mening foydamga {undiriladigan_summa} soʻm miqdorida yetkazilgan zararni undirishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
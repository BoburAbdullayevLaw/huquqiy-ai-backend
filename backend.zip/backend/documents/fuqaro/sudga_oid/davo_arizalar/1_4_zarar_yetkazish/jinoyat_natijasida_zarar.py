# 1_4_zarar_yetkazish/jinoyat_natijasida_zarar.py
"""
Jinoyat natijasida yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-003": {
        "nomi": "Jinoyat natijasida yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 1022-modda, Konstitutsiya 26-modda, Oliy sud Plenumi 7-sonli qarori, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Jinoyat natijasida yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # JAMI SUMMA
            {"id": "jami_summa", "label": "Jinoyat natijasida yetkazilgan zararni undirish summasi", "type": "text",
             "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # JINOYAT MA'LUMOTLARI
            {"id": "jinoyat_sana", "label": "Jinoyat sodir etilgan sana", "type": "date", "required": True},
            {"id": "jinoyat_soat", "label": "Jinoyat sodir etilgan soat", "type": "text", "required": True},
            {"id": "jinoyat_manzil", "label": "Jinoyat sodir etilgan manzil", "type": "text", "required": True},
            {"id": "kelishmovchilik", "label": "Jinoyat sodir etilishiga sabab boʻlgan kelishmovchilik", "type": "textarea",
             "required": True},

            # SUD HUKMI
            {"id": "hukm_sud_nomi", "label": "Javobgarga nisbatan hukm chiqargan sud nomi", "type": "text",
             "required": True},
            {"id": "hukm_sana", "label": "Javobgarga nisbatan sud tomonidan hukm chiqarilgan sana", "type": "date",
             "required": True},
            {"id": "jk_modda", "label": "Javobgar Jinoyat kodeksining qaysi moddasi bilan javobgarlikka tortilgan",
             "type": "text", "required": True},
            {"id": "jk_qism", "label": "Javobgar Jinoyat kodeksining qismi bilan javobgarlikka tortilgan", "type": "text",
             "required": True},

            # ZARAR
            {"id": "davolanish_summa", "label": "Davolanish uchun sarflangan summa miqdori", "type": "text",
             "required": True},
            {"id": "manaviy_zarar", "label": "Daʼvo arizada undirib berish soʻralgan maʼnaviy zarar miqdori",
             "type": "text", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilingan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: Jinoyat natijasida yetkazilgan {jami_summa} soʻm zararni undirish haqida



                                                            DAʼVO ARIZA



Mening javobgar bilan ilgaridan oʻzaro kelishmovchiliklarimiz mavjud edi. Javobgar {jinoyat_sana} soat {jinoyat_soat} larda {jinoyat_manzil} hududida {kelishmovchilik} oʻzaro kelishmovchilik sabab jinoyat sodir etdi.

Javobgar shu kuni sodir etgan harakati uchun jinoyat ishlari boʻyicha {hukm_sud_nomi} tuman sudining {hukm_sana} kungi hukmiga asosan Oʻzbekiston Respublikasi JKning {jk_modda}-moddasi {jk_qism}-qismi bilan jinoiy javobgarlikka tortilgan.

Javobgar menga yetkazgan tan jarohati boʻyicha men oʻzimning hisobimdan davolandim. Tergov hamda sudga qatnab moddiy zarar koʻrdim. Bundan tashqari javobgarning xatti-harakatlari natijasida maʼnaviy azoblandim.

Men davolanishim uchun jami {davolanish_summa} soʻm sarfladim.

Oʻzbekiston Respublikasining Konstitutsiyasining 26-moddasi ikkinchi xatboshisiga binoan, hech kim qiynoqqa solinishi, zoʻravonlikka, shafqatsiz yoki inson qadr-qimmatini kamsituvchi boshqa tarzdagi tazyiqqa duchor etilishi mumkin emas.

Oʻzbekiston Respublikasi Oliy sudi Plenumining "Maʼnaviy zararni qoplash haqidagi qonunlarni qoʻllashning ayrim masalalari toʻgʻrisida"gi 2000-yil 28-apreldagi 7-sonli qarorining 2-bandiga muvofiq maʼnaviy zarar deganda jabrlanuvchiga qarshi sodir etilgan huquqbuzarlik harakati (harakatsizlik) oqibatida u boshidan kechirgan (oʻtkazgan) maʼnaviy va jismoniy (kamsitish, jismoniy ogʻriq, zarar koʻrish, noqulaylik va boshqa) azoblar tushuniladi.

Oʻzbekiston Respublikasi Fuqarolik kodeksining 1022-moddasiga asosan, maʼnaviy zarar pul bilan qoplanadi.

Maʼnaviy zararni qoplash miqdori jabrlanuvchiga yetkazilgan jismoniy va maʼnaviy azoblarning xususiyatiga, shuningdek ayb tovon toʻlashga asos boʻlgan hollarda zarar yetkazuvchining aybi darajasiga qarab sud tomonidan aniqlanadi. Zararni qoplash miqdorini aniqlashda oqilonalik va adolatlilik talablari eʼtiborga olinishi lozim.

Jismoniy va maʼnaviy azoblarning xususiyati maʼnaviy zarar yetkazilgan haqiqiy holatlar va jabrlanuvchining shaxsiy xususiyatlari hisobga olingan holda sud tomonidan baholanadi.

Maʼnaviy zarar toʻlanishi lozim boʻlgan mulkiy zarardan qatʼi nazar qoplanadi.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik kodeksining 1022-moddasi, hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgar tomonidan jinoyat natijasida yetkazilgan {davolanish_summa} soʻm moddiy va {manaviy_zarar} soʻm maʼnaviy zararni undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
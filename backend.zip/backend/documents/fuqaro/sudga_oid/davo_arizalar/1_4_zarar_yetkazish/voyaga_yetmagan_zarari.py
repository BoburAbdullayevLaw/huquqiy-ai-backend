# 1_4_zarar_yetkazish/voyaga_yetmagan_zarari.py
"""
Voyaga yetmagan shaxs tomonidan yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-004": {
        "nomi": "Voyaga yetmagan shaxs tomonidan yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 8, 993-moddalar, MJtK 38-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Voyaga yetmagan shaxs tomonidan yetkazilgan zararni undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # JAMI SUMMA
            {"id": "jami_summa", "label": "Voyaga yetmagan shaxs tomonidan yetkazilgan zarar summasi", "type": "text",
             "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI (OTA-ONA)
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O. (ota-onasi)", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # VOYAGA YETMAGAN SHAXS
            {"id": "voyaga_yetmagan_fio", "label": "Voyaga yetmagan shaxsning F.I.O.", "type": "text", "required": True},

            # ZARAR MA'LUMOTLARI
            {"id": "zarar_sana", "label": "Mol-mulkka zarar yetkazilgan sana", "type": "date", "required": True},
            {"id": "mulk_nomi", "label": "Zarar yetkazilgan mol-mulk nomi (turi)", "type": "text", "required": True},
            {"id": "hodisa_tafsiloti", "label": "Mol-mulkka zarar yetkazish hodisasining qisqacha tafsiloti",
             "type": "textarea", "required": True},
            {"id": "zarardan_soʻnggi_holat", "label": "Mol-mulkka yetkazilgan zarardan soʻnggi holat", "type": "text",
             "required": True},

            # MUTAXASSIS XULOSASI
            {"id": "xulosa_sana", "label": "Mutaxassis tomonidan xulosa tuzilgan sana", "type": "date",
             "required": True},
            {"id": "xulosa_zarar_miqdori",
             "label": "Mutaxassis xulosasiga koʻra mol-mulkka yetkazilgan moddiy zarar miqdori", "type": "text",
             "required": True},

            # QO'SHIMCHA MA'LUMOT
            {"id": "qoshimcha_ma'lumot", "label": "Ish holati yuzasidan qoʻshimcha maʼlumot", "type": "textarea",
             "required": False},

            # ILOVA
            {"id": "ilova", "label": "Ilova hujjatlarining roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: Voyaga yetmagan shaxs tomonidan {jami_summa} soʻm yetkazilgan zararni undirish toʻgʻrisida



                                                            DAʼVO ARIZA



Men oila aʼzolarim bilan {davogar_manzil} manzilida yashayman. Joriy yilning {zarar_sana} kuni oʻzimga tegishli boʻlgan {mulk_nomi} ga, qoʻshnim {javobgar_fio}ning 13 yoshli voyaga yetmagan farzandi {voyaga_yetmagan_fio} {hodisa_tafsiloti} mening mol-mulkimga zarar yetkazgan. Shundan soʻng, mol-mulk {zarardan_soʻnggi_holat} holatiga keldi.

Mutaxassisning {xulosa_sana} dagi xulosasiga koʻra mol-mulkimga {xulosa_zarar_miqdori} soʻmlik moddiy zarar yetkazilgan.

Shundan soʻng {voyaga_yetmagan_fio}ning otasi (onasi) {javobgar_fio}ning oldiga borib, farzandining qilgan ishi haqida aytib, mol-mulkga yetkazilgan zararni toʻlab berishini soʻradim. Ammo qoʻshnim {javobgar_fio} yetkazilgan zararni qoplab bermasligini maʼlum qildi.

Shundan soʻng men ushbu holat boʻyicha mahalla va profilaktika noziriga borib, ularga boʻlgan voqeani aytib berdim. Mahalla raisi va profilaktika noziri ishtirokida dalolatnoma tuzildi. Men bir necha marotaba javobgardan mulkimga yetkazilgan zararni toʻlab berishni soʻrasamda, javobgar bundan boʻyin tovladi.

{qoshimcha_ma'lumot}

Oʻzbekiston Respublikasi Fuqarolik kodeksining 8-moddasida fuqarolik huquq va burchlari boshqa shaxsga zarar yetkazish natijasida vujudga kelishi belgilab qoʻyilgan.

Oʻzbekiston Respublikasi Fuqarolik kodeksining 993-moddasi 1-qismi talabiga koʻra, oʻn toʻrt yoshgacha boʻlgan voyaga yetmagan (kichik yoshdagi bola) tomonidan yetkazilgan zarar uchun uning ota-onasi (farzandlikka oluvchilari) yoki vasiylari, agar zarar ularning aybi bilan yetkazilmaganligini isbotlay olmasalar, javobgar boʻladilar.

Oʻzbekiston Respublikasi MJtKning 38-moddasida maʼmuriy huquqbuzarlik sodir etgan shaxs maʼmuriy huquqbuzarlik oqibatida keltirilgan zararni qoplashi shartligi belgilab qoʻyilgan.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik kodeksining 993-moddasi, MJtKning 38-moddasi hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgardan meni mol-mulkimga yetkazilgan {xulosa_zarar_miqdori} soʻm miqdoridagi zararni undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
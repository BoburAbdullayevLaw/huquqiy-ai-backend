# 1_4_zarar_yetkazish/mulkka_yetkazilgan_zarar.py
"""
Mulkka yetkazilgan zararni undirish haqida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-006": {
        "nomi": "Mulkka yetkazilgan zararni undirish haqida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 985-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mulkka yetkazilgan zararni undirish haqida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # JAMI SUMMA
            {"id": "jami_summa", "label": "Mulkka yetkazilgan zarar summasi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MULK MA'LUMOTLARI
            {"id": "zarar_manzil", "label": "Zarar yetkazilgan xonadon joylashgan manzil", "type": "text",
             "required": True},
            {"id": "zarar_xonadon", "label": "Zarar yetkazilgan xonadon raqami", "type": "text", "required": True},
            {"id": "notarial_hudud", "label": "Notarial idora joylashgan hudud", "type": "text", "required": True},
            {"id": "notarial_idora", "label": "Notarial idora (Davlat notarial idora notariusi yoki Xususiy amaliyot bilan shugʻullanuvchi notarius F.I.O. bilan birga toʻliq koʻrsatiladi)",
             "type": "text", "required": True},
            {"id": "shartnoma_sana", "label": "Shartnoma tuzilgan sana", "type": "date", "required": True},
            {"id": "shartnoma_turi",
             "label": "Uy-joyga nisbatan mulk huquqi vujudga kelishiga asos boʻlgan shartnoma turi (oldi-sotdi, ayriboshlash, hadya v.h.)",
             "type": "text", "required": True},
            {"id": "qavat", "label": "Zarar yetkazilgan uy joylashgan qavat", "type": "text", "required": True},

            # JAVOBGAR XONADONI
            {"id": "javobgar_xonadon_manzil", "label": "Javobgarning xonadoni joylashgan manzil", "type": "text",
             "required": True},

            # ZARAR HODISASI
            {"id": "zarar_sana", "label": "Zarar yetkazilgan sana", "type": "date", "required": True},
            {"id": "hodisa_tafsiloti", "label": "Zarar yetkazish hodisasining qisqacha tafsiloti (suv toshirilganligi, yongʻin yoki boshqa hodisalar)",
             "type": "textarea", "required": True},
            {"id": "zarar_mazmuni", "label": "Hodisa natijasida yetkazilgan zararlarning qisqacha mazmuni",
             "type": "textarea", "required": True},
            {"id": "zarar_miqdori", "label": "Hodisa natijasida yetkazilgan zarar summasi", "type": "text",
             "required": True},

            # DALLILAR
            {"id": "dalillar", "label": "Daʼvo talabini tasdiqlovchi hujjatlar va boshqa dalillar", "type": "textarea",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: Mulkka yetkazilgan {jami_summa} soʻm zararlarni undirish haqida



                                                            DAʼVO ARIZA



{zarar_manzil} manzilida joylashgan {zarar_xonadon}-sonli xonadon {notarial_hudud} {notarial_idora} tomonidan {shartnoma_sana} yilda rasmiylashtirilgan {shartnoma_turi} shartnomasiga asosan menga tegishli.

Men yashaydigan xonadon koʻp qavatli turar joyning {qavat} qavatida joylashgan.

Mening qoʻshnim, yuqoridagi manzilda joylashgan uyning {javobgar_xonadon_manzil}-sonli xonadonida yashovchi {javobgar_fio} {zarar_sana} yilda uy-joydan foydalanishga oid xavfsizlik qoidalarini buzishi natijasida {hodisa_tafsiloti} hodisasi sodir boʻldi. Natijada {zarar_mazmuni}, yaʼni mening xonadonim hamda mening mol-mulkimga {zarar_miqdori} soʻm miqdorida zarar yetkazildi.

Mazkur holat {dalillar} bilan toʻliq oʻz isbotini topdi.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 985-moddasi 1-qismida "Gʻayriqonuniy harakat (harakatsizlik) tufayli fuqaroning shaxsiga yoki mol-mulkiga yetkazilgan zarar, shuningdek, yuridik shaxsga yetkazilgan zarar, shu jumladan boy berilgan foyda zararni yetkazgan shaxs tomonidan toʻliq hajmda qoplanishi lozim"ligi nazarda tutilgan.

Yuqoridagilarga hamda Oʻzbekiston Respublikasi Fuqarolik kodeksining 985-moddasi, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgar tomonidan mening xonadonimga yetkazilgan {zarar_miqdori} soʻm miqdoridagi moddiy zararni undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
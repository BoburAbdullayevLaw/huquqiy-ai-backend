# 1_4_zarar_yetkazish/qishloq_xojalik_mahsuloti_jarima.py
"""
Qishloq xo`jalik mahsulotini yetkazib bermaganligi uchun jarima undirish haqida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-001": {
        "nomi": "Qishloq xo`jalik mahsulotini yetkazib bermaganligi uchun jarima undirish haqida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 437-456-moddalar, Iqtisodiy protsessual kodeksi 148, 149, 151-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Qishloq xo`jalik mahsulotini yetkazib bermaganligi uchun jarima undirish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yuridik manzili", "type": "text", "required": True},
            {"id": "davogar_stir", "label": "Daʼvogarning STIR raqami", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yuridik manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # SHARTNOMA MA'LUMOTLARI
            {"id": "shartnoma_sana", "label": "Taraflar tomonidan tuzilgan kontrakatsiya shartnomasining sanasi",
             "type": "date", "required": True},
            {"id": "yetkazish_muddati", "label": "Javobgar tomonidan mahsulot yetkazib berilishi lozim bo`lgan sana",
             "type": "date", "required": True},
            {"id": "mahsulot_miqdori", "label": "Javobgar tomonidan yetkazib berilishi lozim bo`lgan mahsulot miqdori",
             "type": "text", "required": True},
            {"id": "mahsulot_nomi", "label": "Yetkazib berilishi lozim bo`lgan qishloq xo`jaligi mahsuloti nomi",
             "type": "text", "required": True},

            # TO'LOV MA'LUMOTLARI
            {"id": "tolov_sanasi", "label": "Javobgarning hisob raqamiga pul o`tkazilgan sana", "type": "date",
             "required": True},
            {"id": "tolov_raqami", "label": "To`lov topshirig`i raqami", "type": "text", "required": True},
            {"id": "oldindan_tolov", "label": "Oldindan o`tkazib berilgan summa miqdori", "type": "text",
             "required": True},

            # JARIMA
            {"id": "jarima_miqdori", "label": "Daʼvogar tomonidan talab qilinayotgan jarima miqdori", "type": "text",
             "required": True},

            # TALABNOMA
            {"id": "talabnoma_sanasi", "label": "Daʼvogar tomonidan yuborilgan talabnoma sanasi", "type": "date",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Yuridik manzil: {davogar_manzil}
                                                            STIR: {davogar_stir}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Yuridik manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}



                                                            DAʼVO ARIZASI

                                      (Qishloq xo`jalik mahsulotini yetkazib bermaganligi 
                                                 uchun jarima undirish haqida)



Taraflar tomonidan {shartnoma_sana} da tuzilgan kontraktatsiya shartnomasiga muvofiq javobgar {yetkazish_muddati} ga qadar {mahsulot_miqdori} miqdorida {mahsulot_nomi} yetkazib berish majburiyatini olgan edi.

Qayd etib o`tilgan shartnomaga binoan biz javobgarning hisob raqamiga {tolov_sanasi} kuni {tolov_raqami} raqamli to`lov topshirig`i bilan oldindan {oldindan_tolov} so`m o`tkazdik.

Javobgar shartnoma bo`yicha o`z majburiyatini bajarmadi, yaʼni belgilangan muddatda mahsulotni topshirishdan asossiz bo`yin tovladi.

Yuqorida ko`rsatilgan shartnomaga va "Qishloq xo`jaligi mahsulotlari yetishtiruvchilar bilan tayyorlov, xizmat ko`rsatish tashkilotlari o`rtasida shartnomalar tuzish, ularni ro`yxatdan o`tkazish, bajarish, shuningdek ularning bajarilishi monitoringini olib borish tartibi to`g`risida"gi Nizomning 67-bandiga muvofiq, qishloq xo`jalik mahsulotlarini shartnomada belgilangan muddatlarda topshirishdan asossiz bo`yin tovlaganligi uchun xo`jalik tayyorlovchiga topshirilmagan mahsulot qiymatining 30 foizi miqdorida jarima to`lashi ko`zda tutilgan.

Jarima summasi daʼvo arizasiga ilova qilinayotgan hisob-kitobga ko`ra, {jarima_miqdori} so`mni tashkil etadi.

Bizning {talabnoma_sanasi} da yuborgan talabnomamizni javobgar javobsiz qoldirdi (qanoatlantirmadi).

Yuqoridagilarga hamda Oʻzbekiston Respublikasi Fuqarolik kodeksining 437-456-moddalari, Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 148, 149 va 151-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgardan bizning foydamizga {jarima_miqdori} so`m jarima summasini undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
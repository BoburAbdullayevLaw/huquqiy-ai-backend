# 1_4_zarar_yetkazish/zarar_va_penya_undirish.py
"""
Yetkazilgan zararni va penyani undirish to‘g‘risida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-ZY-002": {
        "nomi": "Yetkazilgan zararni va penyani undirish to‘g‘risida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 259-312, 324-325-moddalar, Xo‘jalik yurituvchi subyektlar faoliyatining shartnomaviy-huquqiy bazasi to‘g‘risida”gi Qonun 34-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Yetkazilgan zararni va penyani undirish to‘g‘risida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo arizasi imzolangan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # SHARTNOMA MA'LUMOTLARI
            {"id": "shartnoma_nomi", "label": "Shartnomaning nomi", "type": "text", "required": True},
            {"id": "shartnoma_sana", "label": "Shartnoma imzolangan sana", "type": "date", "required": True},
            {"id": "shartnoma_raqami", "label": "Shartnomaning raqami", "type": "text", "required": True},
            {"id": "shartnoma_predmeti", "label": "Shartnoma predmeti", "type": "text", "required": True},
            {"id": "bajarilmagan_bandlar", "label": "Shartnomaning bajarilmagan bandlari raqami", "type": "text",
             "required": True},

            # ZARAR MA'LUMOTLARI
            {"id": "zarar_haqida", "label": "Yuzaga kelgan zarar haqida maʼlumot", "type": "textarea",
             "required": True},
            {"id": "zarar_miqdori", "label": "Vujudga kelgan zarar miqdori", "type": "text", "required": True},

            # PENYA
            {"id": "penya_miqdori", "label": "Undirib berilishi so‘ralayotgan penya miqdori", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilingan hujjatlar", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi} tumanlararo sudiga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}



                                                            DAʼVO ARIZA

                                      (Yetkazilgan zararni va penyani undirish toʻgʻrisida)



{shartnoma_sana} sanasida fuqaro {javobgar_fio} bilan {shartnoma_nomi} toʻgʻrisidagi shartnomani tuzdik. Oʻrtamizda tuzilgan shartnomada {shartnoma_predmeti} amalga oshirishni shartnoma predmeti sifatida belgiladik. Shartnomaning barcha rekvizitlari va mazmunini toʻliq belgiladik. Bundan tashqari shartnomani bajarish muddatlarini ham aniq kelishdik.

Ammo javobgar {javobgar_fio} shartnomaning {bajarilmagan_bandlar} bandlarini bajarmadi va natijada {zarar_haqida}. {zarar_miqdori} soʻm miqdorida zarar yetdi.

Javobgarga bu haqda bir necha marta xabardor qilganim bilan hozirgacha shartnoma shartlarini bajarmasdan kelmoqda va qarzdorligini ham qoplamagan.

Oʻzbekiston Respublikasi Fuqarolik kodeksining 324 va 325-moddalariga koʻra, qarzdor majburiyatni bajarmaganligi yoki lozim darajada bajarmaganligi tufayli kreditorga yetkazilgan zararni toʻlashi shart. Agar qonunchilikda yoki shartnomada oʻzgacha tartib nazarda tutilgan boʻlmasa, zararni aniqlashda majburiyat bajarilishi kerak boʻlgan joyda, qarzdor kreditorning talablarini ixtiyoriy qanoatlantirgan kunda, bordi-yu, talab ixtiyoriy qanoatlantirilgan boʻlmasa, — daʼvo qoʻzgʻatilgan kunda mavjud boʻlgan narxlar eʼtiborga olinadi. Sud vaziyatga qarab, zararni toʻlash haqidagi talabni qaror chiqarilgan kunda mavjud boʻlgan narxlarni eʼtiborga olgan holda qanoatlantirishi mumkin.

Agar majburiyatni bajarmaganlik yoki lozim darajada bajarmaganlik uchun neustoyka belgilangan boʻlsa, zararning neustoyka bilan qoplanmagan qismi toʻlanadi.

Qonunda yoki shartnomada zararni emas, balki faqat neustoykani undirib olishga yoʻl qoʻyiladigan; zarar ham neustoykadan tashqari toʻla hajmda undirib olinishi mumkin boʻlgan; kreditorning tanloviga koʻra yoki neustoyka yoxud zarar undirib olinishi mumkin boʻlgan hollar belgilanishi mumkin.

Oʻzbekiston Respublikasining "Xo‘jalik yurituvchi subyektlar faoliyatining shartnomaviy-huquqiy bazasi to‘g‘risida"gi Qonunining 34-moddasiga koʻra, neustoyka (jarima, penya) to‘laganligidan qat’i nazar, shartnoma majburiyatlarini buzgan taraf ikkinchi tarafga ana shu zarar oqibatida o‘zi yetkazgan zarar qismini ham qoplaydi.

Yetkazilgan zararlarga shartnoma majburiyatlari bajarilmaganligi yoki lozim darajada bajarilmaganligi, mol-mulk yo‘qolishi yoki shikastlanishi munosabati bilan taraf qilgan yoki qilishi lozim bo‘lgan xarajatlar, shuningdek agar ikkinchi taraf shartnoma majburiyatlarini bajarganida taraf olishi mumkin bo‘lgan, lekin ololmay qolgan daromadlar kiradi.

Yuqoridagilardan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik kodeksining 259-312 va 324-325-moddalariga asosan,



                                                            SOʻRAYMAN:



Javobgar {javobgar_fio} dan meni foydamga {zarar_miqdori} soʻm zarar uchun hamda shartnoma shartlarini bajarmaganligi uchun {penya_miqdori} soʻm miqdorida penya undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
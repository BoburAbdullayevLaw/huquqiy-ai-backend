# 1_2_uyjoy_nizolari/ijara_haqi_undirish.py
"""
Ijara toʻlovlari boʻyicha qarzdorlikni undirish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-UJ-001": {
        "nomi": "Ijara toʻlovlari boʻyicha qarzdorlikni undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 535, 543, 237-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ijara toʻlovlari boʻyicha qarzdorlikni undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # JAMI SUMMA
            {"id": "jami_summa", "label": "Undirilishi soʻralayotgan ijara haqi va penyaning umumiy summasi",
             "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # IJARA SHARTNOMASI
            {"id": "shartnoma_sana", "label": "Ijara shartnomasi tuzilgan sana", "type": "date", "required": True},
            {"id": "shartnoma_raqami", "label": "Ijara shartnomasining raqami", "type": "text", "required": True},
            {"id": "tolash_muddati", "label": "Shartnomaga asosan ijara haqi toʻlash muddati", "type": "text",
             "required": True},

            # QARZDORLIK
            {"id": "qarzdorlik_miqdori", "label": "Ijara toʻlovlari boʻyicha kelib chiqqan qarzdorlik miqdori",
             "type": "text", "required": True},

            # PENYA
            {"id": "penya_foizi", "label": "Ijara toʻlovi kechiktirilgan har bir kun uchun toʻlanishi lozim boʻlgan penya miqdori (foizda)",
             "type": "text", "required": True},
            {"id": "penya_umumiy_foizi", "label": "Ijara toʻlovi kechiktirilganligi uchun toʻlanishi lozim boʻlgan penyaning umumiy summasi miqdori (foizda)",
             "type": "text", "required": True},
            {"id": "penya_summa", "label": "Belgilangan muddatda toʻlanmagan ijara toʻlovlari uchun hisoblangan jami penya miqdori",
             "type": "text", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinadigan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: Ijara toʻlovlari boʻyicha {jami_summa} soʻm qarzdorlikni undirish toʻgʻrisida



                                                            DAʼVO ARIZASI



Men va {javobgar_fio} oʻrtamizda {shartnoma_sana} da {shartnoma_raqami}-sonli ijara shartnomasi tuzilgan. Ushbu shartnomaga koʻra, belgilangan ijara toʻlovini oʻz vaqtida, belgilangan muddatda va miqdorda mening tranzit hisob raqamimga toʻlashi, ijaraga oluvchi shartnomada koʻrsatilgan, ijara haqi toʻlashi, birinchi toʻlovni shartnoma roʻyxatga olingan sanadan boshlab {tolash_muddati} kun ichida amalga oshirishi va kelgusi toʻlovlarni shartnomaning koʻrsatilgan jadvalga asosan har chorakning birinchi oyining yigirmanchi kunidan kechiktirmasdan toʻlashi belgilangan.

Ijaraga oluvchi shartnoma majburiyatini buzib, {qarzdorlik_miqdori} soʻm qarzdorlikni toʻlamasdan kelgan. Shartnomada ijaraga oluvchi belgilangan ijara toʻlovini oʻz vaqtida va miqdorda toʻlamaganligi uchun ijaraga beruvchiga kechiktirilgan har bir kun uchun toʻlov summasining {penya_foizi} foizi miqdorida, ammo kechiktirilgan toʻlov summasining {penya_umumiy_foizi} foizidan ortiq boʻlmagan miqdorda penya toʻlashi belgilangan.

Shartnoma shartlaridan kelib chiqqan holda belgilangan muddatda toʻlanmagan ijara toʻlovlari uchun jami {penya_summa} soʻm penya hisoblandi. Qarzdorga bu haqda xabarnoma yuborilgan boʻlsada, u tomonidan eʼtiborsiz qoldirilgan.

Oʻzbekiston Respublikasining Fuqarolik Kodeksining 535-moddasiga binoan, mulk ijarasi shartnomasi boʻyicha ijaraga beruvchi ijaraga oluvchiga haq evaziga mol-mulkni vaqtincha egalik qilish va foydalanish yoki foydalanish uchun topshirish majburiyatini oladi.

Shuningdek, 543-moddasida ijaraga oluvchi mol-mulkdan foydalanganlik uchun haqni oʻz vaqtida toʻlab turishi shart.

Mol-mulkdan foydalanganlik uchun haq toʻlash tartibi, shartlari va muddatlari mulk ijarasi shartnomasi bilan belgilanadi. Bular shartnomada belgilanmagan hollarda odatda xuddi shunday mol-mulkni oʻxshash holatlarda ijaraga berishda qoʻllaniladigan tartib, shartlar va muddatlar belgilangan deb hisoblanadi.

Oʻzbekiston Respublikasi Oliy Xoʻjalik sudi Plenumining "Mulk ijarasi shartnomasiga oid fuqarolik qonun hujjatlari normalarini iqtisodiy sudlar tomonidan qoʻllashning ayrim masalalari toʻgʻrisida" 2011-yil 1-dekabr 234-sonli qarorining 9-bandiga asosan, mulk ijarasi shartnomasi haq evaziga tuziladigan shartnoma hisoblanadi, shu sababli ijaraga oluvchining asosiy majburiyatlaridan biri mulkdan foydalanganlik uchun haqni, yaʼni ijara haqini oʻz vaqtida toʻlashdir.

Yuqoridagilarga asosan, Fuqarolik kodeksining 543, 237-moddalari hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189-191-moddalariga asosan,



                                                            SOʻRAYMAN:



Javobgar {javobgar_fio} dan mening foydamga {qarzdorlik_miqdori} soʻm miqdoridagi ijara toʻlovlari boʻyicha qarzdorlikni hamda unga hisoblangan {penya_summa} soʻm penyani, jami {jami_summa} soʻmni undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
# 1_2_uyjoy_nizolari/mulk_huquqi_belgilash.py
"""
Mulk huquqini belgilash toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-UJ-003": {
        "nomi": "Mulk huquqini belgilash toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 16, 17, 18, 19, 20, 21-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mulk huquqini belgilash toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MULK MA'LUMOTLARI
            {"id": "mulk_turi", "label": "Mulk turi (uy, xonadon, yer uchastkasi, avtomobil va h.k.)",
             "type": "text", "required": True},
            {"id": "mulk_manzili", "label": "Mulkning manzili (joylashgan yeri)", "type": "text", "required": True},
            {"id": "mulk_tavsifi", "label": "Mulkning tavsifi (maydoni, qavati, xonalar soni va h.k.)",
             "type": "textarea", "required": True},
            {"id": "mulk_qiymati", "label": "Mulkning qiymati", "type": "text", "required": True},

            # HUQUQ ASOSI
            {"id": "huquq_asosi", "label": "Mulk huquqiga ega boʻlish asosi (sotib olish, meros, hadya va h.k.)",
             "type": "text", "required": True},
            {"id": "huquq_hujjati", "label": "Huquqni tasdiqlovchi hujjat (shartnoma, guvohnoma va h.k.)",
             "type": "text", "required": True},
            {"id": "huquq_sanasi", "label": "Huquq vujudga kelgan sana", "type": "date", "required": True},

            # NIZO SABABI
            {"id": "nizo_sababi", "label": "Mulk huquqi tan olinmayotganligi sababi", "type": "textarea",
             "required": True},
            {"id": "daʼvogar_dalillari", "label": "Daʼvogarning mulkka egaligini tasdiqlovchi dalillar",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinadigan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                                (Mulk huquqini belgilash toʻgʻrisida)



Men {davogar_fio} quyidagi mulkka nisbatan oʻz huquqimni himoya qilish uchun sudga murojaat qilmoqdaman:

Mulk turi: {mulk_turi}
Manzili: {mulk_manzili}
Tavsifi: {mulk_tavsifi}
Qiymati: {mulk_qiymati} soʻm

Ushbu mulkka boʻlgan huquqim {huquq_asosi} asosida vujudga kelgan. {huquq_sanasi} kuni tuzilgan {huquq_hujjati} bilan bu holat tasdiqlanadi.

Biroq, javobgar {javobgar_fio} tomonidan {nizo_sababi} sababli mulkka boʻlgan huquqim tan olinmayapti va daʼvo qilinmoqda. Aslida esa, {daʼvogar_dalillari}.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 16-moddasiga koʻra, mulkdor oʻz mulkiga boʻlgan huquqini himoya qilish uchun sudga murojaat qilishga haqli.

Fuqarolik Kodeksining 17-moddasiga asosan, mulkdor oʻz mulkiga nisbatan har qanday huquqbuzarliklarni, garchi bu huquqbuzarliklar mulkdorlikdan mahrum qilish bilan bogʻliq boʻlmasa ham, bartaraf qilishni talab qilishga haqli.

Fuqarolik Kodeksining 18-moddasiga muvofiq, mulkdor mulkini boshqa shaxslarning noqonuniy egaligidan talib olish huquqiga ega.

Fuqarolik Kodeksining 19-moddasiga koʻra, mulkdor mulkiga boʻlgan huquqini himoya qilish uchun daʼvo qilish muddati uch yil.

Fuqarolik Kodeksining 20-moddasiga asosan, mulkdor oʻz mulkiga boʻlgan huquqini tan olishni talab qilishga haqli.

Fuqarolik Kodeksining 21-moddasiga muvofiq, mulkdor mulkiga boʻlgan huquqini buzayotgan yoki buzish xavfini tugʻdirayotgan xatti-harakatlarni bartaraf qilishni talab qilishga haqli.

Yuqoridagilarga asosan, Oʻzbekiston Respublikasi Fuqarolik Kodeksining 16, 17, 18, 19, 20, 21-moddalari hamda Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



1. Men {davogar_fio} ning {mulk_manzili} manzilida joylashgan {mulk_turi} ga boʻlgan mulk huquqini belgilab berishingizni.

2. Javobgar {javobgar_fio} ning ushbu mulkka boʻlgan daʼvolarini rad etishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
# 1_2_uyjoy_nizolari/ijara_shartnomasi_bekor_qilish.py
"""
Ijara shartnomasini bekor qilish toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-UJ-002": {
        "nomi": "Ijara shartnomasini bekor qilish toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 535, 543, 545, 552-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ijara shartnomasini bekor qilish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # IJARA SHARTNOMASI
            {"id": "shartnoma_sana", "label": "Ijara shartnomasi tuzilgan sana", "type": "date", "required": True},
            {"id": "shartnoma_raqami", "label": "Ijara shartnomasining raqami", "type": "text", "required": True},
            {"id": "muddat", "label": "Shartnoma muddati", "type": "text", "required": True},
            {"id": "ijara_haqi", "label": "Ijara haqi miqdori", "type": "text", "required": True},

            # BUZILISH SABABI
            {"id": "buzilish_sababi", "label": "Shartnomani buzish sababi", "type": "textarea", "required": True},
            {"id": "qarzdorlik_miqdori", "label": "Ijara haqi boʻyicha qarzdorlik miqdori", "type": "text",
             "required": False},

            # OGOHLANTIRISH
            {"id": "ogohlantirish_sanasi", "label": "Javobgar ogohlantirilgan sana", "type": "date", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinadigan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                            (Ijara shartnomasini bekor qilish toʻgʻrisida)



Men {davogar_fio} va {javobgar_fio} oʻrtamizda {shartnoma_sana} kuni {shartnoma_raqami}-sonli ijara shartnomasi tuzilgan. Ushbu shartnomaga koʻra, men {javobgar_fio} ga tegishli boʻlgan mol-mulkni {muddat} muddatga ijaraga berganman va har oy uchun {ijara_haqi} soʻm miqdorida ijara haqi belgilangan.

Biroq, javobgar tomonidan shartnoma shartlari {buzilish_sababi} sababli buzilmoqda. {f"Javobgar tomonidan ijara haqi {qarzdorlik_miqdori} soʻm miqdorida toʻlanmagan." if qarzdorlik_miqdori else ""}

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 535-moddasiga binoan, mulk ijarasi shartnomasi boʻyicha ijaraga beruvchi ijaraga oluvchiga haq evaziga mol-mulkni vaqtincha egalik qilish va foydalanish yoki foydalanish uchun topshirish majburiyatini oladi.

Shuningdek, Fuqarolik Kodeksining 543-moddasiga asosan, ijaraga oluvchi mol-mulkdan foydalanganlik uchun haqni oʻz vaqtida toʻlab turishi shart.

Fuqarolik Kodeksining 545-moddasiga koʻra, ijaraga oluvchi mol-mulkdan foydalanganlik uchun haqni shartnomada belgilangan muddatlarda toʻlamasa, ijaraga beruvchi undan toʻlovni talab qilish bilan birga shartnomani bekor qilishni ham talab qilishga haqli.

Fuqarolik Kodeksining 552-moddasiga asosan, ijaraga beruvchi ijaraga oluvchi tomonidan shartnoma shartlarini buzgan taqdirda, shartnomani bekor qilishni talab qilishga haqli.

Men javobgarni {ogohlantirish_sanasi} kuni yozma ravishda ogohlantirgan boʻlsamda, javobgar tomonidan shartnoma shartlari bartaraf etilmadi va ijara haqi toʻlanmadi.

Yuqoridagilarga asosan, Oʻzbekiston Respublikasi Fuqarolik Kodeksining 535, 543, 545, 552-moddalari hamda Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



1. Men {davogar_fio} va {javobgar_fio} oʻrtasida tuzilgan {shartnoma_sana} kungi {shartnoma_raqami}-sonli ijara shartnomasini bekor qilishingizni.

2. Javobgar {javobgar_fio} ni ijaraga olingan mol-mulkni boʻshatib, menga topshirishga majbur qilishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
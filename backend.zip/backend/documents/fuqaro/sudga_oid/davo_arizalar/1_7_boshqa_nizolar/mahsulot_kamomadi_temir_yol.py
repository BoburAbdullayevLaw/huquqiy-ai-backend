# 1_7_boshqa_nizolar/mahsulot_kamomadi_temir_yol.py
"""
Mahsulot kamomadi qiymatini undirish to`g`risida da'vo arizasi (yuki tekshirib berilgan hamda temiryo`l orqali yuborilgan hollarda)
"""

HUJJATLAR = {
    "FQ-BN-003": {
        "nomi": "Mahsulot kamomadi qiymatini undirish to`g`risida da'vo arizasi (yuki tekshirib berilgan hamda temiryo`l orqali yuborilgan hollarda)",
        "jpk": "Fuqarolik Kodeksi 437-456-moddalar, Iqtisodiy protsessual kodeksi 148, 149, 151-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mahsulot kamomadi qiymatini undirish to`g`risida da'vo arizasi (yuki tekshirib berilgan hamda temiryo`l orqali yuborilgan hollarda)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yuridik manzili", "type": "text", "required": True},
            {"id": "davogar_stir", "label": "Daʼvogarning STIR raqami", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yuridik manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # YUK MA'LUMOTLARI
            {"id": "temir_yol_varakasi", "label": "Temiryo`l varaqasining raqami", "type": "text", "required": True},
            {"id": "vagon_raqami", "label": "Mahsulot yetkazib berilgan vagon raqami", "type": "text", "required": True},
            {"id": "kamomad_miqdori", "label": "Aniqlangan kamomad miqdori", "type": "text", "required": True},

            # TIJORAT DALOLATNOMASI
            {"id": "dalolatnoma_sana", "label": "Tijorat dalolatnomasi tuzilgan sana", "type": "date", "required": True},
            {"id": "dalolatnoma_soni", "label": "Tijorat dalolatnomasi soni", "type": "text", "required": True},

            # TO'LOV
            {"id": "tolov_sanasi", "label": "Daʼvogar tomonidan to`lov amalga oshirilgan sana", "type": "date",
             "required": True},
            {"id": "tolov_raqami", "label": "To`lov topshirig`i raqami", "type": "text", "required": True},

            # UMUMIY KAMOMAD
            {"id": "umumiy_kamomad", "label": "Umumiy kamomad miqdori", "type": "text", "required": True},

            # TALABNOMA
            {"id": "talabnoma_sanasi", "label": "Daʼvogar tomonidan talabnoma yuborilgan sana", "type": "date",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Yuridik manzil: {davogar_manzil}
                                                            STIR: {davogar_stir}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Yuridik manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}



                                                            DAʼVO ARIZA

                     (Mahsulot kamomadi qiymatini undirish to`g`risida - yuki tekshirib berilgan 
                               hamda temiryo`l orqali yuborilgan hollarda)



Bizning manzilimizga {temir_yol_varakasi} raqamli temir yo`l varaqasi orqali {vagon_raqami}-sonli vagonda kelgan yukni temir yo`l xodimlari tomonidan tekshirib topshirish vaqtida yuk saqlanmagan holatda va {kamomad_miqdori} kamomad bilan kelganligi aniqlandi va ular {dalolatnoma_sana} kuni tuzilgan, {dalolatnoma_soni}-sonli tijorat dalolatnomasi va umumiy shakldagi dalolatnomalar bilan tasdiqlangan.

Mahsulot qiymati daʼvogar tomonidan {tolov_sanasi} kuni {tolov_raqami} raqamli to`lov topshirig`i orqali to`langan.

Hisobga asosan kamomad qiymati {umumiy_kamomad} so`mni tashkil qiladi.

Bizning {talabnoma_sanasi} kuni yuborgan talabnomamizni javobgar javobsiz qoldirdi, asossiz qanoatlantirmadi.

Yuqoridagilarga hamda Oʻzbekiston Respublikasi Fuqarolik kodeksining 437-456-moddalari, Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 148, 149 va 151-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgardan bizning foydamizga {umumiy_kamomad} so`m kamomad qiymatini undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
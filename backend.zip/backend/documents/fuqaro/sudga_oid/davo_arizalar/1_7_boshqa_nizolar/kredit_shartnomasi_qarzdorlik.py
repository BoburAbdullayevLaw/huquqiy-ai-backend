# 1_7_boshqa_nizolar/kredit_shartnomasi_qarzdorlik.py
"""
Kredit shartnomasi bo‘yicha qarzdorlikni undirish to‘g‘risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-005": {
        "nomi": "Kredit shartnomasi bo‘yicha qarzdorlikni undirish to‘g‘risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 734-740, 746-752-moddalar, Iqtisodiy protsessual kodeksi 148, 149, 151-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Kredit shartnomasi bo‘yicha qarzdorlikni undirish to‘g‘risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR (BANK) MA'LUMOTLARI
            {"id": "bank_nomi", "label": "Bank nomi", "type": "text", "required": True},
            {"id": "bank_filiali", "label": "Bank filiali", "type": "text", "required": True},

            # JAVOBGAR (QARZ OLUVCHI) MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": True},

            # KREDIT SHARTNOMASI
            {"id": "kredit_shartnoma_sana", "label": "Kredit shartnomasi tuzilgan sana", "type": "date", "required": True},
            {"id": "kredit_shartnoma_raqami", "label": "Kredit shartnomasi raqami", "type": "text", "required": True},
            {"id": "kredit_summa", "label": "Kredit summasi (so'z bilan)", "type": "text", "required": True},
            {"id": "kredit_summa_raqam", "label": "Kredit summasi (raqam bilan)", "type": "text", "required": True},
            {"id": "kredit_muddati", "label": "Kredit muddati (so'z bilan)", "type": "text", "required": True},
            {"id": "kredit_maqsadi", "label": "Kredit maqsadi", "type": "text", "required": True},

            # GAROV SHARTNOMASI
            {"id": "garov_shartnoma_sana", "label": "Garov shartnomasi tuzilgan sana", "type": "date", "required": True},
            {"id": "garov_shartnoma_turi", "label": "Garov shartnomasi turi", "type": "text", "required": True},
            {"id": "garov_mulk_manzili", "label": "Garovga qo'yilgan mulk manzili", "type": "text", "required": True},
            {"id": "garov_mulk_raqami", "label": "Garovga qo'yilgan uy-joy raqami", "type": "text", "required": True},
            {"id": "garov_bahosi", "label": "Garov bahosi", "type": "text", "required": True},

            # QARZDORLIK
            {"id": "qarzdorlik_kuni", "label": "Qarzdorlik hisoblangan kun", "type": "date", "required": True},
            {"id": "jami_qarzdorlik", "label": "Jami qarzdorlik", "type": "text", "required": True},
            {"id": "muddati_otgan_foiz", "label": "Muddati o'tgan kredit foizi qarzdorligi", "type": "text",
             "required": True},
            {"id": "hisoblangan_foiz", "label": "Hisoblangan foiz qarzdorligi", "type": "text", "required": True},
            {"id": "muddatli_asosiy_qarz", "label": "Muddatli asosiy qarzdorlik", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Daʼvogar: {bank_nomi} {bank_filiali} filiali

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Kredit shartnomasi boʻyicha qarzdorlikni undirish toʻgʻrisida)



{bank_nomi} hamda fuqaro {javobgar_fio} oʻrtasida {kredit_shartnoma_sana} kuni № {kredit_shartnoma_raqami}-sonli kredit shartnomasi tuzilgan. Shartnoma shartlariga koʻra bank qarz oluvchining {kredit_maqsadi} uchun {kredit_summa} soʻm miqdorida kredit mablagʻi ajratgan.

Kreditdan foydalanish muddati – {kredit_muddati} yil.

{kredit_shartnoma_sana} kuni tuzilgan {garov_shartnoma_turi} shartnomasiga asosan fuqaro {javobgar_fio}ga tegishli boʻlgan, {garov_mulk_manzili} manzilida joylashgan № {garov_mulk_raqami}-sonli uy-joy {garov_bahosi} soʻm miqdoridagi bahoda kredit shartnomasidagi majburiyatlarning bajarilishi taʼminoti sifatida garovga qoʻyilgan.

Qarzdor tomonidan kredit shartnomasining shartlari buzilgan, muddati oʻtgan asosiy kredit qarzdorligi hamda muddati oʻtgan kredit foizi qarzdorligi yuzaga kelgan.

Kredit shartnomasining tegishli bandiga koʻra, qarz oluvchi tomonidan shartnomaga ilova qilingan toʻlovlar jadvaliga muvofiq har oylik toʻlovlarni amalga oshirish yoʻli bilan kredit asosiy qarzi va unga hisoblangan foizlarni toʻlab borish majburiyati olingan. Lekin, qarz oluvchi tomonidan kredit shartnomasining ushbu bandi talablari muntazam ravishda buzilib kelingan.

Javobgarning kredit shartnomasi boʻyicha {qarzdorlik_kuni} kuni holatiga jami qarzdorligi {jami_qarzdorlik} soʻmni tashkil qiladi, jumladan:
- muddati oʻtgan kredit foizi qarzdorligi – {muddati_otgan_foiz} soʻm;
- hisoblangan foiz qarzdorligi – {hisoblangan_foiz} soʻm;
- muddatli asosiy qarzdorlik – {muddatli_asosiy_qarz} soʻm.

Qarz oluvchiga kredit asosiy qarzi va unga hisoblangan foizlarni toʻlash yuzasidan berilgan talabnomalar ijrosiz qoldirilib, qarz oluvchi tomonidan ushbu talablar bajarilmasdan kelinmoqda.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik Kodeksining 734-740, 746-752-moddalariga asosan,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} dan {bank_nomi} {bank_filiali} filiali foydasiga jami {jami_qarzdorlik} soʻm kredit qarzdorligini undirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Kredit shartnomasi
3. Garov shartnomasi
4. Pasport nusxasi
5. Yashash joyidan maʼlumotnoma
6. Qarzdorlik toʻgʻrisida maʼlumotnoma
7. Ogohlantirish xatlari
8. Davlat boji toʻlanganligi toʻgʻrisida kvitansiya



                                                              Daʼvogar: {bank_nomi} {bank_filiali} filiali

                                                              _________________
                                                                   (imzo)

                                                              {kredit_shartnoma_sana} yil.
***
"""
    }
}
# 1_7_boshqa_nizolar/sifatsiz_tovarni_almashirish.py
"""
Sifatsiz tovarni almashtirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-011": {
        "nomi": "Sifatsiz tovarni almashtirish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 434-modda, FPK 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sifatsiz tovarni almashtirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # TOVAR MA'LUMOTLARI
            {"id": "sotib_olingan_sana", "label": "Tovar sotib olingan sana", "type": "date", "required": True},
            {"id": "tovar_rusumi", "label": "Tovar rusumi (modeli)", "type": "text", "required": True},
            {"id": "tovar_turi", "label": "Tovar turi (televizor, telefon va h.k.)", "type": "text", "required": True},
            {"id": "kafolat_muddati", "label": "Kafolat muddati", "type": "text", "required": True},

            # NOSOZLIK
            {"id": "nosozlik_tavsifi", "label": "Nosozlik tavsifi", "type": "textarea", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Sifatsiz tovarni almashtirish to'g'risida)



Men javobgardan {sotib_olingan_sana} kuni {tovar_rusumi} rusumli {tovar_turi} ni sotib oldim. Javobgar {tovar_rusumi} rusumli {tovar_turi} boʻyicha {kafolat_muddati} yillik kafolat bergan va {tovar_turi}ning pasportiga imzo qoʻyib, muhur bosib bergan.

Biroq, men {tovar_turi}ni uyimga olib borib, qoʻyib koʻrsam, {tovar_turi} {nosozlik_tavsifi}. Men {tovar_turi}ning ishlamaganligini javobgarga aytganimda, javobgar sifatsiz {tovar_turi}ni qaytarib olmadi. Men bir necha marta javobgardan {tovar_turi}ni yangisiga almashtirib berishni soʻraganimda, javobgar bundan boʻyin tovladi. Shundan soʻng men bir necha tashkilotlarga murojaat qilishga majbur boʻldim.

Oʻzbekiston Respublikasi Fuqarolik kodeksining 434-moddasi, 1-qismi talabiga koʻra, sotib oluvchiga sifati tegishli darajada boʻlmagan tovar sotilganida, agar uning kamchiliklari shartnoma tuzish paytida maʼlum qilinmagan boʻlsa, sotib oluvchi oʻz xohishiga koʻra xuddi shu markadagi (modeldagi) sifati tegishli darajada boʻlgan tovarga almashtirishni talab qilish huquqiga ega.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik kodeksining 434-moddasi hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189 va 191-moddalariga asosan,



                                                              SOʻRAYMAN:



{tovar_rusumi} rusumli sifatsiz {tovar_turi} ni xuddi shu rusumdagi sifati bilan almashtirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Davlat boji kvitansiyasi
3. Pasport nusxasi
4. Tovar pasporti nusxasi
5. Mutaxassis xulosasi nusxasi
6. Yashash joyidan maʼlumotnoma
7. Daʼvo arizani tasdiqlovchi boshqa hujjatlar



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {sotib_olingan_sana} yil.
***
"""
    }
}
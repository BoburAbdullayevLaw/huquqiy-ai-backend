# 1_7_boshqa_nizolar/oldi_sotdi_shartnomasini_bekor_qilish.py
"""
Oldi-sotdi shartnomasini bekor qilish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-008": {
        "nomi": "Oldi-sotdi shartnomasini bekor qilish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 382-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Oldi-sotdi shartnomasini bekor qilish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # SHARTNOMA MA'LUMOTLARI
            {"id": "shartnoma_sana", "label": "Shartnoma tuzilgan sana", "type": "date", "required": True},
            {"id": "shartnoma_raqami", "label": "Shartnoma raqami", "type": "text", "required": True},
            {"id": "shartnoma_turi", "label": "Shartnoma turi va predmeti", "type": "text", "required": True},
            {"id": "buzilgan_band", "label": "Shartnomaning buzilgan bandi raqami", "type": "text", "required": True},
            {"id": "buzilgan_talablar", "label": "Buzilgan talablar (bajarilmagan shartlar)", "type": "textarea",
             "required": True},

            # RAD ETISH ASOSI
            {"id": "rad_etish_asosi", "label": "Javobgarning rad etish asosi", "type": "textarea", "required": True},

            # BEKOR QILISH SABABI
            {"id": "bekor_qilish_sababi", "label": "Shartnomani bekor qilish sababi", "type": "textarea",
             "required": True},
        ],
        "shablon": """
***
                                                                                Fuqarolik ishlari boʻyicha
                                                                                {sud_nomi} sudiga
                    
                                                                                Daʼvogar: {davogar_fio}
                                                                                Manzil: {davogar_manzil}
                                                                                Telefon: {davogar_telefon}
                                                                                
                                                                                Javobgar: {javobgar_fio}
                                                                                Manzil: {javobgar_manzil}
                                                                                Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Oldi-sotdi shartnomasini bekor qilish to'g'risida)



{shartnoma_sana} kuni men va javobgar {javobgar_fio} oʻrtamizda {shartnoma_turi} {shartnoma_raqami}-sonli shartnomasi tuzilgan.

Tuzilgan shartnomaning {buzilgan_band}-bandiga koʻra javobgar {buzilgan_talablar} talablarini bajarishi kerak edi.

Javobgar shartnomaning ushbu talablarini bajarmasdan shartnoma talablarini buzdi, aynan {buzilgan_band}-bandida koʻrsatilgan talablarni bajarmadi.

Oʻzbekiston Respublikasi Fuqarolik kodeksining 382-moddasida agar boshqa qonunlarda yoki shartnomada boshqacha tartib nazarda tutilgan boʻlmasa, shartnoma taraflarning kelishuviga muvofiq oʻzgartirilishi va bekor qilinishi mumkin.

Taraflardan birining talabi bilan shartnoma sud tomonidan faqat quyidagi hollarda oʻzgartirilishi yoki bekor qilinishi mumkin.

Daʼvogar javobgarga oldi-sotdi shartnomasini bekor qilishni taklif qilgan. Daʼvogar tomonidan oldi-sotdi shartnomasini bekor qilish takliflari javobgar tomonidan {rad_etish_asosi} asoslar bilan rad qilindi.

Oldi-sotdi shartnomasini bekor qilish boʻyicha {bekor_qilish_sababi} sabablarga koʻra bekor qilinishini lozim deb hisoblayman.

Yuqorida bayon etilganlarga koʻra va Oʻzbekiston Respublikasi Fuqarolik kodeksining 382-moddasiga asosan,



                                                              SOʻRAYMAN:



1. {shartnoma_sana} kuni № {shartnoma_raqami}-son bilan qayd etilgan daʼvogar {davogar_fio} va javobgar {javobgar_fio} oʻrtasida tuzilgan oldi-sotdi shartnomasini bekor qilishingizni.

2. Javobgar {javobgar_fio} dan daʼvo taqdim etish vaqtida toʻlangan davlat bojini undirishingizni.



Ilova:
1. Oldi-sotdi shartnomasi nusxasi
2. Hujjatlar nusxasi
3. Shartnomani bekor qilish uchun yetarli boʻlgan dalillar
4. Davlat boji kvitansiyasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shartnoma_sana} yil.
***
"""
    }
}
# 1_7_boshqa_nizolar/kredit_shartnomasi_bekor_qilish.py
"""
Kredit shartnomasini bekor qilish, undiruvni garovga qo`yilgan mol-mulkka qaratish yo`li bilan qarzni muddatidan oldin undirish to`g`risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-004": {
        "nomi": "Kredit shartnomasini bekor qilish, undiruvni garovga qo`yilgan mol-mulkka qaratish yo`li bilan qarzni muddatidan oldin undirish to`g`risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 236, 279, 280, 735, 736, 744-moddalar, Iqtisodiy protsessual kodeksi 148, 149, 151-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Kredit shartnomasini bekor qilish, undiruvni garovga qo`yilgan mol-mulkka qaratish yo`li bilan qarzni muddatidan oldin undirish to`g`risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_nomi", "label": "Daʼvogarning nomi", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yuridik manzili", "type": "text", "required": True},
            {"id": "davogar_stir", "label": "Daʼvogarning STIR raqami", "type": "text", "required": True},
            {"id": "davogar_hisob", "label": "Daʼvogarning bank hisobraqami", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgarning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yuridik manzili", "type": "text", "required": True},
            {"id": "javobgar_hisob", "label": "Javobgarning bank hisobraqami", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # KREDIT SHARTNOMASI
            {"id": "kredit_yil", "label": "Kredit shartnomasi tuzilgan yil", "type": "text", "required": True},
            {"id": "kredit_soni", "label": "Kredit shartnomasi soni", "type": "text", "required": True},
            {"id": "kredit_maqsadi", "label": "Kredit ajratish maqsadi", "type": "text", "required": True},
            {"id": "kredit_summasi", "label": "Ajratilgan kredit shartnomasining summasi", "type": "text",
             "required": True},
            {"id": "kredit_tugash_sana", "label": "Kredit shartnomasi tugaydigan sana", "type": "date", "required": True},
            {"id": "foiz_stavkasi", "label": "Kreditning yillik foiz stavkasi", "type": "text", "required": True},

            # GAROV SHARTNOMASI
            {"id": "garov_sana", "label": "Kredit shartnomasi ta’minoti sifatida belgilangan garov shartnomasi tuzilgan sana",
             "type": "date", "required": True},
            {"id": "garov_soni", "label": "Kredit shartnomasi ta’minoti sifatida belgilangan garov shartnomasi soni",
             "type": "text", "required": True},
            {"id": "garov_narsasi", "label": "Garov narsasi nomi", "type": "text", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_nomi}
                                                            Yuridik manzil: {davogar_manzil}
                                                            STIR: {davogar_stir}
                                                            Hisob raqami: {davogar_hisob}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Yuridik manzil: {javobgar_manzil}
                                                            Hisob raqami: {javobgar_hisob}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZA

         (kredit shartnomasini bekor qilish, undiruvni garovga qo`yilgan mol-mulkka qaratish yo`li bilan 
                                   qarzni muddatidan oldin undirish to`g`risida)



{kredit_yil}-yilda {davogar_nomi} (keyingi o`rinlarda - daʼvogar) va {javobgar_nomi} (keyingi o`rinlarda - javobgar) o`rtasida {kredit_soni}-sonli {kredit_maqsadi} uchun kredit berish shartnomasi imzolangan.

Bundan tashqari, kredit shartnomasining taʼminoti sifatida {garov_sana} kuni, {garov_soni}-sonli garov shartnomasiga asosan {garov_narsasi} garovga qo`yilgan.

Mazkur kredit shartnomasiga ko`ra, kredit summasi {kredit_summasi} soʻm deb belgilangan. Shuningdek, shartnomaga ko`ra, javobgar kredit va undan foydalanganlik uchun foiz toʻlovlarini shartnomaga muvofiq har oyda toʻlab borishi shartligi belgilangan.

Kredit shartnomasi, kredit berilgan kundan boshlab {kredit_tugash_sana} gacha toʻliq qaytarilishi nazarda tutilgan.

Shuningdek, shartnomaga ko`ra, kreditdan foydalanganlik uchun foiz stavkasi – yillik {foiz_stavkasi}% qilib belgilangan.

Mazkur kredit shartnomasi shartlariga asosan daʼvogar javobgar hisob raqamiga shartnomada ko`rsatilgan pul mablag`larini o`tkazib berib, shartnoma bo`yicha o`z majburiyatlarini lozim darajada bajargan.

Kredit shartnomasiga ko`ra, javobgar tomonidan majburiyatlar bajarilmaganlik holatlari aniqlangan taqdirda, daʼvogar javobgarga majburiyat bajarilmaganligi holati kelib chiqqanligini bildirib, uni bartaraf etish muddatlarini ko`rsatgan holda yozma bildirishnoma yuborish yoki mazkur shartnomada belgilangan tartibda kredit shartnomasini bekor qilish, foizlarni hamda kredit bo`yicha asosiy qarzni muddatidan oldin undirish, shuningdek undiruvni kredit taʼminotiga qaratishi va boshqa choralarni ko`rishi mumkinligi belgilangan.

Daʼvogar tomonidan javobgarga kredit va unga hisoblangan foizlarni qaytarishni talab qilib yozma ravishda murojaat qilingan bo`lsa-da, javobgar tomonidan qarzdorlikni so`ndirish choralari ko`rilmagan.

Bugungi kunga qadar javobgar tomonidan kredit shartnomasi shartlari qo`pol tarzda buzilib, shartnomada belgilangan kredit va foiz toʻlovlari oʻz vaqtida amalga oshirilmagan.

Oʻzbekiston Respublikasining Fuqarolik kodeksi 236-moddasiga muvofiq, majburiyatlar majburiyat shartlariga va qonunchilik hujjatlari talablariga muvofiq, bunday shartlar va talablar boʻlmaganida esa - ish muomalasi odatlariga yoki odatda qoʻyiladigan boshqa talablarga muvofiq, lozim darajada bajarilishi kerak.

Shuningdek, Oʻzbekiston Respublikasining Fuqarolik kodeksi 279-moddasiga asosan garovga oluvchining (kreditorning) talablarini qondirish uchun undiruvni qarzdor garov bilan taʼminlangan majburiyatni oʻzi javobgar boʻlgan vaziyatlarda bajarmagan yoki lozim darajada bajarmagan taqdirda, garovga qoʻyilgan mol-mulkka qaratish mumkin.

Oʻzbekiston Respublikasining Fuqarolik kodeksi 280-moddasiga muvofiq, garovga oluvchining (kreditorning) talablari garovga qoʻyilgan koʻchmas mol-mulk qiymatidan sudning qaroriga muvofiq qondiriladi.

Yuqoridagilarni inobatga olib, Oʻzbekiston Respublikasining Fuqarolik kodeksi 236, 279, 280, 735, 736 va 744-moddalari hamda Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 148, 149 va 151-moddalariga asosan:



                                                            SOʻRAYMAN:



1. {kredit_yil}-yilgi {kredit_soni}-sonli kredit shartnomasini bekor qilishingizni.

2. Undiruvni javobgarning garovga qo`yilgan mol-mulkiga qaratishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_nomi}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
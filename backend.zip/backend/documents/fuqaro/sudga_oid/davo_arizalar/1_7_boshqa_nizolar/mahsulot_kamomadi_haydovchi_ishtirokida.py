# 1_7_boshqa_nizolar/mahsulot_kamomadi_haydovchi_ishtirokida.py
"""
Mahsulot kamomadi qiymatini undirish haqida da'vo arizasi (qabul qilish dalolatnomasi yuk tashuvchining vakili (haydovchi) ishtirokida tuzilgan hollarda)
"""

HUJJATLAR = {
    "FQ-BN-002": {
        "nomi": "Mahsulot kamomadi qiymatini undirish haqida da'vo arizasi (qabul qilish dalolatnomasi yuk tashuvchining vakili (haydovchi) ishtirokida tuzilgan hollarda)",
        "jpk": "Avtomobil transporti toʻgʻrisidagi Qonun 18, 21, 22-moddalar, Iqtisodiy protsessual kodeksi 148, 149, 151-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mahsulot kamomadi qiymatini undirish haqida da'vo arizasi (qabul qilish dalolatnomasi yuk tashuvchining vakili (haydovchi) ishtirokida tuzilgan hollarda)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yuridik manzili", "type": "text", "required": True},
            {"id": "davogar_stir", "label": "Daʼvogarning STIR raqami", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yuridik manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # YUK MA'LUMOTLARI
            {"id": "tovar_yuk_varakasi", "label": "Tovar-yuk varaqasi soni", "type": "text", "required": True},
            {"id": "avtomashina_raqami", "label": "Tovarni yetkazib bergan avtomashina raqami", "type": "text",
             "required": True},
            {"id": "kamomad_miqdori", "label": "Aniqlangan kamomad miqdori (soʻmda)", "type": "text", "required": True},

            # TO'LOV
            {"id": "tolov_topshiriq_raqami", "label": "Tovar uchun toʻlangan pulning toʻlov topshirigʻi raqami",
             "type": "text", "required": True},
            {"id": "tolangan_summa", "label": "Tovar uchun toʻlangan summa miqdori", "type": "text", "required": True},

            # DALOLATNOMA
            {"id": "dalolatnoma_sana", "label": "Qabul qilish topshirish dalolatnomasi tuzilgan sana", "type": "date",
             "required": True},
            {"id": "dalolatnoma_soni", "label": "Qabul qilish topshirish dalolatnomasi soni", "type": "text",
             "required": True},

            # TALABNOMA
            {"id": "talabnoma_sanasi", "label": "Daʼvogar tomonidan talabnoma yuborilgan sana", "type": "date",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Yuridik manzil: {davogar_manzil}
                                                            STIR: {davogar_stir}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Yuridik manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}



                                                            DAʼVO ARIZA

              (Mahsulot kamomadi qiymatini undirish haqida - qabul qilish dalolatnomasi yuk tashuvchining 
                         vakili (haydovchi) ishtirokida tuzilgan hollarda)



Bizning manzilimizga {tovar_yuk_varakasi}-sonli tovar-yuk varaqasi boʻyicha {avtomashina_raqami} raqamli avtomashinada javobgar yukning saqlanishini taʼminlamaganligini ifodalovchi holatda, yaʼni konteynerdagi mahsulot yuboruvchining tamgʻalari buzilgan holda yukni keltirganligi va buning oqibatida {kamomad_miqdori} soʻm kamomad bilan keltirilganligi aniqlandi.

Mahsulot qiymati yuk yuboruvchiga biz tomonimizdan {tolov_topshiriq_raqami} raqamli toʻlov topshirigʻi bilan toʻla miqdorda {tolangan_summa} soʻm toʻlangan. Kamomad yuk qabul qiluvchi va haydovchining tovar-yuk varakasidagi imzolari va ular ishtirokida {dalolatnoma_sana} kuni tuzilgan {dalolatnoma_soni}-sonli qabul qilish topshirish dalolatnomasi bilan tasdiqlangan.

Oʻzbekiston Respublikasining "Avtomobil transporti toʻgʻrisida"gi Qonuni 18-moddasiga muvofiq, mijozga xizmat koʻrsatish chogʻida tashuvchi bagaj va yuklarning tashishga qabul qilib olingan paytdan boshlab oluvchiga berilgunga qadar saqlanishini taʼminlashi lozim.

Bizning {talabnoma_sanasi} kuni yuborgan talabnomamizni javobgar javobsiz qoldirdi, asossiz qanoatlantirmadi.

Yuqoridagilarga hamda Oʻzbekiston Respublikasining "Avtomobil transporti toʻgʻrisida"gi Qonuni 18, 21, 22-moddalari, Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 148, 149 va 151-moddalariga asosan:



                                                            SOʻRAYMAN:



Javobgardan bizning foydamizga {kamomad_miqdori} soʻm kamomad tufayli keltirilgan zararni undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
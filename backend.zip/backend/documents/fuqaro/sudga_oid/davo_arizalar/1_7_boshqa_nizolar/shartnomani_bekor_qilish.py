# 1_7_boshqa_nizolar/shartnomani_bekor_qilish.py
"""
Shartnomani bekor qilish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-010": {
        "nomi": "Shartnomani bekor qilish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 382-modda, FPK 188-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Shartnomani bekor qilish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # SHARTNOMA MA'LUMOTLARI
            {"id": "shartnoma_sana", "label": "Shartnoma tuzilgan sana", "type": "date", "required": True},
            {"id": "shartnoma_raqami", "label": "Shartnoma raqami", "type": "text", "required": True},
            {"id": "shartnoma_mazmuni", "label": "Shartnoma mazmuni", "type": "textarea", "required": True},

            # MAJBURIYATLAR
            {"id": "javobgar_majburiyatlari", "label": "Javobgarning shartnoma bo'yicha majburiyatlari", "type": "textarea",
             "required": True},
            {"id": "bajarilmagan_bandlar", "label": "Bajarilmagan shartnoma bandlari", "type": "textarea",
             "required": True},

            # BEKOR QILISH TAKLIFI
            {"id": "bekor_qilish_taklifi", "label": "Shartnomani bekor qilish taklifi", "type": "textarea",
             "required": True},
            {"id": "rad_javobi", "label": "Javobgarning rad javobi asoslari", "type": "textarea", "required": True},
            {"id": "rad_javobiga_etiroz", "label": "Rad javobini asossiz deb hisoblash asoslari", "type": "textarea",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Shartnomani bekor qilish to'g'risida)



{shartnoma_sana} kuni taraflar oʻrtasida {shartnoma_raqami}-sonli {shartnoma_mazmuni} shartnomasi tuzilgan.

Mazkur shartnoma boʻyicha javobgar quyidagi majburiyatlarni bajarishi lozim boʻlgan: {javobgar_majburiyatlari}.

Shartnomada koʻrsatilgan quyidagi majburiyatlar, javobgar tomonidan bajarilmagan: {bajarilmagan_bandlar}. Shu sababli daʼvogar javobgarga {bekor_qilish_taklifi} shartnomani bekor qilishni taklif qilgan.

Uning shartnomani bekor qilish taklifi javobgar tomonidan rad qilindi (javobsiz qoldirildi) quyidagi asoslar boʻyicha: {rad_javobi}.

Quyidagi asoslar boʻyicha javobgarning rad javobini asossiz deb hisoblayman: {rad_javobiga_etiroz}.

Yuqoridagilarni inobatga olib, Oʻzbekiston Respublikasi Fuqarolik kodeksining 382-moddasiga asosan,



                                                              SOʻRAYMAN:



1. {shartnoma_sana} kuni № {shartnoma_raqami}-son bilan taraflar oʻrtasida tuzilgan shartnomani bekor qilishingizni.

2. Javobgardan daʼvo qoʻzgʻatish vaqtida toʻlangan davlat bojini undirishingizni.



Ilova:
1. Shartnoma nusxasi
2. Shartnomani bekor qilishga asos boʻlgan hujjatlardan nusxa
3. Davlat boji toʻlanganligi toʻgʻrisida kvitansiya
4. Daʼvo arizani javobgarga yuborilganligini tasdiqlovchi hujjat
5. Ishonchnoma (agar vakil orqali berilgan boʻlsa)



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shartnoma_sana} yil.
***
"""
    }
}
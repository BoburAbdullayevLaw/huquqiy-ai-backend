# 1_7_boshqa_nizolar/regress_tartibida_undirish.py
"""
Regress tartibida undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-009": {
        "nomi": "Regress tartibida undirish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1001-modda, FPK 188-191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Regress tartibida undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # MAJBURIYAT ASOSI
            {"id": "majburiyat_asosi", "label": "Majburiyat vujudga kelish asosi (shartnoma, zarar yetkazish va boshqa)",
             "type": "textarea", "required": True},
            {"id": "majburiyat_summa", "label": "Majburiyat summasi", "type": "text", "required": True},
            {"id": "qarzdorlik_summa", "label": "Qarzdorlik summasi", "type": "text", "required": True},

            # BAJARILGAN MAJBURIYAT
            {"id": "bajarilgan_hujjat", "label": "Majburiyatni bajarilganligini tasdiqlovchi hujjat", "type": "text",
             "required": True},

            # ZARAR
            {"id": "zarar_summa", "label": "Yetkazilgan zarar summasi", "type": "text", "required": True},
            {"id": "qoshimcha_xarajat", "label": "Qo'shimcha qilingan xarajatlar summasi", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Regress tartibida undirish to'g'risida)



{majburiyat_asosi} asosan javobgarda {majburiyat_summa} soʻm miqdorida pul toʻlash majburiyati paydo boʻlgan.

Javobgar oʻz majburiyatlarini bajarmaganligi sababli shu {qarzdorlik_summa} soʻm miqdorida qarzdorlik mavjud boʻlgan.

Javobgarning majburiyati men tomonidan bajarildi, bu esa {bajarilgan_hujjat} hujjatda oʻz tasdigʻini topdi.

Javobgarni bir necha marta ogohlantirilishiga qaramay, javobgar tomonidan hech qanday harakat oshirilmagan, bundan tashqari men {zarar_summa} soʻm miqdorida zarar koʻrdim.

Yuqoridagilarga asosan va Oʻzbekiston Respublikasi Fuqarolik kodeksining 1001-moddasini qoʻllab,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} dan mening foydamga regress tartibida {qarzdorlik_summa} soʻm, hamda qoʻshimcha qilingan xarajatlar uchun {qoshimcha_xarajat} soʻm undirishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Davlat boji toʻlanganligi haqida kvitansiya
3. Majburiyatni tasdiqlovchi hujjatlar
4. Majburiyatni bajarilganligini tasdiqlovchi hujjatlar



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              ______________ yil.
***
"""
    }
}
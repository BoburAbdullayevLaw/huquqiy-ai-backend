# 1_7_boshqa_nizolar/manaviy_zarar_undirish.py
"""
Ma'naviy zararni undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-007": {
        "nomi": "Ma'naviy zararni undirish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 1021-modda, MJtK 41-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ma'naviy zararni undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # HUQUQBUZARLIK MA'LUMOTLARI
            {"id": "huquqbuzarlik_sana", "label": "Huquqbuzarlik sodir bo'lgan sana", "type": "date", "required": True},
            {"id": "huquqbuzarlik_soat", "label": "Huquqbuzarlik sodir bo'lgan soat", "type": "text", "required": True},

            # SUD QARORI
            {"id": "sud_qaror_sud_nomi", "label": "Ma'muriy sud nomi", "type": "text", "required": True},
            {"id": "sud_qaror_sana", "label": "Sud qarori sanasi", "type": "date", "required": True},
            {"id": "mjtk_modda", "label": "MJtK moddasi", "type": "text", "required": True},

            # MA'NAVIY ZARAR
            {"id": "manaviy_zarar_summa", "label": "Talab qilinayotgan ma'naviy zarar summasi", "type": "text",
             "required": True},
            {"id": "sogliq_holati", "label": "Sog'liq holati va davolanish haqida ma'lumot", "type": "textarea",
             "required": True},
        ],
        "shablon": """
***
                                                                                Fuqarolik ishlari boʻyicha
                                                                                {sud_nomi} sudiga
                    
                                                                                Daʼvogar: {davogar_fio}
                                                                                Manzil: {davogar_manzil}
                                                                                Telefon: {davogar_telefon}
                                                                                
                                                                                Javobgar: {javobgar_fio}
                                                                                Manzil: {javobgar_manzil}
                                                                                Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Ma'naviy zararni undirish to'g'risida)



Meni {huquqbuzarlik_sana} kuni soat {huquqbuzarlik_soat} larda javobgar {javobgar_fio} haqorat qildi. {sud_qaror_sud_nomi} sudining {sud_qaror_sana} yildagi qaroriga koʻra, Oʻzbekiston Respublikasi MJtKning {mjtk_modda}-moddasida koʻrsatilgan huquqbuzarlikni sodir qilganlikda aybli deb topilib, u maʼmuriy javobgarlikka tortildi.

Men javobgar {javobgar_fio}ning bu maʼmuriy huquqbuzarligi oqibatida katta maʼnaviy zarar koʻrdim. {sogliq_holati}. Natijada javobgar {javobgar_fio}ning aybi bilan sodir boʻlgan bu hodisadan soʻng men juda katta ruhiy, maʼnaviy qiyinchiliklarni boshdan kechirdim.

Shu sababli yuqorida bayon etilganlarga hamda Oʻzbekiston Respublikasining Fuqarolik Kodeksining 1021-moddasiga asosan,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} dan mening foydamga {manaviy_zarar_summa} soʻm maʼnaviy zararni undirib berishingizni.



Ilova:
- Pasport nusxasi
- Sud qarori nusxasi
- Turar joydan maʼlumotnoma
- Davlat boji kvitansiyasi
- Daʼvo ariza nusxasi



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {huquqbuzarlik_sana} yil.
***
"""
    }
}
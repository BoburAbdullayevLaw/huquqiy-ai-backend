# 1_7_boshqa_nizolar/meva_sabzavot_kamomadi.py
"""
Da'vo ariza (meva-sabzavot mahsuloti kamomadi qiymatini, jarima va zararni undirish haqida)
"""

HUJJATLAR = {
    "FQ-BN-001": {
        "nomi": "Da'vo ariza (meva-sabzavot mahsuloti kamomadi qiymatini, jarima va zararni undirish haqida)",
        "jpk": "Fuqarolik Kodeksi 437-456-moddalar, Iqtisodiy protsessual kodeksi 148, 149, 151-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Da'vo ariza (meva-sabzavot mahsuloti kamomadi qiymatini, jarima va zararni undirish haqida)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yuridik manzili", "type": "text", "required": True},
            {"id": "davogar_stir", "label": "Daʼvogarning STIR raqami", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yuridik manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # SHARTNOMA MA'LUMOTLARI
            {"id": "shartnoma_raqami", "label": "Taraflar tomonidan tuzilgan shartnoma raqami", "type": "text",
             "required": True},
            {"id": "yetkazib_berish_usuli", "label": "Mahsulotni yetkazib berish usuli (temiryoʻl, yuk mashinasi, havo transporti)",
             "type": "text", "required": True},

            # EKSPERTIZA
            {"id": "ekspertiza_raqami", "label": "Qabul qilish topshirish davomida tuzilgan ekspertiza xulosasining raqami",
             "type": "text", "required": True},

            # TO'LOV
            {"id": "tolov_sanasi", "label": "Mahsulotning qiymati toʻlangan sana", "type": "date", "required": True},
            {"id": "tolov_raqami", "label": "Toʻlov topshirigʻi raqami", "type": "text", "required": True},

            # ZARAR
            {"id": "zarar_miqdori", "label": "Daʼvogarga yetkazilgan zararning umumiy miqdori", "type": "text",
             "required": True},

            # PENYA
            {"id": "penya_miqdori", "label": "Shartnomaga muvofiq penya miqdori (foizda)", "type": "text",
             "required": True},

            # TALABNOMA
            {"id": "talabnoma_sanasi", "label": "Daʼvogar tomonidan talabnoma yuborilgan sana", "type": "date",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Yuridik manzil: {davogar_manzil}
                                                            STIR: {davogar_stir}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_fio}
                                                            Yuridik manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}



                                                            DAʼVO ARIZA

                                (meva-sabzavot mahsuloti kamomadi qiymatini, jarima va zararni undirish haqida)



Bizning manzilga {shartnoma_raqami}-raqamli shartnomaga binoan javobgar tomonidan mahsulot {yetkazib_berish_usuli} orqali yetkazib berildi.

Meva-sabzavot mahsuloti texnik jihatdan soz transportda, buzilmagan tamgʻalar bilan yetib kelgan.

Mahsulotni miqdori va sifati boʻyicha qabul qilib olish mobaynida quyidagilar aniqlandi: mahsulot yuk varaqalarida koʻrsatilganga qaraganda kamomad bilan hamda sifatsiz yuborilgan. Bu {ekspertiza_raqami} raqamli ekspertiza dalolatnomasi, qayta oʻlchash; tijorat dalolatnomalari va sanitariya-epidemiologiya markazi xulosasi bilan tasdiqlangan.

Mahsulotning qiymati biz tomonimizdan {tolov_sanasi} kuni {tolov_raqami} raqamli toʻlov topshirigʻi (toʻlov talabnomasi, akkreditiv) orqali toʻlangan.

Mahsulot kamomadi bilan keltirilgan zarar, meva-sabzavot mahsuloti sifatsiz yuborilganligidan keltirilgan zarar, chirik, chiqindi va yoʻqotish xarajatlari jami {zarar_miqdori} soʻmni tashkil etdi.

Qayd etib oʻtilgan shartnomada sifatsiz mahsulot yetkazib berilganligi uchun uning qiymatining {penya_miqdori} foizi miqdorida jarima toʻlash koʻzda tutilgan.

Bizning {talabnoma_sanasi} kuni yuborgan talabnomamizni javobgar javobsiz qoldirdi, sababsiz qanoatlantirmadi.

Yuqoridagilarga hamda Oʻzbekiston Respublikasi Fuqarolik kodeksining 437-456-moddalari, Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 148, 149 va 151-moddalariga asosan



                                                            SOʻRAYMAN:



Javobgardan bizning foydamizga meva-sabzavot mahsuloti kamomadi, sifatsiz yuborilganligidan kelib chiqqan jarima va zarar {zarar_miqdori} soʻm undirib berishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
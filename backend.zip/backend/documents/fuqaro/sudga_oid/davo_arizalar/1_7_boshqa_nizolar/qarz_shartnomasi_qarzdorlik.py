# 1_7_boshqa_nizolar/qarz_shartnomasi_qarzdorlik.py
"""
Qarz shartnomasi bo'yicha qarzdorlikni undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-006": {
        "nomi": "Qarz shartnomasi bo'yicha qarzdorlikni undirish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 734-735-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Qarz shartnomasi bo'yicha qarzdorlikni undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning yashash manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # QARZ MA'LUMOTLARI
            {"id": "qarz_berilgan_sana", "label": "Qarz berilgan sana (kun, oy, yil)", "type": "date", "required": True},
            {"id": "qarz_summa", "label": "Qarz summasi (raqam bilan)", "type": "text", "required": True},
            {"id": "qarz_summa_soz", "label": "Qarz summasi (so'z bilan)", "type": "text", "required": True},
            {"id": "qaytarish_muddati", "label": "Qarzni qaytarish muddati (kun, oy, yil)", "type": "date",
             "required": True},
            {"id": "qaytarilmagan_summa", "label": "Qaytarilmagan qarz summasi", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                                                    Fuqarolik ishlari boʻyicha
                                                                                    {sud_nomi} sudiga
                        
                                                                                    Daʼvogar: {davogar_fio}
                                                                                    Manzil: {davogar_manzil}
                                                                                    Telefon: {davogar_telefon}
                                                                                    
                                                                                    Javobgar: {javobgar_fio}
                                                                                    Manzil: {javobgar_manzil}
                                                                                    Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Qarz shartnomasi boʻyicha qarzdorlikni undirish toʻgʻrisida)



Men yuqorida koʻrsatilgan manzilda yashayman. {qarz_berilgan_sana} kuni {javobgar_fio} meni oldimga kelib qarz soʻradi. Shundan soʻng men javobgarga oʻzaro tilxat asosida {qarz_summa} soʻm qarz berdim.

Javobgar {qarz_summa} soʻmni {qaytarish_muddati} kuniga qadar qaytarishi lozim edi, shunday boʻlsada javobgar {qaytarilmagan_summa} soʻm qarzni qaytarmasdan kelayapti, shu kunga qadar javobgarga bir necha bor qarzni qaytarishni soʻrab murojaat qildim, lekin u ertaga, indinga beraman deb meni aldab kelmoqda.

Yuqoridagilardan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik kodeksining 734-735 moddalariga asosan,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} dan meni foydamga {qaytarilmagan_summa} soʻm asosiy qarzni undirib berishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Tilxat asli
3. Pasport nusxasi
4. Yashash joyidan maʼlumotnoma
5. Davlat boji toʻlanganligi toʻgʻrisida kvitansiya



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {qarz_berilgan_sana} yil.
***
"""
    }
}
# 1_6_avtotransport/avtotransport_garaji_huquqi.py
"""
Avtotransport garaji uchun mulk huquqini belgilash toʻgʻrisida daʼvo arizasi
"""

HUJJATLAR = {
    "FQ-AT-001": {
        "nomi": "Avtotransport garaji uchun mulk huquqini belgilash toʻgʻrisida daʼvo arizasi",
        "jpk": "Fuqarolik Kodeksi 210-modda, Mulkchilik toʻgʻrisidagi Qonun 7-modda 5-band, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Avtotransport garaji uchun mulk huquqini belgilash toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar (hokimlik) ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR (HOKIMLIK)
            {"id": "hokimlik_nomi", "label": "Javobgar (egalik huquqini berish toʻgʻrisida murojaat qilingan hokimlik) nomi",
             "type": "text", "required": True},
            {"id": "hokimlik_manzil", "label": "Javobgar (hokimlik) joylashgan manzil", "type": "text", "required": True},
            {"id": "hokimlik_telefon", "label": "Javobgar (hokimlik)ning telefon raqami", "type": "text",
             "required": False},
            {"id": "hokimlik_email", "label": "Javobgar (hokimlik)ning elektron manzili", "type": "email",
             "required": False},

            # XONADON MA'LUMOTLARI
            {"id": "mulk_vujudga_kelgan_sana",
             "label": "Xonadonga nisbatan mulk huquqi vujudga kelgan sana (oldi-sotdi, hadya shartnomasi tuzilgan, meros qabul qilib olingan sana)",
             "type": "date", "required": True},
            {"id": "shartnoma_turi",
             "label": "Uy-joyga mulk huquqi vujudga kelishi uchun asos boʻlgan shartnoma turi (meros, hadya, oldi-sotdi va boshqalar)",
             "type": "text", "required": True},
            {"id": "xonadon_manzili", "label": "Xonadon manzili (tuman, mahalla, koʻcha va uy raqami)", "type": "text",
             "required": True},

            # MUROJAAT
            {"id": "murojaat_sanasi", "label": "Egalik huquqini berish toʻgʻrisida tegishli hokimlikka murojaat qilingan sana",
             "type": "date", "required": True},
            {"id": "rad_sanasi", "label": "Egalik huquqini berish toʻgʻrisidagi murojaat rad qilingan sana", "type": "date",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova hujjatlarining roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {hokimlik_nomi}
                                                            Manzil: {hokimlik_manzil}
                                                            Telefon: {hokimlik_telefon}
                                                            Elektron manzil: {hokimlik_email}



Daʼvo mazmuni: garaj uchun mulk huquqini belgilash toʻgʻrisida



                                                            DAʼVO ARIZA



Men {mulk_vujudga_kelgan_sana} kuni notarial tasdiqlangan {shartnoma_turi}ga asosan {xonadon_manzili} xonadonining mulkdori boʻlganman. Men uyni garaji bilan birga qabul qilib olganman. Garaj ham uyning yonida joylashgan. Biroq, garajga nisbatan mulk huquqimni tasdiqlovchi hujjatim yoʻq. Men shu garajdan 18 yildan buyon foydalanishimni mahalla ahli va qoʻshnilar ham tasdiqlaydi. Mazkur bino boʻyicha qoʻshnilarim bilan mulkiy yoki boshqa tusdagi nizo mavjud emas.

Men garajga nisbatan oʻzimning mulk huquqimni tasdiqlash toʻgʻrisida {murojaat_sanasi} kuni {hokimlik_nomi} hokimiyatiga murojaat qildim. Biroq {hokimlik_nomi} hokimiyatining {rad_sanasi} yildagi javob xatiga asosan mening murojaatim rad qilingan.

Oʻzbekiston Respublikasi Fuqarolik kodeksining 210-moddasining uchinchi xatboshisi talabiga koʻra, kooperativ uy-joyga, kvartiraga, garajga, chorboqqa va boshqa binolarga mulk huquqi kooperativ aʼzosi pay badallarini batamom toʻlab boʻlganidan keyin vujudga keladi.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik kodeksining 210-moddasi, "Oʻzbekiston Respublikasida mulkchilik toʻgʻrisida"gi Qonunning 7-moddasi 5-bandi hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan,



                                                            SOʻRAYMAN:



{davogar_manzil} manzilidagi xonadonning yonida joylashgan, men foydalanib kelayotgan garajga nisbatan mening mulk huquqimni belgilashingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    }
}
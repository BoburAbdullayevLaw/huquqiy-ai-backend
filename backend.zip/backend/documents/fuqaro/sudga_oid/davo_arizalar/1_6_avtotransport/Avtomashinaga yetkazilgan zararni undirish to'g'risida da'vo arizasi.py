# 1_7_boshqa_nizolar/avtomashinaga_yetkazilgan_zarar.py
"""
Avtomashinaga yetkazilgan zararni undirish to'g'risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-BN-012": {
        "nomi": "Avtomashinaga yetkazilgan zararni undirish to'g'risida da'vo arizasi",
        "jpk": "Fuqarolik Kodeksi 985-modda, FPK 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Avtomashinaga yetkazilgan zararni undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo'yicha sud nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Da'vogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Da'vogarning manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Da'vogarning telefon raqami", "type": "text", "required": True},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_fio", "label": "Javobgarning F.I.O.", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},

            # AVTOMOBIL MA'LUMOTLARI
            {"id": "davogar_avto_rusumi", "label": "Da'vogarning avtomobil rusumi", "type": "text", "required": True},
            {"id": "javobgar_avto_rusumi", "label": "Javobgarning avtomobil rusumi", "type": "text", "required": True},
            {"id": "yth_sana", "label": "YTH sodir bo'lgan sana (kun)", "type": "text", "required": True},
            {"id": "yth_oy", "label": "YTH sodir bo'lgan oy", "type": "text", "required": True},
            {"id": "yth_yil", "label": "YTH sodir bo'lgan yil", "type": "text", "required": True},
            {"id": "yth_soat", "label": "YTH sodir bo'lgan soat", "type": "text", "required": True},

            # ZARAR
            {"id": "zarar_summa", "label": "Yetkazilgan zarar summasi", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} sudiga

Daʼvogar: {davogar_fio}
Manzil: {davogar_manzil}
Telefon: {davogar_telefon}

Javobgar: {javobgar_fio}
Manzil: {javobgar_manzil}
Telefon: {javobgar_telefon}



                                                              DA'VO ARIZASI

                                    (Avtomashinaga yetkazilgan zararni undirish to'g'risida)



{yth_yil} yil {yth_sana} {yth_oy} dan {yth_sana+1} {yth_oy} ga oʻtar kechasi soat {yth_soat} larda javobgar boshqaruvidagi {javobgar_avto_rusumi} rusumli avtomashina bilan meni boshqaruvimdagi {davogar_avto_rusumi} rusumli avtomashinamni urib yuborib, yoʻl transport hodisasini sodir qildi.

Javobgar esa mening avtomashinamni urib yuborib, yoʻl transport hodisasini sodir etganligi sababli Oʻzbekiston Respublikasi MJtKning tegishli moddalariga asosan javobgarlikka tortildi.

Javobgar mening avtomashinamga yetkazilgan zararni qoplab berishni istamasdan kelmoqda.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 985-moddasi 1-qismida "Gʻayriqonuniy harakat (harakatsizlik) tufayli fuqaroning shaxsiga yoki mol-mulkiga yetkazilgan zarar, shuningdek yuridik shaxsga yetkazilgan zarar, shu jumladan boy berilgan foyda zararni yetkazgan shaxs tomonidan toʻliq hajmda qoplanishi lozim"ligi nazarda tutilgan.

Yuqoridagilarga koʻra, Oʻzbekiston Respublikasi Fuqarolik kodeksining 985-moddasi hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 189 va 191-moddalariga asosan,



                                                              SOʻRAYMAN:



Javobgar {javobgar_fio} dan mening foydamga avtomashinamga yetkazilgan {zarar_summa} soʻm moddiy zararni undirib berishingizni.



Ilova:
1. Daʼvo ariza nusxasi
2. Davlat boji kvitansiyasi
3. Pasport nusxasi
4. Avtomobil hujjatlari
5. Mutaxassis xulosasi nusxasi
6. Yashash joyidan maʼlumotnoma va dalolatnoma
7. Daʼvo arizani tasdiqlovchi boshqa hujjatlar



                                                              Daʼvogar: {davogar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {yth_yil} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/kassatsiya_shikoyatlari/iqtisodiy_sudda_qarshi_davo.py
"""
Iqtisodiy ishlarda qarshi da’voni taqdim etish to‘g‘risida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-KS-004": {
        "nomi": "Iqtisodiy ishlarda qarshi da’voni taqdim etish to‘g‘risida da'vo arizasi",
        "jpk": "Iqtisodiy protsessual kodeksi 131, 132, 133-moddalar, Fuqarolik Kodeksi 234, 235-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Iqtisodiy ishlarda qarshi da’voni taqdim etish to‘g‘risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, qarshi da'vogar ma'lumotlari bo'lsin.
4. "QARSHI DA'VO ARIZASI" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Iqtisodiy sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # QARSHI DA'VOGAR (JAVOBGAR)
            {"id": "qarshi_davogar_nomi", "label": "Qarshi da'vogar yuridik shaxs nomi va tashkiliy huquqiy shakli",
             "type": "text", "required": True},
            {"id": "qarshi_davogar_manzil", "label": "Qarshi da'vogarning yuridik manzili", "type": "text",
             "required": True},
            {"id": "qarshi_davogar_stir", "label": "Qarshi da'vogarning STIR raqami", "type": "text", "required": True},
            {"id": "qarshi_davogar_rahbar_fio", "label": "Qarshi da'vogar yuridik shaxs rahbarining F.I.O.",
             "type": "text", "required": True},
            {"id": "qarshi_davogar_telefon", "label": "Qarshi da'vogarning telefon raqami", "type": "text",
             "required": False},
            {"id": "qarshi_davogar_email", "label": "Qarshi da'vogarning elektron manzili", "type": "email",
             "required": False},

            # ASOSIY DA'VOGAR
            {"id": "asosiy_davogar_nomi", "label": "Asosiy da'vogar yuridik shaxs nomi va tashkiliy huquqiy shakli",
             "type": "text", "required": True},
            {"id": "asosiy_davogar_manzil", "label": "Asosiy da'vogarning yuridik manzili", "type": "text",
             "required": True},
            {"id": "asosiy_davogar_stir", "label": "Asosiy da'vogarning STIR raqami", "type": "text", "required": True},

            # ASOSIY ISH MA'LUMOTLARI
            {"id": "asosiy_ish_raqami", "label": "Asosiy ish raqami", "type": "text", "required": True},
            {"id": "asosiy_davo_mazmuni", "label": "Asosiy da'vo arizasining mazmuni", "type": "textarea",
             "required": True},

            # QARSHI DAVO MA'LUMOTLARI
            {"id": "qarshi_davo_talabi", "label": "Qarshi da'vo talabi mazmuni", "type": "textarea", "required": True},
            {"id": "qarshi_davo_asoslari", "label": "Qarshi da'vo talablarining asoslari", "type": "textarea",
             "required": True},
            {"id": "qarshi_davo_summa", "label": "Qarshi da'vo summasi", "type": "text", "required": True},

            # BOG'LIQLIK
            {"id": "bogliqlik_asoslari",
             "label": "Qarshi da'voning asosiy da'vo bilan bog'liqligi (o'zaro bog'liqlik asoslari)",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Arizaga ilova qilinayotgan hujjatlar ro'yxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Iqtisodiy ishlar bo‘yicha
                                                            {sud_nomi} sudiga

Qarshi da'vogar: {qarshi_davogar_nomi}
Yuridik manzil: {qarshi_davogar_manzil}
STIR: {qarshi_davogar_stir}
{asosiy_davogar_nomi}ga nisbatan

Asosiy da'vogar: {asosiy_davogar_nomi}
Yuridik manzil: {asosiy_davogar_manzil}
STIR: {asosiy_davogar_stir}



                                                              QARSHI DA'VO ARIZASI

                                    ({asosiy_ish_raqami}-sonli ish yuzasidan)



Iqtisodiy ishlar bo‘yicha {sud_nomi} sudining ish yurituvida {asosiy_ish_raqami}-sonli ish ko'rilmoqda. Mazkur ish bo‘yicha {asosiy_davogar_nomi} tomonidan {qarshi_davogar_nomi}ga nisbatan {asosiy_davo_mazmuni} to'g'risida da'vo arizasi berilgan.

Ushbu da'vo bilan bog'liq holda, {qarshi_davogar_nomi} tomonidan {asosiy_davogar_nomi}ga nisbatan quyidagi asoslarda qarshi da'vo taqdim etiladi:

{qarshi_davo_asoslari}

Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 131-moddasiga koʻra, javobgar ish boʻyicha sud hujjati qabul qilinishidan oldin dastlabki daʼvoni birgalikda koʻrish uchun qarshi daʼvo taqdim etishga haqli.

Qarshi daʼvoni taqdim etish quyidagi hollarda amalga oshiriladi:
1) qarshi talab dastlabki talabni qoplash uchun yoʻnaltirilgan boʻlsa;
2) qarshi talabning qanoatlantirilishi dastlabki talabni toʻliq yoki qisman rad etishni istisno etsa;
3) qarshi va dastlabki talablar oʻrtasida oʻzaro bogʻliqlik mavjud boʻlib, ularni birgalikda koʻrish ishga tez va toʻgʻri hal etilishiga olib kelsa.

Mazkur holatda, qarshi da'vo bilan asosiy da'vo o'rtasida quyidagi bog'liqlik mavjud:

{bogliqlik_asoslari}

Iqtisodiy protsessual kodeksining 132-moddasiga koʻra, qarshi daʼvo umumiy qoidalarga muvofiq taqdim etiladi.

Qarshi da'vo talabi: {qarshi_davo_talabi}

Qarshi da'vo summasi: {qarshi_davo_summa} so'mni tashkil etadi.

Oʻzbekiston Respublikasi Fuqarolik Kodeksining 234, 235-moddalariga asosan, majburiyatlar shartnomadan, ziyon yetkazish natijasida hamda qonunchilikda koʻrsatilgan boshqa asoslardan kelib chiqadi.

Yuqoridagilardan kelib chiqib, Oʻzbekiston Respublikasi Iqtisodiy protsessual kodeksining 131, 132, 133-moddalariga asosan,



                                                              SOʻRAYMAN:



1. Ushbu qarshi da'vo arizasini {asosiy_ish_raqami}-sonli ishga qabul qilib, dastlabki da'vo bilan birgalikda koʻrishni;

2. {asosiy_davogar_nomi} dan {qarshi_davogar_nomi} foydasiga {qarshi_davo_summa} so'm undirish to'g'risida hal qiluv qarori qabul qilishingizni.



Ilova:
1. Qarshi da'vo arizasi nusxalari;
2. Qarshi da'vo talablarini asoslovchi hujjatlar;
3. Davlat boji to'langanligini tasdiqlovchi hujjat;
4. {ilova}



                                                              Qarshi da'vogar: {qarshi_davogar_nomi}
                                                              {qarshi_davogar_rahbar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/kassatsiya_shikoyatlari/kassatsiya_muddatini_tiklash.py
"""
Kassatsiya shikoyati berish muddatini tiklash to‘g‘risida ariza
"""

HUJJATLAR = {
    "FQ-KS-003": {
        "nomi": "Kassatsiya shikoyati berish muddatini tiklash to‘g‘risida ariza",
        "jpk": "Fuqarolik protsessual kodeksi 403-406-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Kassatsiya shikoyati berish muddatini tiklash to‘g‘risida ariza" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, ariza beruvchi ma'lumotlari bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Ariza berilgan fuqarolik sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # ARIZA BERUVCHI
            {"id": "arizachi_manzil", "label": "Ariza beruvchining manzili", "type": "text", "required": True},
            {"id": "arizachi_fio", "label": "Ariza beruvchining F.I.O.", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar", "label": "Ish bo‘yicha da’vogar", "type": "text", "required": True},
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Da’vo ariza mazmuni", "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ish bo‘yicha hal qiluv qarori qabul qilingan sana", "type": "date",
             "required": True},

            # MUDDAT O'TKAZIB YUBORILISH SABABI
            {"id": "uzrli_sabablar",
             "label": "Hal qiluv qarori ustidan shikoyat keltirish uchun belgilangan muddat o‘tkazib yuborilishi uchun sabab bo‘lgan uzrli holatlar (kasallik yoki boshqa holat)",
             "type": "textarea", "required": True},
            {"id": "isbotlovchi_hujjatlar",
             "label": "Shikoyat keltirish muddati uzrli sabab bilan o‘tkazib yuborilganligini isbotlovchi hujjatlar nomi",
             "type": "textarea", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari bo‘yicha
                                                            {sud_nomi} sudiga

{arizachi_manzil}da yashovchi
{arizachi_fio}dan



                                                              A R I Z A

                                    sudning hal qiluv qarori ustidan kassatsiya shikoyati berish muddatini tiklash to‘g‘risida



Fuqarolik ishlari bo‘yicha {sud_nomi} sudining ish yurituvida da’vogar {davogar}ning javobgar {javobgar}ga nisbatan {davo_mazmuni} to‘g‘risidagi da’vo arizasi yuzasidan {qaror_sana} kuni chiqarilgan hal qiluv qarori ustidan {uzrli_sabablar} sababli kassatsiya shikoyati bera olmadim.

Mening ushbu sabablarimning uzrli ekanligini {isbotlovchi_hujjatlar} kabi dalillar tasdiqlaydi.

O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 403-moddasiga ko‘ra, taraflar va ishda ishtirok etuvchi boshqa shaxslar, ishda ishtirok etishga jalb qilinmagan, ammo huquq va majburiyatlari haqidagi masala sud tomonidan hal etilgan shaxslar, shuningdek O‘zbekiston Respublikasi Prezidenti huzuridagi Tadbirkorlik subyektlarining huquqlari va qonuniy manfaatlarini himoya qilish bo‘yicha vakil, bundan tadbirkorlik faoliyati bilan bog‘liq bo‘lmagan nizolar mustasno, sudning qonuniy kuchga kirgan va apellyatsiya tartibida ko‘rilmagan hal qiluv qarori, ajrimi, qarori ustidan kassatsiya shikoyati berishi mumkin.

Mazkur Kodeksning 4051-moddasiga ko‘ra, kassatsiya shikoyati (protesti) birinchi instansiya sudining hal qiluv qarori qonuniy kuchga kirgan kundan e’tiboran olti oy ichida berilishi mumkin.

O‘tkazib yuborilgan kassatsiya shikoyati (protesti) berish muddati shikoyat (protest) berayotgan shaxsning iltimosnomasiga ko‘ra kassatsiya instansiya sudining sudyasi tomonidan, agar iltimosnoma kassatsiya shikoyati (protesti) berish muddati o‘tgan kundan e’tiboran uch oydan kechiktirmay berilgan bo‘lsa va o‘tkazib yuborilgan muddat sud tomonidan uzrli deb topilsa, tiklanishi mumkin.

Yuqoridagilardan kelib chiqib, O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 403-406-moddalariga asoslanib,



                                                              SO‘RAYMAN:



Fuqarolik ishlari bo‘yicha {sud_nomi} sudining {qaror_sana} kunidagi hal qiluv qarori ustidan kassatsiya shikoyati berish muddatini tiklashingizni.



Arizaga ilova qilinayotgan hujjatlar:
1. Ariza nusxasi.
2. {isbotlovchi_hujjatlar}



                                                              {arizachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
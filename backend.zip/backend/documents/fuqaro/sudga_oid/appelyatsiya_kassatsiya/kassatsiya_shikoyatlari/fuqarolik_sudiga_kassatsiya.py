# appelyatsiya_kassatsiya/kassatsiya_shikoyatlari/fuqarolik_sudiga_kassatsiya.py
"""
Kassatsiya shikoyati (Fuqarolik sudiga)
"""

HUJJATLAR = {
    "FQ-KS-001": {
        "nomi": "Kassatsiya shikoyati (Fuqarolik sudiga)",
        "jpk": "Fuqarolik protsessual kodeksi 72, 403, 405, 419-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Kassatsiya shikoyati (Fuqarolik sudiga)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat beruvchi ma'lumotlari bo'lsin.
4. "KASSATSIYA SHIKOYATI" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Shikoyat berilgan fuqarolik sudi nomi", "type": "text", "required": True},
            {"id": "shikoyat_sana", "label": "Shikoyat berilgan sana", "type": "date", "required": True},

            # SHIKOYAT BERUVCHI
            {"id": "shikoyatchi_manzil", "label": "Shikoyat beruvchining manzili", "type": "text", "required": True},
            {"id": "shikoyatchi_fio", "label": "Shikoyat beruvchi shaxsning F.I.O.", "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "quyi_sud_nomi", "label": "Ustidan shikoyat berilayotgan sud qarorini qabul qilgan sud nomi",
             "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ustidan shikoyat berilayotgan sud qarori qabul qilingan sana", "type": "date",
             "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar", "label": "Ish bo‘yicha da’vogar", "type": "text", "required": True},
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},
            {"id": "davo_talabi", "label": "Da’vo talabi mazmuni", "type": "text", "required": True},
            {"id": "qaror_mazmuni", "label": "Sudning hal qiluv qarori mazmuni", "type": "text", "required": True},

            # SHIKOYAT ASOSLARI
            {"id": "shikoyat_asoslari",
             "label": "Shikoyat muallifining fikriga ko‘ra sudning hal qiluv qarori qaysi asoslarga ko‘ra noqonuniy?",
             "type": "textarea", "required": True},

            # YANGI QAROR
            {"id": "yangi_qaror_mazmuni",
             "label": "Hal qiluv qarori bekor qilinib, o‘rniga qabul qilinishi so‘ralayotgan yangi hal qiluv qarorining qisqacha mazmuni",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Shikoyatga ilova qilinayotgan hujjatlar nomi", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari bo‘yicha
                                                            {sud_nomi} sudiga

{shikoyatchi_manzil}da yashovchi
{shikoyatchi_fio}dan



                                                              KASSATSIYA SHIKOYATI

                        {quyi_sud_nomi} sudining {qaror_sana} dagi hal qiluv qarori yuzasidan



Da’vogar {davogar} javobgar {javobgar}ga nisbatan {davo_talabi} to‘g‘risidagi da’vo ariza bilan fuqarolik ishlar bo‘yicha {quyi_sud_nomi} sudiga murojaat qilgan. Sud {qaror_sana} kuni {qaror_mazmuni} to‘g‘risida hal qiluv qarori qabul qilgan.

Men quyidagilarga asosan ushbu qarordan noroziman:

{shikoyat_asoslari}

O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 403-moddasiga ko‘ra, taraflar va ishda ishtirok etuvchi boshqa shaxslar, ishda ishtirok etishga jalb qilinmagan, ammo huquq va majburiyatlari haqidagi masala sud tomonidan hal etilgan shaxslar, shuningdek O‘zbekiston Respublikasi Prezidenti huzuridagi Tadbirkorlik subyektlarining huquqlari va qonuniy manfaatlarini himoya qilish bo‘yicha vakil, bundan tadbirkorlik faoliyati bilan bog‘liq bo‘lmagan nizolar mustasno, sudning qonuniy kuchga kirgan va apellyatsiya tartibida ko‘rilmagan hal qiluv qarori, ajrimi, qarori ustidan kassatsiya shikoyati berishi mumkin.

Mazkur Kodeksning 405-moddasiga ko‘ra, kassatsiya shikoyati (protesti) kassatsiya instansiyasi sudining nomiga yo‘llanadi, lekin hal qiluv qarorini, ajrimni, qarorni qabul qilgan sudga beriladi.

Ushbu Kodeksning 419-moddasiga ko‘ra kassatsiya instansiyasining sudi kassatsiya shikoyatini (protestini) ko‘rish natijalari bo‘yicha hal qiluv qarorini, ajrimni, qarorni to‘liq yoxud qisman bekor qilishga va yangi hal qiluv qarori, ajrim yoki qaror qabul qilishga, hal qiluv qarorini, ajrimni, qarorni to‘liq yoki qisman o‘zgartirishga, hal qiluv qarorini, qarorni to‘liq yoki qisman bekor qilishga va arizani ko‘rmasdan qoldirishga yoxud ish yuritishni to‘liq yoki qisman tugatishga haqli.

Biroq birinchi instansiya sudi yuqoridagi qonun talablariga rioya qilmagan. Chunki sud ish holatlarini o‘rganmadi.

Shuningdek, Fuqarolik protsessual kodeksining 72-moddasida har bir taraf o‘zining talablari va eʼtirozlariga asos qilib ko‘rsatgan holatlarni isbotlashi shart. Biroq sud ushbu qonun talabiga rioya qilmadi.

Ish uchun ahamiyatli holatlarning to‘liq aniqlanmaganligi, sud aniqlangan deb hisoblagan, ish uchun ahamiyatli bo‘lgan holatlarning isbotlanmaganligi, sud hujjatida bayon etilgan sud xulosalarining ish holatlariga muvofiq emasligi, moddiy va protsessual huquq normalarining buzilganligi yoki noto‘g‘ri qoʻllanilganligi sud hujjatini bekor qilish yoki o‘zgartirish uchun asos bo‘ladi.

Yuqoridagilardan hamda Fuqarolik protsessual Kodeksining 72, 372, 403-moddalaridan kelib chiqqan holda



                                                              SO‘RAYMAN:



1. {quyi_sud_nomi} sudining {qaror_sana} kunidagi hal qiluv qarorini bekor qilishingizni.

2. {yangi_qaror_mazmuni} haqida yangi hal qiluv qarori qabul qilishingizni.



Ilova: {ilova}



                                                              {shikoyatchi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
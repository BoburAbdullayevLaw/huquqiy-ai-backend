# appelyatsiya_kassatsiya/kassatsiya_shikoyatlari/iqtisodiy_sudga_kassatsiya.py
"""
Kassatsiya tartibida shikoyat (Iqtisodiy ishlar bo‘yicha sudga)
"""

HUJJATLAR = {
    "FQ-KS-002": {
        "nomi": "Kassatsiya tartibida shikoyat (Iqtisodiy ishlar bo‘yicha sudga)",
        "jpk": "Iqtisodiy protsessual kodeksi 42, 68, 177, 282-303, 301, 302-moddalar, Fuqarolik Kodeksi 234-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Kassatsiya tartibida shikoyat (Iqtisodiy ishlar bo‘yicha sudga)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat beruvchi ma'lumotlari bo'lsin.
4. "KASSATSIYA SHIKOYATI" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Shikoyat berilgan iqtisodiy sud nomi", "type": "text", "required": True},
            {"id": "shikoyat_sana", "label": "Shikoyat berilgan sana", "type": "date", "required": True},

            # SHIKOYAT BERUVCHI
            {"id": "shikoyatchi_nomi", "label": "Shikoyat beruvchi yuridik shaxs nomi va tashkiliy huquqiy shakli",
             "type": "text", "required": True},
            {"id": "shikoyatchi_rahbar_fio", "label": "Shikoyat beruvchi yuridik shaxs rahbarining F.I.O.",
             "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "quyi_sud_nomi", "label": "Ustidan shikoyat berilayotgan sud qarorini qabul qilgan sud nomi",
             "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ustidan shikoyat berilayotgan sud qarori qabul qilingan sana", "type": "date",
             "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar", "label": "Ish bo‘yicha da’vogar", "type": "text", "required": True},
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},
            {"id": "davo_talabi", "label": "Da’vo talabi mazmuni", "type": "text", "required": True},
            {"id": "qaror_mazmuni", "label": "Sudning hal qiluv qarori mazmuni", "type": "text", "required": True},

            # SHIKOYAT ASOSLARI
            {"id": "shikoyat_asoslari",
             "label": "Shikoyat muallifining fikriga ko‘ra sudning hal qiluv qarori qaysi asoslarga ko‘ra noqonuniy?",
             "type": "textarea", "required": True},

            # YANGI QAROR
            {"id": "yangi_qaror_mazmuni",
             "label": "Hal qiluv qarori bekor qilinib, o‘rniga qabul qilinishi so‘ralayotgan yangi hal qiluv qarorining qisqacha mazmuni",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Shikoyatga ilova qilinayotgan hujjatlar nomi", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Iqtisodiy ishlar bo‘yicha
                                                            {sud_nomi} sudiga

{shikoyatchi_nomi}
{shikoyatchi_rahbar_fio}dan



                                                              KASSATSIYA SHIKOYATI

                        {quyi_sud_nomi} sudining {qaror_sana} dagi hal qiluv qarori yuzasidan



Da’vogar {davogar} javobgar {javobgar}ga nisbatan {davo_talabi} to‘g‘risidagi da’vo ariza bilan iqtisodiy ishlar bo‘yicha {quyi_sud_nomi} sudiga murojaat qilgan. Sud {qaror_sana} kuni {qaror_mazmuni} to‘g‘risida hal qiluv qarori qabul qilgan.

Men quyidagilarga asosan ushbu qarordan noroziman:

{shikoyat_asoslari}

O‘zbekiston Respublikasi Fuqarolik Kodeksining 234-moddasiga ko‘ra, majburiyat — fuqarolik huquqiy munosabati bo‘lib, unga asosan bir shaxs (qarzdor) boshqa shaxs (kreditor) foydasiga muayyan harakatni amalga oshirishga, chunonchi: mol-mulkni topshirish, ishni bajarish, xizmatlar ko‘rsatish, pul to‘lash va hokazo yoki muayyan harakatdan o‘zini saqlashga majbur bo‘ladi, kreditor esa — qarzdordan o‘zining majburiyatlarini bajarishni talab qilish huquqiga ega bo‘ladi.

Majburiyatlar shartnomadan, ziyon yetkazish natijasida hamda ushbu Kodeksda ko‘rsatilgan boshqa asoslardan kelib chiqadi.

O‘zbekiston Respublikasi Iqtisodiy protsessual kodeksining 177-moddasiga ko‘ra, sud hal qiluv qarorini qabul qilish chog‘ida ishda ishtirok etuvchi shaxslarning o‘z talablari va e’tirozlarini asoslantirish uchun keltirgan dalillari va vajlariga baho berishi, ish uchun ahamiyatli qaysi holatlar aniqlanganligini va qaysilari aniqlanmaganligini belgilashi, ishda ishtirok etuvchi shaxslarning qanday huquq va majburiyatlari borligini belgilashi lozimligi ko‘rsatilgan.

Biroq birinchi instansiya sudi yuqoridagi qonun talablariga rioya qilmagan. Chunki sud ish holatlarini o‘rganmadi.

Shuningdek, Iqtisodiy protsessual kodeksining 68-moddasida ishda ishtirok etuvchi har bir shaxs o‘z talablari va e’tirozlariga asos qilib keltirayotgan holatlarni isbotlashi kerak. Ishda ishtirok etuvchi shaxslar faqat ishda ishtirok etuvchi boshqa shaxslar oldindan tanishtirilgan dalillarga asoslanishga haqli. Biroq sud ushbu qonun talabiga rioya qilmadi.

Iqtisodiy protsessual Kodeksning 301-moddasiga ko‘ra, kassatsiya instansiyasi sudi hal qiluv qarorini to‘liq yoki qisman bekor qilishga va yangi qaror qabul qilishga, hal qiluv qarorini to‘liq yoki qisman bekor qilishga va ish yuritishni tugatishga yoxud da’voni to‘liq yoki qisman ko‘rmasdan qoldirishga haqli.

Iqtisodiy protsessual Kodeksning 302-moddasiga ko‘ra, ish uchun ahamiyatli holatlarning to‘liq aniqlanmaganligi, sud aniqlangan deb hisoblagan, ish uchun ahamiyatli bo‘lgan holatlarning isbotlanmaganligi, hal qiluv qarorida bayon qilingan xulosalarning ish holatlariga muvofiq emasligi, moddiy va (yoki) protsessual huquq normalarining buzilganligi yoxud noto‘g‘ri qo‘llanilganligi birinchi instansiya sudining hal qiluv qarorini o‘zgartirish yoki bekor qilish uchun asos bo‘ladi.

Yuqoridagilardan hamda Iqtisodiy protsessual Kodeksning 42, 68, 282-303-moddalaridan kelib chiqqan holda



                                                              SO‘RAYMAN:



1. {quyi_sud_nomi} sudining {qaror_sana} kunidagi hal qiluv qarorini bekor qilishingizni.

2. {yangi_qaror_mazmuni} haqida yangi hal qiluv qarori qabul qilishingizni.



Ilova: {ilova}



                                                              {shikoyatchi_rahbar_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
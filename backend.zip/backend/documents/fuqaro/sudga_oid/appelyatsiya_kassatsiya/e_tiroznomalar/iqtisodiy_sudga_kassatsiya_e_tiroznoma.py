# appelyatsiya_kassatsiya/e_tiroznomalar/iqtisodiy_sudga_kassatsiya_e_tiroznoma.py
"""
Iqtisodiy sudga kassatsiya shikoyati yuzasidan e’tiroznoma
"""

HUJJATLAR = {
    "FQ-ET-001": {
        "nomi": "Iqtisodiy sudga kassatsiya shikoyati yuzasidan e’tiroznoma",
        "jpk": "Iqtisodiy protsessual kodeksi 42, 293-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Iqtisodiy sudga kassatsiya shikoyati yuzasidan e’tiroznoma" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, e’tiroznoma beruvchi ma'lumotlari bo'lsin.
4. "E’TIROZNOMA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "E’tiroznoma berilgan fuqarolik sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "E’tiroznoma berilgan sana", "type": "date", "required": True},

            # E'TIROZNOMA BERUVCHI
            {"id": "etiroznomachi_manzil", "label": "E’tiroznoma beruvchining manzili", "type": "text", "required": True},
            {"id": "etiroznomachi_fio", "label": "E’tiroznoma beruvchining F.I.O.", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar", "label": "Ish bo‘yicha da’vogar", "type": "text", "required": True},
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Da’vo ariza mazmuni", "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ish bo‘yicha hal qiluv qarori qabul qilingan sana", "type": "date",
             "required": True},

            # SHIKOYAT BERGAN SHAXS
            {"id": "shikoyatchi_fio", "label": "Hal qiluv qarori ustidan shikoyat bergan shaxsning F.I.O.",
             "type": "text", "required": True},

            # E'TIROZ ASOSLARI
            {"id": "etiroz_asoslari",
             "label": "E’tiroznoma muallifi qaysi asoslarga ko‘ra kassatsiya shikoyatini asossiz deb hisoblashi",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "E’tiroznomaga ilova qilingan hujjatlar nomi", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Iqtisodiy ishlar bo‘yicha
                                                            {sud_nomi} sudiga

{etiroznomachi_manzil}da yashovchi
{etiroznomachi_fio}dan



                                                              E’TIROZNOMA

                                    sudning hal qiluv qarori ustidan berilgan kassatsiya shikoyati yuzasidan



Iqtisodiy ishlar bo‘yicha {sud_nomi} sudining ish yurituvida da’vogar {davogar}ning javobgar {javobgar}ga nisbatan {davo_mazmuni} to‘g‘risidagi da’vo arizasi yuzasidan {qaror_sana} kuni hal qiluv qarori qabul qilingan. Ushbu hal qiluv qarori ustidan {shikoyatchi_fio} tomonidan kassatsiya shikoyati berilgan.

O‘zbekiston Respublikasi Iqtisodiy protsessual kodeksining 42-moddasiga ko‘ra, ishda ishtirok etuvchi shaxslar boshqa taraflarning vajlariga qarshi e’tirozlar bildirish huquqiga ega.

Mazkur Kodeksning 293-moddasiga ko‘ra, ishda ishtirok etuvchi shaxs kassatsiya shikoyatining (protestining) ko‘chirma nusxasini olganidan keyin uning yuzasidan yozma fikrini hamda ishda ishtirok etuvchi boshqa shaxslarga ushbu yozma fikrning ko‘chirma nusxalari yuborilganligini tasdiqlovchi hujjatlarni kassatsiya shikoyati (protesti) ko‘rib chiqiladigan kunga qadar yetib borishini ta’minlaydigan muddatda, kassatsiya shikoyatini (protestini) ish yuritishga qabul qilish to‘g‘risida ajrim chiqarilgan kundan e’tiboran yigirma kundan kechiktirmay sudga yuborishga haqli.

Men quyidagilarga asosan sud qarorini qonuniy deb, ushbu shikoyatni esa asossiz deb hisoblayman:

{etiroz_asoslari}

Yuqoridagilardan kelib chiqib, O‘zbekiston Respublikasi Iqtisodiy protsessual kodeksining 42 hamda 293-moddalariga asoslanib, {shikoyatchi_fio}ning kassatsiya shikoyatini rad qilish maqsadga muvofiq deb hisoblayman.



Ilova: {ilova}



                                                              {etiroznomachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/e_tiroznomalar/fuqarolik_sudiga_appelyatsiya_e_tiroznoma.py
"""
Fuqarolik sudiga apellyasiya shikoyati yuzasidan e’tiroznoma
"""

HUJJATLAR = {
    "FQ-ET-002": {
        "nomi": "Fuqarolik sudiga apellyasiya shikoyati yuzasidan e’tiroznoma",
        "jpk": "Fuqarolik protsessual kodeksi 40-43, 391-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Fuqarolik sudiga apellyasiya shikoyati yuzasidan e’tiroznoma" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, e’tiroznoma beruvchi ma'lumotlari bo'lsin.
4. "E’TIROZNOMA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "E’tiroznoma berilgan fuqarolik sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "E’tiroznoma berilgan sana", "type": "date", "required": True},

            # E'TIROZNOMA BERUVCHI
            {"id": "etiroznomachi_manzil", "label": "E’tiroznoma beruvchining manzili", "type": "text", "required": True},
            {"id": "etiroznomachi_fio", "label": "E’tiroznoma beruvchining F.I.O.", "type": "text", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "davogar", "label": "Ish bo‘yicha da’vogar", "type": "text", "required": True},
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Da’vo ariza mazmuni", "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ish bo‘yicha hal qiluv qarori qabul qilingan sana", "type": "date",
             "required": True},

            # SHIKOYAT BERGAN SHAXS
            {"id": "shikoyatchi_fio", "label": "Hal qiluv qarori ustidan shikoyat bergan shaxsning F.I.O.",
             "type": "text", "required": True},

            # E'TIROZ ASOSLARI
            {"id": "etiroz_asoslari",
             "label": "E’tiroznoma muallifi qaysi asoslarga ko‘ra apellyatsiya shikoyatini asossiz deb hisoblashi",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "E’tiroznomaga ilova qilingan hujjatlar nomi", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari bo‘yicha
                                                            {sud_nomi} sudiga

{etiroznomachi_manzil}da yashovchi
{etiroznomachi_fio}dan



                                                              E’TIROZNOMA

                                    sudning hal qiluv qarori ustidan berilgan apellyatsiya shikoyati yuzasidan



Fuqarolik ishlari bo‘yicha {sud_nomi} sudining ish yurituvida da’vogar {davogar}ning javobgar {javobgar}ga nisbatan {davo_mazmuni} to‘g‘risidagi da’vo arizasi yuzasidan {qaror_sana} kuni hal qiluv qarori qabul qilingan. Ushbu hal qiluv qarori ustidan {shikoyatchi_fio} tomonidan apellyatsiya shikoyati berilgan.

O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 40-moddasiga ko‘ra, ishda ishtirok etuvchi shaxslar boshqa taraflarning vajlariga qarshi e’tirozlar bildirish huquqiga ega.

Mazkur Kodeksning 391-moddasiga ko‘ra, ishda ishtirok etuvchi shaxslar shikoyat (protest) yuzasidan sudga tushuntirishlar (e’tirozlar) ularni tasdiqlovchi hujjatlarni ilova qilib, taqdim etishga haqli. Tushuntirishlar (e’tirozlar) ishda ishtirok etuvchi shaxslar soniga qarab mutanosib miqdordagi ko‘chirma nusxalari bilan birga sudga taqdim etiladi, bundan elektron hujjat tarzida yuboriladigan tushuntirishlar (e’tirozlar) mustasno. Sud tushuntirishlarning (e’tirozlarning) ko‘chirma nusxalarini ishda ishtirok etuvchi shaxslarga topshiradi (yuboradi).

Men quyidagilarga asosan sud qarorini qonuniy deb, ushbu shikoyatni esa asossiz deb hisoblayman:

{etiroz_asoslari}

Yuqoridagilardan kelib chiqib, O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 40-43, hamda 391-moddalariga asoslanib, {shikoyatchi_fio}ning apellyatsiya shikoyatini rad qilish maqsadga muvofiq deb hisoblayman.



Ilova: {ilova}



                                                              {etiroznomachi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {ariza_sana} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/appelyatsiya_shikoyatlari/da_vo_arizani_kormasdan_qoldirish_ajrim_ustidan.py
"""
Da’vo arizani ko‘rmasdan qoldirish to‘g‘risidagi ajrim ustidan shikoyat (Xususiy shikoyat)
"""

HUJJATLAR = {
    "FQ-AS-001": {
        "nomi": "Da’vo arizani ko‘rmasdan qoldirish to‘g‘risidagi ajrim ustidan shikoyat (Xususiy shikoyat)",
        "jpk": "Fuqarolik protsessual kodeksi 3, 39, 40, 122, 123-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Da’vo arizani ko‘rmasdan qoldirish to‘g‘risidagi ajrim ustidan shikoyat (Xususiy shikoyat)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat beruvchi ma'lumotlari bo'lsin.
4. "XUSUSIY SHIKOYAT" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Xususiy shikoyat berilayotgan fuqarolik sud nomi", "type": "text",
             "required": True},
            {"id": "shikoyat_sana", "label": "Xususiy shikoyat berilgan sana", "type": "date", "required": True},

            # SHIKOYAT BERUVCHI
            {"id": "shikoyatchi_manzil", "label": "Xususiy shikoyat beruvchining manzili", "type": "text",
             "required": True},
            {"id": "shikoyatchi_fio", "label": "Xususiy shikoyat beruvchining F.I.O.", "type": "text", "required": True},

            # AJRIM MA'LUMOTLARI
            {"id": "quyi_sud_nomi", "label": "Ishni ko‘rmasdan qoldirish to‘g‘risida ajrim chiqargan sud nomi",
             "type": "text", "required": True},
            {"id": "ajrim_sana", "label": "Sud ishni ko‘rmasdan qoldirish to‘g‘risida ajrim chiqargan sana",
             "type": "date", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},
            {"id": "davo_mazmuni", "label": "Da’vo ariza mazmuni", "type": "text", "required": True},

            # SUD MAJLISLARI
            {"id": "birinchi_sana",
             "label": "Sud ajrimiga ko‘ra sud fuqarolik ishni sud majlisida ko‘rib chiqish uchun birinchi marta tayinlangan kun",
             "type": "date", "required": True},
            {"id": "ikkinchi_sana",
             "label": "Sud ajrimiga ko‘ra sud fuqarolik ishni sud majlisida ko‘rib chiqish uchun ikkinchi marta tayinlagan kun",
             "type": "date", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Arizaga ilova qilinadigan hujjatlar nomi", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi} sudiga

{shikoyatchi_manzil}da yashovchi fuqaro {shikoyatchi_fio}dan



                                                              XUSUSIY SHIKOYAT

                        {quyi_sud_nomi} sudining da’vo arizani ko‘rmasdan qoldirish to‘g‘risidagi {ajrim_sana} kungi ajrimi ustidan



Fuqarolik ishlar bo‘yicha {quyi_sud_nomi} sudiga men, ya’ni da’vogar {shikoyatchi_fio} javobgar {javobgar}ga nisbatan {davo_mazmuni} to‘g‘risidagi da’vo ariza bilan murojaat qilganman.

Sud o‘zining {ajrim_sana} kungi ajrimiga asosan ishni O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 122-moddasi 6-bandiga asosan, ya’ni ishni o‘zining ishtirokisiz muhokama qilishni iltimos qilmagan da’vogar ikkinchi chaqiruv bo‘yicha sudga kelmaganligi asosi bilan ko‘rmasdan qoldirgan.

Men ushbu ajrimni olganimdan so‘ng tushunishimcha, sud mening da’vo arizam bo‘yicha ishni ko‘rib chiqish uchun {birinchi_sana} hamda {ikkinchi_sana} sanalariga tayinlagan hamda da’vogar ishni ko‘rib chiqilishiga sababsiz kelmadi degan asos bilan ishni ko‘rmasdan qoldirgan.

Aslida esa menga ish ko‘rib chiqiladigan kun haqida xabar qilinmagan. Mening yashash manzilimga sud xabarnomasi yuborilmagan.

O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 123-moddasiga ko‘ra, ushbu Kodeks 122-moddasining 6-bandida nazarda tutilgan asoslar bo‘yicha arizani ko‘rmasdan qoldirish haqidagi sud ajrimi ustidan xususiy shikoyat berilishi mumkinligi belgilab qo‘yilgan.

Yuqoridagilardan kelib chiqib, O‘zbekiston Respublikasi Fuqarolik protsessual kodeksining 3, 39, 40, 122, 123-moddalariga asoslanib,



                                                              SO‘RAYMAN:



Fuqarolik ishlar bo‘yicha {quyi_sud_nomi} sudining {ajrim_sana} kungi ajrimini bekor qilib, mening da’vo arizamni ko‘rib chiqishga tayinlashingizni.



Ilova: {ilova}



                                                              {shikoyatchi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/appelyatsiya_shikoyatlari/ma_muriy_huquqbuzarlik_appelyatsiya.py
"""
Sudning maʼmuriy huquqbuzarlik to‘g‘risidagi qarori ustidan apellyatsiya shikoyati
"""

HUJJATLAR = {
    "FQ-AS-005": {
        "nomi": "Sudning maʼmuriy huquqbuzarlik to‘g‘risidagi qarori ustidan apellyatsiya shikoyati",
        "jpk": "Maʼmuriy javobgarlik toʻgʻrisidagi kodeks 314, 324-1, 324-3, 324-8-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sudning maʼmuriy huquqbuzarlik to‘g‘risidagi qarori ustidan apellyatsiya shikoyati" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat beruvchi ma'lumotlari bo'lsin.
4. "APELLYATSIYA SHIKOYATI" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Apellyatsiya shikoyati berilgan sud nomi", "type": "text", "required": True},
            {"id": "shikoyat_sana", "label": "Apellyatsiya shikoyati berilgan sana", "type": "date", "required": True},

            # SHIKOYAT BERUVCHI
            {"id": "shikoyatchi_fio", "label": "Apellyatsiya shikoyati beruvchi shaxsning F.I.O.", "type": "text",
             "required": True},
            {"id": "shikoyatchi_manzil", "label": "Apellyatsiya shikoyati beruvchi shaxsning manzili", "type": "text",
             "required": True},
            {"id": "shikoyatchi_telefon", "label": "Apellyatsiya shikoyati beruvchi shaxsning telefon raqami",
             "type": "text", "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "quyi_sud_nomi", "label": "Birinchi instansiya sudining nomi", "type": "text", "required": True},
            {"id": "qaror_sana",
             "label": "Birinchi instansiya sudi tomonidan maʼmuriy huquqbuzarlik to‘g‘risidagi qarori qabul qilingan sana",
             "type": "date", "required": True},
            {"id": "qaror_raqami",
             "label": "Birinchi instansiya sudi tomonidan maʼmuriy huquqbuzarlik to‘g‘risidagi qarori raqami",
             "type": "text", "required": True},

            # DA'VO DALILLARI
            {"id": "davo_dalillari", "label": "Apellyatsiya beruvchi shaxsning daʼvo arizasida ko‘rsatgan dalillari",
             "type": "textarea", "required": True},
            {"id": "davo_vajlari", "label": "Apellyatsiya beruvchi shaxsning daʼvo arizasida ko‘rsatgan vajlari",
             "type": "textarea", "required": True},
            {"id": "davo_asoslari", "label": "Apellyatsiya beruvchi shaxsning daʼvo talablarining asoslari",
             "type": "textarea", "required": True},
            {"id": "qoshimcha_vajlar",
             "label": "Apellyatsiya beruvchi shaxsning vajlari sud majlisida ko‘rsatgan qo‘shimcha vajlari",
             "type": "textarea", "required": True},

            # SUD XATOSI
            {"id": "sud_inobatga_olmagan_asoslar",
             "label": "Apellyatsiya beruvchi shaxsning sud inobatga olmagan deb xulosaga kelishiga sabab bo‘lgan asoslar",
             "type": "textarea", "required": True},
            {"id": "sud_buzgan_normalar",
             "label": "Sud qaysi normalarni buzgan va noto‘g‘ri qo‘llanganligi", "type": "textarea", "required": True},

            # ILTIMOS
            {"id": "iltimos",
             "label": "Shikoyat berayotgan shaxsning iltimosi (maʼmuriy huquqbuzarlik to‘g‘risidagi qarorni qanday mazmunda o‘zgartirish, butunlay yoki qisman bekor qilish)",
             "type": "textarea", "required": True},
        ],
        "shablon": """
***
                                                            {sud_nomi} sudiga

{shikoyatchi_fio}dan

Manzil: {shikoyatchi_manzil}
Telefon: {shikoyatchi_telefon}



                                                              APELLYATSIYA SHIKOYATI

                        {quyi_sud_nomi} sudining {qaror_sana} dagi maʼmuriy huquqbuzarlik toʻgʻrisidagi qarori ustidan



Quyidagilarga koʻra {quyi_sud_nomi} sudining {qaror_sana} dagi {qaror_raqami}-sonli maʼmuriy huquqbuzarlik toʻgʻrisidagi qarorini qonun talablari buzilgan holda qabul qilingan deb hisoblayman.

Men daʼvo arizamda {davo_dalillari}ligini koʻrsatib, suddan {davo_vajlari}ni soʻraganman va daʼvo talablarimning asosi sifatida {davo_asoslari}ni keltirganman.

Shuningdek, vajlarimning asosli ekanligi sud majlisida yana {qoshimcha_vajlar} bilan ham tasdigʻini topdi.

Biroq sud, {sud_inobatga_olmagan_asoslar}ni inobatga olmasdan, notoʻgʻri xulosaga kelgan.

Ishni koʻrishda sud tomonidan quyidagi normalar buzilib, notoʻgʻri qoʻllanilgan. Jumladan, {sud_buzgan_normalar}.

Oʻzbekiston Respublikasining Maʼmuriy javobgarlik toʻgʻrisidagi kodeksining (keyingi oʻrinlarda — MJTK) 324-1-moddasiga koʻra, maʼmuriy huquqbuzarlik toʻgʻrisidagi ish yuzasidan oʻziga nisbatan sudning qarori chiqarilgan shaxs, jabrlanuvchi, ularning qonuniy vakillari, advokat, shuningdek maʼmuriy huquqbuzarlik toʻgʻrisida bayonnoma tuzgan organ birinchi instansiya sudining qarori ustidan apellyatsiya shikoyati berishga, prokuror esa protest keltirishga haqli ekanligi belgilangan.

MJTKning 324-3-moddasiga koʻra, birinchi instansiya sudining maʼmuriy huquqbuzarlik toʻgʻrisidagi ish boʻyicha qarori ustidan apellyatsiya shikoyati (protesti) qaror oʻqib eshittirilgan kundan eʼtiboran yigirma sutka ichida, oʻziga nisbatan sud qarori chiqarilgan shaxs va jabrlanuvchi tomonidan esa, qarorning koʻchirma nusxalari ularga topshirilgan yoki ular tomonidan ushbu koʻchirma nusxalar olingan kundan eʼtiboran xuddi shu muddatda berilishi mumkin.

MJTKning 324-8-moddasiga koʻra, birinchi instansiya sudining qarori ustidan apellyatsiya shikoyatini (protestini) koʻrib chiqish natijalariga koʻra, apellyatsiya instansiyasi sudi birinchi instansiya sudi qarorini bekor qilish va ishni maʼmuriy huquqbuzarlik toʻgʻrisida bayonnoma tuzgan organga (mansabdor shaxsga) qaytarishga haqli.

Bayon etilganlardan kelib chiqib, MJTKning 314 va 3241-moddalariga asoslanib, apellyatsiya instansiyasi sudidan



                                                              SOʻRAYMAN:



{quyi_sud_nomi} sudining {qaror_sana} yildagi {qaror_raqami}-sonli maʼmuriy huquqbuzarlik toʻgʻrisidagi qarorini bekor qilishingizni va {iltimos}ni.



Ilova:
1. Davlat boji toʻlanganligini tasdiqlovchi hujjat.
2. Apellyatsiya shikoyati nusxalari.
3. Apellyatsiya shikoyati vakil tomonidan imzolangan taqdirda — uni imzolashga vakilning vakolatlarini tasdiqlovchi hujjat.
4. Apellyatsiya shikoyatidagi vajlarini tasdiqlovchi, ilgari sudga taqdim qilinmagan boshqa hujjatlar.



                                                              {shikoyatchi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/appelyatsiya_shikoyatlari/sud_ajrimi_ustidan_xususiy_shikoyat.py
"""
Sud ajrimi ustidan xususiy shikoyat
"""

HUJJATLAR = {
    "FQ-AS-011": {
        "nomi": "Sud ajrimi ustidan xususiy shikoyat",
        "jpk": "Fuqarolik protsessual kodeksi 319, 320, 321-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sud ajrimi ustidan xususiy shikoyat" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat beruvchi ma'lumotlari bo'lsin.
4. "XUSUSIY SHIKOYAT" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Xususiy shikoyat berilayotgan sud nomi", "type": "text", "required": True},
            {"id": "shikoyat_sana", "label": "Xususiy shikoyat berilgan sana", "type": "date", "required": True},

            # SHIKOYAT BERUVCHI
            {"id": "shikoyatchi_fio", "label": "Xususiy shikoyat beruvchining F.I.O.", "type": "text", "required": True},
            {"id": "shikoyatchi_manzil", "label": "Xususiy shikoyat beruvchining manzili", "type": "text",
             "required": True},
            {"id": "shikoyatchi_telefon", "label": "Xususiy shikoyat beruvchining telefon raqami", "type": "text",
             "required": False},

            # SUD AJRIMI MA'LUMOTLARI
            {"id": "quyi_sud_nomi", "label": "Ajrim chiqargan sud nomi", "type": "text", "required": True},
            {"id": "ajrim_sana", "label": "Ajrim chiqarilgan sana", "type": "date", "required": True},
            {"id": "ajrim_raqami", "label": "Ajrim raqami", "type": "text", "required": True},
            {"id": "ajrim_mazmuni", "label": "Ajrimning qisqacha mazmuni", "type": "textarea", "required": True},

            # ISH MA'LUMOTLARI
            {"id": "ish_raqami", "label": "Ish raqami", "type": "text", "required": True},
            {"id": "davogar", "label": "Ish bo‘yicha da’vogar", "type": "text", "required": True},
            {"id": "javobgar", "label": "Ish bo‘yicha javobgar", "type": "text", "required": True},

            # SHIKOYAT ASOSLARI
            {"id": "shikoyat_asoslari",
             "label": "Shikoyat muallifining fikriga ko‘ra sud ajrimi qaysi asoslarga ko‘ra noqonuniy?",
             "type": "textarea", "required": True},
            {"id": "buzilgan_normalar",
             "label": "Sud qaysi normalarni buzgan va noto‘g‘ri qo‘llaganligi", "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Shikoyatga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi} sudiga

{shikoyatchi_fio}dan
Manzil: {shikoyatchi_manzil}
Telefon: {shikoyatchi_telefon}



                                                              XUSUSIY SHIKOYAT

                        {quyi_sud_nomi} sudining {ajrim_sana} dagi {ajrim_raqami}-sonli ajrimi ustidan



{quyi_sud_nomi} sudining ish yurituvida {ish_raqami}-sonli fuqarolik ishi koʻrilmoqda. Mazkur ish bo‘yicha da’vogar {davogar}, javobgar {javobgar} hisoblanadi.

Sud tomonidan {ajrim_sana} kuni {ajrim_raqami}-sonli ajrim chiqarilgan boʻlib, ushbu ajrim bilan {ajrim_mazmuni} belgilangan.

Men ushbu ajrimni quyidagilarga asosan noqonuniy va asossiz deb hisoblayman:

{shikoyat_asoslari}

Bundan tashqari, ajrim chiqarishda sud tomonidan quyidagi normalar buzilgan va noto‘g‘ri qo‘llanilgan:

{buzilgan_normalar}

Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 319-moddasiga ko‘ra, sudning qonuniy kuchga kirmagan ajrimi ustidan taraflar va ishda ishtirok etayotgan boshqa shaxslar tomonidan xususiy shikoyat, protest berilishi mumkin.

Fuqarolik protsessual kodeksining 320-moddasiga ko‘ra, xususiy shikoyat berish huquqi berilgan shaxslar ushbu shikoyatni sud ajrimi chiqarilgan kundan eʼtiboran o‘n besh kun ichida berishlari mumkin.

Fuqarolik protsessual kodeksining 321-moddasiga ko‘ra, xususiy shikoyatni ko‘rib chiqish natijalariga ko‘ra, apellyatsiya instansiyasi sudi quyidagi vakolatlarga ega:

1) sud ajrimini oʻzgarishsiz, shikoyatni esa qanoatlantirmay qoldirish;
2) sud ajrimini bekor qilib, masalani birinchi instansiya sudiga yangidan ko‘rish uchun yuborish;
3) sud ajrimini oʻzgartirish yoki bekor qilish va yangi ajrim chiqarish.

Yuqoridagilardan kelib chiqib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 319-321-moddalariga asosan,



                                                              SOʻRAYMAN:



{quyi_sud_nomi} sudining {ajrim_sana} dagi {ajrim_raqami}-sonli ajrimini bekor qilib, masalani yangidan ko‘rish uchun birinchi instansiya sudiga yuborishingizni.



Ilova:
1. Xususiy shikoyat nusxalari.
2. Shikoyatdagi vajlarni tasdiqlovchi hujjatlar.
3. {ilova}



                                                              {shikoyatchi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
# appelyatsiya_kassatsiya/appelyatsiya_shikoyatlari/sud_jarima_tayinlash_qarori_ustidan.py
"""
Sudning jarima tayinlash qarori ustidan shikoyat (Apellyatsiya shikoyati)
"""

HUJJATLAR = {
    "FQ-AS-004": {
        "nomi": "Sudning jarima tayinlash qarori ustidan shikoyat (Apellyatsiya shikoyati)",
        "jpk": "Maʼmuriy huquqbuzarlik to‘g‘risidagi Kodeks 3241-3249-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Sudning jarima tayinlash qarori ustidan shikoyat" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat muallifi ma'lumotlari bo'lsin.
4. "APELLYATSIYA SHIKOYATI" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Shikoyat berilgan jinoyat sudi nomi", "type": "text", "required": True},
            {"id": "shikoyat_sana", "label": "Shikoyat berilgan sana", "type": "date", "required": True},

            # SHIKOYAT MUALLIFI
            {"id": "shikoyatchi_manzil", "label": "Shikoyat muallifining manzili", "type": "text", "required": True},
            {"id": "shikoyatchi_fio", "label": "Shikoyat muallifining F.I.O.", "type": "text", "required": True},

            # YTH MA'LUMOTLARI
            {"id": "yth_sana", "label": "Yo‘l transport hodisasi sodir bo‘lgan sana", "type": "date", "required": True},
            {"id": "shikoyatchi_avto_rusumi", "label": "Shikoyat muallifining avtomashinasi rusumi", "type": "text",
             "required": True},
            {"id": "shikoyatchi_davlat_raqam", "label": "Shikoyat muallifining davlat raqam belgisi", "type": "text",
             "required": True},
            {"id": "yth_manzil", "label": "Yo‘l transport hodisasi sodir bo‘lgan manzil", "type": "text", "required": True},

            # JABRLANUVCHI
            {"id": "jabrlanuvchi_fio", "label": "Jablanuvchining F.I.O.", "type": "text", "required": True},
            {"id": "jabrlanuvchi_avto_rusumi", "label": "Jablanuvchining avtomashinasi rusumi", "type": "text",
             "required": True},
            {"id": "jabrlanuvchi_davlat_raqam", "label": "Jablanuvchi avtomashinasining davlat raqam belgisi",
             "type": "text", "required": True},
            {"id": "zarar_miqdori", "label": "Jablanuvchining avtomashinasiga yetkazilgan zarar miqdori (so‘mda)",
             "type": "text", "required": True},

            # SUD QARORI
            {"id": "quyi_sud_nomi", "label": "Ma’muriy jarima belgilash to‘g‘risida qaror qabul qilgan sud nomi",
             "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ma’muriy jarima belgilash to‘g‘risida qaror qabul qilingan sana",
             "type": "date", "required": True},
            {"id": "mjk_modda", "label": "MJtKning shikoyat muallifi javobgarlikka tortilgan moddasi", "type": "text",
             "required": True},
            {"id": "jarima_miqdori", "label": "Shikoyat muallifiga belgilangan jarima miqdori", "type": "text",
             "required": True},

            # SHIKOYAT ASOSLARI
            {"id": "shikoyat_asoslari",
             "label": "Sud qarori nima sababdan asossiz va noqonuniy deb hisoblanayotganligi", "type": "textarea",
             "required": True},

            # YANGI QAROR
            {"id": "yangi_qaror_mazmuni",
             "label": "Apellyatsiya instansiyasi tomonidan qabul qilinishi so‘ralayotgan yangi qarorning mazmuni",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "ilova", "label": "Shikoyatga ilova qilinadigan hujjatlar ro‘yxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            Jinoyat ishlari bo‘yicha
                                                            {sud_nomi} sudiga

{shikoyatchi_manzil}da yashovchi
{shikoyatchi_fio}dan



                                                              APELLYATSIYA SHIKOYATI

                        {quyi_sud_nomi} sudining menga nisbatan {qaror_sana} kuni chiqarilgan qarori ustidan



{yth_sana} kuni men o‘z boshqaruvimdagi {shikoyatchi_avto_rusumi} rusumli davlat raqam belgisi {shikoyatchi_davlat_raqam} bo‘lgan avtomashina bilan {yth_manzil} ko‘chalari kesishmasiga boshqarib kelib, amaldagi yo‘l harakati qoidalari talablarini buzishim natijasida {jabrlanuvchi_fio}ning boshqaruvida bo‘lgan {jabrlanuvchi_avto_rusumi} rusumli {jabrlanuvchi_davlat_raqam} davlat belgili avtomashinaga urilib, yo‘l transport hodisasini sodir qildim. Natijada {jabrlanuvchi_fio}ning avtomashinasiga {zarar_miqdori} so‘m miqdorida zarar yetgan.

Ushbu holat bo‘yicha {quyi_sud_nomi} sudining {qaror_sana} kunidagi qaroriga asosan men MJtKning {mjk_modda} moddasi bilan aybdor deb topilib, menga {jarima_miqdori} so‘m miqdorida jarima jazosi belgilangan.

Men ushbu jarima jazosini quyidagilarga asosan asossiz va noqonuniy deb hisoblayman:

{shikoyat_asoslari}

O‘zbekiston Respublikasining Ma’muriy huquqbuzarlik to‘g‘risidagi Kodeksining 3241-moddasiga ko‘ra, ma’muriy huquqbuzarlik to‘g‘risidagi ish yuzasidan o‘ziga nisbatan sudning qarori chiqarilgan shaxs, jabrlanuvchi, ularning qonuniy vakillari, advokat, shuningdek ma’muriy huquqbuzarlik to‘g‘risida bayonnoma tuzgan organ birinchi instansiya sudining qarori ustidan apellyatsiya shikoyati berishga, prokuror esa protest keltirishga haqli.

Mazkur Kodeksning 3248-moddasiga ko‘ra, birinchi instansiya sudining qarori ustidan apellyatsiya shikoyatini (protestini) ko‘rib chiqish natijalariga ko‘ra, apellyatsiya instansiyasi birinchi instansiya sudi qarorini, shuningdek organning (mansabdor shaxsning) qarorini bekor qilish va ishni ma’muriy huquqbuzarlik to‘g‘risida bayonnoma tuzgan organga (mansabdor shaxsga) qaytarish haqida, birinchi instansiya sudi qarorini bekor qilish va ish yuritishni tugatish to‘g‘risida qaror qabul qilishi mumkin.

Qayd qilingan holatlar hamda O‘zbekiston Respublikasining Ma’muriy huquqbuzarlik to‘g‘risidagi Kodeksining 3241-3249-moddalariga asosan,



                                                              SO‘RAYMAN:



{quyi_sud_nomi} sudining {qaror_sana} kunidagi qarorini bekor qilib, {yangi_qaror_mazmuni} to‘g‘risida qaror qabul qilishingizni.



Ilova: {ilova}



                                                              {shikoyatchi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
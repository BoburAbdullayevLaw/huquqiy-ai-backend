import importlib.util
from pathlib import Path

HUJJATLAR = {}
_dir = Path(__file__).parent

for _f in _dir.glob('*.py'):
    if _f.name.startswith('_'):
        continue
    try:
        spec = importlib.util.spec_from_file_location(_f.stem, _f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if hasattr(mod, 'HUJJATLAR'):
            HUJJATLAR.update(mod.HUJJATLAR)
    except Exception as e:
        print(f"XATO {_f.name}: {e}")

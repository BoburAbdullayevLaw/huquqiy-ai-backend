# appelyatsiya_kassatsiya/appelyatsiya_shikoyatlari/fuqarolik_sudiga_appelyatsiya_general.py
"""
Appelyatsiya shikoyati (Fuqarolik sudi uchun umumiy shablon)
"""

HUJJATLAR = {
    "FQ-AS-008": {
        "nomi": "Appelyatsiya shikoyati (Fuqarolik sudi uchun)",
        "jpk": "Fuqarolik protsessual kodeksi 372, 383, 399-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Appelyatsiya shikoyati (Fuqarolik sudi uchun)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, shikoyat beruvchi ma'lumotlari bo'lsin.
4. "APELLYATSIYA SHIKOYATI" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Apellyatsiya shikoyati berilgan sud nomi", "type": "text", "required": True},
            {"id": "shikoyat_sana", "label": "Shikoyat berilgan sana", "type": "date", "required": True},

            # SHIKOYAT BERUVCHI
            {"id": "shikoyatchi_fio", "label": "Shikoyat beruvchining F.I.O.", "type": "text", "required": True},
            {"id": "shikoyatchi_manzil", "label": "Shikoyat beruvchining manzili", "type": "text", "required": True},
            {"id": "shikoyatchi_telefon", "label": "Shikoyat beruvchining telefon raqami", "type": "text",
             "required": True},

            # SUD QARORI MA'LUMOTLARI
            {"id": "quyi_sud_nomi", "label": "Ustidan shikoyat berilayotgan qarorni qabul qilgan sud nomi",
             "type": "text", "required": True},
            {"id": "qaror_sana", "label": "Ustidan shikoyat berilayotgan qaror qabul qilingan sana", "type": "date",
             "required": True},

            # ISH MA'LUMOTLARI
            {"id": "ish_holatlari", "label": "Daʼvo arizada bayon qilingan ish holatlari (daʼvo arizasining qisqacha mazmuni)",
             "type": "textarea", "required": True},
            {"id": "davo_talabi", "label": "Daʼvogarning daʼvo talabi", "type": "text", "required": True},
            {"id": "asos_holatlar", "label": "Daʼvo arizaga asos sifatida koʻrsatilgan holatlar", "type": "textarea",
             "required": True},

            # DALLILAR
            {"id": "isbotlangan_dalillar",
             "label": "Daʼvogarning fikricha uning vajlarini sud majlisida isbotlagan dalillar", "type": "textarea",
             "required": True},

            # SUD XATOSI
            {"id": "sud_inobatga_olmagan_holatlar", "label": "Daʼvogarning fikricha sud inobatga olmagan holatlar",
             "type": "textarea", "required": True},
            {"id": "buzilgan_normalar",
             "label": "Ishni koʻrishda sud tomonidan qaysi normalar buzilgan yoki notoʻgʻri qoʻllanilgan",
             "type": "textarea", "required": True},

            # QO'SHIMCHA TALAB
            {"id": "qoshimcha_talab",
             "label": "Apellyatsiya instansiyasiga birinchi instansiya sudi qarorini bekor qilishdan tashqari yana qanday talablar qoʻyiladi (masalan yangi hal qiluv qarori chiqarish, arizani koʻrmasdan qoldirish yoxud ish yuritishni tugatish toʻgʻrisida yangi qaror qabul qilish yoki boshqa)",
             "type": "textarea", "required": True},

            # ILOVA
            {"id": "boshqa_hujjatlar", "label": "Shikoyatga ilova qilinayotgan boshqa hujjatlar roʻyxati",
             "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha
                                                            {sud_nomi} apellyatsiya instansiyasiga

Daʼvogar: {shikoyatchi_fio}
Manzil: {shikoyatchi_manzil}
Telefon: {shikoyatchi_telefon}



                                                              APELLYATSIYA SHIKOYATI

                        (Fuqarolik ishlari boʻyicha {quyi_sud_nomi} sudining {qaror_sana} dagi qarori ustidan)



Quyidagilarga koʻra, fuqarolik ishlari boʻyicha {quyi_sud_nomi} sudining {qaror_sana} dagi hal qiluv qarorini qonun talablari buzilgan holda qabul qilingan deb hisoblayman.

Men, daʼvo arizamda {ish_holatlari}ligini koʻrsatib, suddan {davo_talabi}ni soʻraganman va daʼvo talablarimning asosi sifatida {asos_holatlar}ni keltirganman.

Shuningdek, vajlarimning asosli ekanligi sud majlisida yana {isbotlangan_dalillar} kabi dalillar bilan ham tasdigʻini topdi.

Biroq sud, {sud_inobatga_olmagan_holatlar}ni inobatga olmasdan, notoʻgʻri xulosaga kelgan.

Ishni koʻrishda sud tomonidan quyidagi normalar buzilib, notoʻgʻri qoʻllanilgan. Jumladan, {buzilgan_normalar}.

Fuqarolik protsessual kodeksining 383-moddasiga koʻra, taraflar va ishda ishtirok etishga jalb qilingan boshqa shaxslar, shuningdek ishda ishtirok etishga jalb qilinmagan, ammo huquq va majburiyatlari haqidagi masala sud tomonidan hal etilgan shaxslar, shuningdek Oʻzbekiston Respublikasi Prezidenti huzuridagi Tadbirkorlik subyektlarining huquqlari va qonuniy manfaatlarini himoya qilish boʻyicha vakil sudning qonuniy kuchga kirmagan hal qiluv qarori, ajrimi, qarori ustidan apellyatsiya tartibida shikoyat qilishi mumkin, bundan tadbirkorlik faoliyati bilan bogʻliq boʻlmagan nizolar mustasno.

Fuqarolik protsessual kodeksining 372-2-moddasiga koʻra, sud hujjatini apellyatsiya tartibida bekor qilishga yoki oʻzgartirishga quyidagilar asos boʻladi:

1) ish uchun ahamiyatga ega boʻlgan holatlarning toʻliq aniqlanmaganligi;
2) sud aniqlangan deb hisoblagan, ish uchun ahamiyatga ega boʻlgan holatlarning isbotlanmaganligi;
3) sud hujjatida bayon etilgan sud xulosalarining ish holatlariga muvofiq emasligi;
4) bildirilgan talab boʻyicha sud tomonidan sud hujjatining qabul qilinmaganligi;
5) moddiy va protsessual huquq normalarining buzilganligi yoki notoʻgʻri qoʻllanilganligi.

Mazkur holatda, sud tomonidan ish uchun ahamiyatga ega boʻlgan holatlar toʻliq aniqlanmaganligi; sud aniqlangan deb hisoblagan, ish uchun ahamiyatga ega boʻlgan holatlarning isbotlanmaganligi; sud hujjatida bayon etilgan sud xulosalarining ish holatlariga muvofiq emasligi; bildirilgan talab boʻyicha sud tomonidan sud hujjatining qabul qilinmaganligi; moddiy huquq normalarining yoki protsessual huquq normalarining buzilganligi yoki notoʻgʻri qoʻllanilganligi sababli hal qiluv qarorini bekor qilish (oʻzgartirish) lozim boʻladi.

Bayon etilganlardan kelib chiqib, Fuqarolik protsessual kodeksining 399-moddasiga asoslanib, apellyatsiya instansiyasi sudidan



                                                              SOʻRAYMAN:



Fuqarolik ishlari boʻyicha {quyi_sud_nomi} sudining {qaror_sana} dagi hal qiluv qarorini bekor qilishingizni va {qoshimcha_talab}ni.



ILOVA:

1. Davlat boji toʻlanganligini tasdiqlovchi hujjat;
2. Apellyatsiya shikoyati nusxalari;
3. Apellyatsiya shikoyati vakil tomonidan imzolangan taqdirda - uni imzolashga vakilning vakolatlarini tasdiqlovchi hujjat;
4. Apellyatsiya shikoyatidagi vajlarini tasdiqlovchi, ilgari sudga taqdim qilinmagan boshqa hujjatlar;
5. {boshqa_hujjatlar}



                                                              Daʼvogar: {shikoyatchi_fio}

                                                              _________________
                                                                   (imzo)

                                                              {shikoyat_sana} yil.
***
"""
    }
}
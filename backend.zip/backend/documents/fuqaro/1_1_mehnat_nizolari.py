# 1_1_mehnat_nizolari/fuqarolik_huquqiy_munosabatni_mehnat_deb_topish.py
"""
Fuqarolik-huquqiy xususiyatga ega shartnoma asosida yuzaga kelgan munosabatlarni
sud tomonidan yakka tartibdagi mehnatga oid munosabatlar deb eʼtirof etish toʻgʻrisida da'vo arizasi
"""

HUJJATLAR = {
    "FQ-MN-001": {
        "nomi": "Fuqarolik-huquqiy xususiyatga ega shartnoma asosida yuzaga kelgan munosabatlarni sud tomonidan yakka tartibdagi mehnatga oid munosabatlar deb eʼtirof etish toʻgʻrisida da'vo arizasi",
        "jpk": "Mehnat kodeksi 33-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Fuqarolik-huquqiy xususiyatga ega shartnoma asosida yuzaga kelgan munosabatlarni sud tomonidan yakka tartibdagi mehnatga oid munosabatlar deb eʼtirof etish toʻgʻrisida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. Sarlavha va "SOʻRAYMAN" markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": False},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Daʼvogar javobgar tashkilotda mehnat faoliyatini boshlagan sana",
             "type": "date", "required": True},
            {"id": "lavozimi", "label": "Daʼvogarning lavozimi", "type": "text", "required": True},
            {"id": "buyruq_raqami", "label": "Daʼvogarni ishga qabul qilish toʻgʻrisidagi buyruq raqami",
             "type": "text", "required": True},
        ],
        "shablon": """
***Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                    Daʼvogar: {davogar_fio}
                                    Manzil: {davogar_manzil}
                                    Telefon: {davogar_telefon}
                                    Elektron manzil: {davogar_email}

                                    Javobgar: {javobgar_nomi}
                                    Manzil: {javobgar_manzil}
                                    STIR: {javobgar_stir}
                                    Telefon: {javobgar_telefon}
                                    Elektron manzil: {javobgar_email}



                                                      DAʼVO ARIZASI

                                      (Fuqarolik-huquqiy xususiyatga ega shartnoma asosida yuzaga kelgan 
                                       munosabatlarni sud tomonidan yakka tartibdagi mehnatga oid 
                                            munosabatlar deb eʼtirof etish toʻgʻrisida)

Men {davogar_fio} {javobgar_nomi} (keyingi oʻrinlarda – javobgar)da {ish_boshlagan_sana} kunidan fuqarolik-huquqiy shartnomasi asosida {lavozimi} sifatida faoliyat yuritib kelaman.

Bu toʻgʻrisida javobgar va men oʻrtamda {ish_boshlagan_sana} dagi {buyruq_raqami}-sonli fuqarolik huquqiy shartnomasi tuzilgan va ushbu shartnomaga muvofiq men javobgar tomonidan menga topshirilgan ishlarni oʻz vaqtida bajarishim va shunga binoan javobgar menga har oyda ish haqi toʻlovlarini toʻlab borishi koʻrsatilgan.

Men shu vaqtga qadar oʻzimga yuklatilgan majburiyatlarni va vazifalarni oʻz vaqtida hamda sifatli ravishda bajarib kelyapman, faoliyatimga nisbatan shu paytgacha hech qanday eʼtirozlar bildirilmagan.

Biroq, javobgar tomoni shu vaqtga qadar menga qolgan xodimlarga berilayotgan mehnat taʼtili, vaqtincha mehnatga layoqatsiz boʻlganimda kasallik nafaqasi, mukofotlar, ustamalar va boshqa kompensatsiya toʻlovlarini toʻlamasdan kelmoqda.

Garchi men bilan javobgar oʻrtasida fuqarolik-huquqiy tusdagi shartnoma tuzilgan boʻlsada, aslida menga nisbatan mehnat munosabatlariga oid shartlar va qoidalar qoʻllanib kelmoqda. Misol uchun, fuqarolik-huquqiy shartnomasida javobgar – ish beruvchi deb, men esa xodim deb koʻrsatilganman.

Bundan tashqari, menga fuqarolik-huquqiy munosabatini anglatuvchi xizmat yoki ish topshirilmagan, aksincha, oʻrtadagi shartnomaga va tashkilot rahbarining buyrugʻi bilan ushbu lavozimga tayinlanganman.

Oʻzbekiston Respublikasi Mehnat kodeksining 33-moddasiga asosan jismoniy shaxs bilan ushbu Kodeks 11-moddasining ikkinchi qismida nazarda tutilgan munosabatlarni haqiqatdan tartibga soluvchi fuqarolik-huquqiy xususiyatga ega shartnomani tuzish ushbu munosabatlarning sud tomonidan yakka tartibdagi mehnatga oid munosabatlar deb eʼtirof etilishiga sabab boʻladi. Bunday holda mehnat shartnomasi fuqarolik-huquqiy xususiyatga ega shartnoma tuzilgan kundan eʼtiboran tuzilgan deb hisoblanadi, taraflarning munosabatlari esa shartnomada shartlashilgan ishni jismoniy shaxs tomonidan bajarish boshlangan kundan eʼtiboran yakka tartibdagi mehnatga oid munosabatlar deb eʼtirof etiladi.

Yuqorida men keltirib oʻtgan shartlar Oʻzbekiston Respublikasi Mehnat kodeksi bilan belgilangan yakka tartibdagi mehnatga oid munosabatlarni yuzaga keltiruvchi shartlar hisoblanib, bu aslida men bilan fuqarolik-huquqiy emas, balki mehnatga oid munosabatlar oʻrnatilganini toʻliq tasdiqlaydi.

Shunga koʻra, men va javobgar oʻrtasida tuzilgan fuqarolik-huquqiy shartnoma aslida yakka tartibdagi mehnatga oid munosabatlar yuzasidan tuzilgan va aslida men bilan mehnat shartnomasi tuzilib, mehnat qonunchiligida nazarda tutilgan barcha mehnat kafolatlari (taʼtillar, ijtimoiy nafaqalar, ish haqi va ish haqiga qoʻshimcha toʻlovlar, mukofotlar, kompensatsiya toʻlovlari va boshqalar) berilishi kerak edi.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,

                                                      SOʻRAYMAN:

Javobgar {javobgar_nomi} va men {davogar_fio} oʻrtamizda tuzilgan {ish_boshlagan_sana} dagi {buyruq_raqami}-sonli fuqarolik huquqiy shartnomasidan kelib chiqqan munosabatlarni yakka tartibdagi mehnatga oid munosabatlar deb eʼtirof etilsin.

Ilova:
1. Fuqarolik-huquqiy shartnoma nusxasi
2. Davlat boji toʻlanganligi toʻgʻrisidagi kvitansiya

Daʼvogar: ___________ {davogar_fio}

{ariza_sana}
***
"""
    },
"FQ-MN-002": {
        "nomi": "Ish beruvchining xatosi sababli to‘lanmagan ish haqini undirish to‘g‘risida da’vo arizasi",
        "jpk": "Mehnat kodeksi 154, 161, 244, 250, 257-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish beruvchining xatosi sababli to‘lanmagan ish haqini undirish to‘g‘risida da’vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi (roʻyxat)", "type": "select",
             "options": ["Fuqarolik ishlari boʻyicha tumanlararo sud", "Iqtisodiy sud", "Maʼmuriy sud"],
             "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.Sh", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI (YURIDIK SHAXS)
            {"id": "javobgar_nomi", "label": "Javobgar yuridik shaxsning toʻliq nomi", "type": "text",
             "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_hisob_raqami", "label": "Javobgarning hisob raqami", "type": "text", "required": False},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_mfo", "label": "Javobgarning MFO raqami", "type": "text", "required": False},
            {"id": "javobgar_oked", "label": "Javobgarning OKED raqami", "type": "text", "required": False},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # RAHBAR MA'LUMOTLARI
            {"id": "rahbar_mansabi", "label": "Yuridik shaxs rahbarining mansabi", "type": "text", "required": True},
            {"id": "rahbar_fio", "label": "Yuridik shaxs rahbarining F.I.Sh", "type": "text", "required": True},

            # ISHGA QABUL QILISH MA'LUMOTLARI
            {"id": "ishga_kabul_sana", "label": "Ishga qabul qilish sanasi", "type": "date", "required": True},
            {"id": "buyruq_raqami", "label": "Ishga qabul qilish buyruq raqami", "type": "text", "required": True},
            {"id": "lavozimi", "label": "Daʼvogar ishlab kelgan lavozimi nomi", "type": "text", "required": True},
            {"id": "tarif_razryadi", "label": "Daʼvogarning yagona tarif setkasi boʻyicha mehnat razryadi",
             "type": "text", "required": True},

            # ISH HAQI MA'LUMOTLARI
            {"id": "tolanishi_lozim_summa", "label": "Aslida 1 oyda toʻlanishi lozim boʻlgan summa", "type": "text",
             "required": True},
            {"id": "kam_hisoblanish_sababi", "label": "Daʼvogarning ish haqi kam hisoblanishining sabablari",
             "type": "textarea", "required": True},
            {"id": "amalda_tolangan_summa", "label": "Amalda 1 oyda toʻlangan summa", "type": "text", "required": True},
            {"id": "notogri_hisoblash_boshlangan_sana", "label": "Ish haqini notoʻgʻri hisoblash boshlangan sana",
             "type": "date", "required": True},
            {"id": "notogri_hisoblash_tugagan_sana", "label": "Ish haqini notoʻgʻri hisoblash tugagan sana",
             "type": "date", "required": True},
            {"id": "tolanmagan_umumiy_miqdor", "label": "Ish haqining toʻlanmagan umumiy miqdori", "type": "text",
             "required": True},
            {"id": "notogri_hisoblangan_miqdor", "label": "Notoʻgʻri hisoblangan ish haqi umumiy miqdori",
             "type": "text", "required": True},
            {"id": "jami_tolanishi_lozim", "label": "Jami toʻlanishi lozim boʻlgan pul miqdori", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            Hisob raqami: {javobgar_hisob_raqami}
                                                            STIR: {javobgar_stir}
                                                            MFO: {javobgar_mfo}
                                                            OKED: {javobgar_oked}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: {jami_tolanishi_lozim} soʻm miqdorida toʻlanmagan ish haqini undirish toʻgʻrisida



                                                            DAʼVO ARIZASI



{javobgar_nomi} {rahbar_mansabi} {rahbar_fio}ning {ishga_kabul_sana} {buyruq_raqami} buyrugʻi asosida {lavozimi} vazifasiga ishga qabul qilinganman.

Shu kunga qadar mehnat shartnomasida qayd qilingan vazifalarimni hamda ish beruvchining barcha topshiriqlarini amalga oshirgan holda mehnat faoliyati bilan shugʻullanib kelmoqdaman. Yagona tarif setkasi boʻyicha mening razryadim {tarif_razryadi}. Mening razryadimdan kelib chiqqan holda har oyda {tolanishi_lozim_summa} soʻm oylik ish haqi hisoblanishi lozim boʻlsada, ammo {kam_hisoblanish_sababi} sababli menga amalda {amalda_tolangan_summa} soʻm oylik ish haqi hisoblab kelingan.

Amaldagi Mehnat kodeksining 250-moddasiga koʻra, tarifli tizim tarif setkasini, tarif stavkalarini (maoshlarni), tarif razryadlarini, tarif koeffitsiyentlarini oʻz ichiga oladi. Tarif razryadi ishlarning murakkabligini va xodimning malaka darajasini aks ettiradigan qiymatdir. Tarif koeffitsiyenti keyingi razryadlar tarif stavkasining birinchi razryad tarif stavkasiga nisbatan karrali koʻpaytirilishini aks ettiradigan, xodimlar malaka darajasining razryadlar boʻyicha nisbatidir.

Shuningdek, mazkur Kodeksning 257-moddasiga koʻra, mehnatga haq toʻlashning ishbay tizimida narxlar belgilangan ish razryadlaridan, mehnatga haq toʻlash razryadlaridan, tarif stavkalaridan (maoshlardan) va ishlab berish normalaridan (vaqt normalaridan) kelib chiqqan holda aniqlanadi.

Amaldagi Mehnat kodeksining 244-moddasiga muvofiq, ish beruvchi oʻz moliyaviy ahvolidan qatʼi nazar, qonunchilikda, mehnat haqidagi boshqa huquqiy hujjatlarda, mehnat shartnomasida belgilangan mehnatga haq toʻlash shartlariga muvofiq xodimlar tomonidan bajarilgan ish uchun haq toʻlashni amalga oshirishi lozim.

Shuningdek, qonunchilik hujjatlariga koʻra, xodimlarning ayrim toifalari uchun alohida hollarda Oʻzbekiston Respublikasi Hukumati tomonidan ish haqi toʻlashning boshqa muddatlari belgilab qoʻyilishi mumkin. Haq toʻlanadigan kun dam olish kuni yoki bayram kuniga toʻgʻri kelib qolsa, mehnat haqi shu kun arafasida toʻlanadi. Jamoa shartnomasida ish beruvchining aybi bilan xodimga haq toʻlash belgilangan muddatlarga nisbatan kechikkanligi uchun javobgarlik nazarda tutilishi mumkin.

Biroq ish beruvchi tomonidan mening {notogri_hisoblash_boshlangan_sana} yildan {notogri_hisoblash_tugagan_sana} yilga qadar boʻlgan mehnat faoliyatim uchun ish haqim notoʻgʻri hisoblanib, kam miqdorda oylik ish haqi toʻlanib kelinmoqda.

Soha mutaxassislarining hisob kitobiga koʻra, ish haqlarimni hisoblashda xatolikka yoʻl qoʻyilib, amalda koʻrsatilgan davrda ish haqim miqdori {tolanmagan_umumiy_miqdor} soʻmni tashkil etsada, ish beruvchi {notogri_hisoblangan_miqdor} soʻm miqdorida ish haqi hisoblab, xatolikka yoʻl qoʻyilib, menga jami {jami_tolanishi_lozim} soʻm oylik ish haqim toʻlanmasdan kelmoqda.

Yuqorida qayd etilganlarga koʻra, Mehnat kodeksining 154, 161-moddalari, hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan,



                                                            SOʻRAYMAN:



Mening foydamga javobgar {javobgar_nomi} dan {jami_tolanishi_lozim} soʻm miqdoridagi ish haqi pullarimni undirishingizni.

Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.



Izoh: Daʼvo ariza vakil orqali berilgan hollarda vakil tomonidan imzolanadi. Vakilning vakolatini tasdiqlovchi ishonchnoma daʼvo arizasiga ilova qilinishi shart.
***
"""
    },
    "FQ-MN-003": {
        "nomi": "Mehnatda shikastlanganlik uchun to‘lov undirish to‘g‘risida da’vo arizasi",
        "jpk": "Mehnat kodeksi 189, 322, 323, 324-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mehnatda shikastlanganlik uchun to‘lov undirish to‘g‘risida da’vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.Sh.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar yuridik shaxsning toʻliq nomi", "type": "text",
             "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_hisob_raqami", "label": "Javobgarning hisob raqami", "type": "text", "required": False},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_mfo", "label": "Javobgarning MFO raqami", "type": "text", "required": False},
            {"id": "javobgar_oked", "label": "Javobgarning OKED raqami", "type": "text", "required": False},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana",
             "label": "Daʼvogar egallab turgan vazifasida (lavozimida) qachondan buyon ishlab kelyotganligi",
             "type": "text", "required": True},
            {"id": "korxona_nomi", "label": "Javobgar korxona nomi", "type": "text", "required": True},
            {"id": "lavozimi", "label": "Daʼvogar ishlab kelgan vazifa (lavozim) nomi", "type": "text",
             "required": True},

            # BAXTSIZ HODISHA
            {"id": "baxtsiz_hodisa_vaqti",
             "label": "Ishlab chiqarish jarayonida xodimning sogʻligʻiga zarar yetkazgan baxtsiz hodisa sodir boʻlgan vaqt",
             "type": "text", "required": True},
            {"id": "hodisa_mazmuni", "label": "Baxtsiz hodisaning qisqacha mazmuni", "type": "textarea",
             "required": True},
            {"id": "mehnat_qobiliyat_foizi",
             "label": "Baxtsiz hodisa natijasida mehnat qobiliyatining necha foizi yoʻqotilganligi", "type": "text",
             "required": True},
            {"id": "rasmiylashtirilgan_hujjatlar",
             "label": "Baxtsiz hodisa va uning oqibatlari yuzasidan qanday hujjatlar rasmiylashtirilganligi",
             "type": "text", "required": True},

            # ZARAR TO'LANMASLIK SABABI
            {"id": "tolamaslik_sababi", "label": "Sogʻliqqa yetkazilgan zarar toʻlanmasligi sabablari",
             "type": "textarea", "required": True},

            # ZARAR MIQDORI
            {"id": "zarar_summasi", "label": "Daʼvogar sogʻligʻiga yetkazilgan zarar summasi", "type": "text",
             "required": True},

            # DA'VO ASOSI
            {"id": "davo_asosi",
             "label": "Daʼvo talabiga asos sifatida keltirilgan hujjatlar roʻyxati va ishga oid boshqa holatlar",
             "type": "textarea", "required": True},

            # UNDIRILISHI SO'RALAYOTGAN SUMMA
            {"id": "undiriladigan_summa", "label": "Javobgardan undirilishi soʻralayotgan summa", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            Hisob raqami: {javobgar_hisob_raqami}
                                                            STIR: {javobgar_stir}
                                                            MFO: {javobgar_mfo}
                                                            OKED: {javobgar_oked}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            Daʼvo mazmuni:
                                                            Ishlab chiqarish jarayonida mehnatda shikastlanganlik uchun {undiriladigan_summa} soʻm toʻlov undirish toʻgʻrisida



                                                            DAʼVO ARIZA



Men {davogar_fio} {ish_boshlagan_sana} yildan buyon {korxona_nomi} korxonasida {lavozimi} vazifasida ishlab kelganman.

{baxtsiz_hodisa_vaqti} yilda korxonada {hodisa_mazmuni} sodir boʻlganligi tufayli sogʻligʻimga shikast yetdi. Natijada men mehnat qobiliyatimning {mehnat_qobiliyat_foizi} foizini yoʻqotdim.

Mazkur holat boʻyicha {rasmiylashtirilgan_hujjatlar} kabi hujjatlar rasmiylashtirilgan.

Shunday boʻlsada korxona tomonidan mening sogʻligʻimga yetkazilgan zararni toʻlash {tolamaslik_sababi} kabi sabablarga asosan kechiktirilib, ijro qilinmasdan kelinmoqda.

Oʻzbekiston Respublikasi Mehnat kodeksining 322-moddasiga koʻra, xodimning sogʻligʻiga yetkazilgan ziyonning oʻrnini ish beruvchi tomonidan qoplash quyidagilarni oʻz ichiga oladi: xodimga bir martalik nafaqa toʻlash, xodimga yoʻqotilgan ish haqi uchun yetkazilgan ziyonning oʻrnini qoplash tarzida amalga oshiriladigan har oylik toʻlovlar; xodimning qoʻshimcha xarajatlarini kompensatsiya qilish.

Shuningdek, mazkur kodeksning 323-moddasiga koʻra, xodimning sogʻligʻiga ziyon yetkazilganligi munosabati bilan ish beruvchi tomonidan bir yoʻla toʻlanadigan nafaqa miqdori jamoa shartnomasida, agar u tuzilmagan boʻlsa, ish beruvchi va kasaba uyushmasi qoʻmitasi oʻrtasidagi kelishuvga binoan belgilanadi. Bunda xodimning sogʻligʻiga ziyon yetkazilganligi munosabati bilan bir yoʻla toʻlanadigan nafaqa miqdori jabrlangan xodimning oʻrtacha oylik ish haqi asosida hisoblangan yillik ish haqidan kam boʻlmasligi kerak.

Mazkur kodeksning 324-moddasiga koʻra, xodimning sogʻligʻiga ziyon yetkazilganligi munosabati bilan yoʻqotilgan ish haqining oʻrnini qoplash uchun amalga oshiriladigan oylik toʻlovlar miqdori jabrlanuvchi mehnatda mayib boʻlguniga qadar olgan oʻrtacha oylik ish haqiga nisbatan uning kasbiy mehnat qobiliyatining yoʻqotilishi darajasiga muvofiq boʻlgan foizli nisbatda belgilanadi. Kasbiy mehnat qobiliyatini yoʻqotish darajasi tibbiy-ijtimoiy ekspert komissiyasi tomonidan belgilanadi.

Ziyonning oʻrnini qoplashga oid toʻlovni tayinlashda jabrlanuvchi oladigan ish haqi, stipendiya, pensiya va boshqa daromadlar hisobga olinmaydi. Bunda mehnatda mayib boʻlgan jabrlanganlarga — nogironligi boʻlgan shaxslarga yetkazilgan ziyonning oʻrnini qoplash summasi qonunchilikda belgilangan mehnatga haq toʻlash eng kam miqdorining ellik foizidan kam boʻlmasligi kerak.

Bugungi kungacha mening sogʻligʻimni tiklashga ketgan xarajatlar {zarar_summasi} soʻmni tashkil qiladi. Daʼvo talabimga {davo_asosi} kabi hujjatlarni asos sifatida keltiraman.

Yuqoridagilarni inobatga olib, Mehnat kodeksining 189-moddasiga asosan



                                                            SOʻRAYMAN:



Ishlab chiqarish jarayonida mehnatda shikastlanganligim uchun javobgardan mening foydamga {undiriladigan_summa} soʻm miqdorida yetkazilgan zararni undirish toʻgʻrisida hal qiluv qarori chiqarishingizni.

Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-004": {
        "nomi": "Toʻlanishi lozim boʻlgan pul mukofotlarini undirish haqida da'vo arizasi",
        "jpk": "Mehnat kodeksi 299-modda, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Toʻlanishi lozim boʻlgan pul mukofotlarini undirish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Daʼvogar ish boshlagan sana", "type": "date", "required": True},
            {"id": "lavozimi", "label": "Daʼvogarning lavozimi", "type": "text", "required": True},

            # INTIZOMIY JAZO
            {"id": "intizomiy_jazo_sanasi", "label": "Daʼvogarga nisbatan qoʻllanilgan intizomiy jazo sanasi",
             "type": "date", "required": True},

            # BAYRAM KUNLARI
            {"id": "bayram_kunlari_nomi", "label": "Daʼvogarga toʻlanmay qolgan bayram kunlari nomi", "type": "text",
             "required": True},

            # MUROJAAT
            {"id": "murojaat_sanasi", "label": "Daʼvogar Javobgarga alohida yozma ariza bilan murojaat qilgan sana",
             "type": "date", "required": True},

            # MA'NAVIY ZARAR
            {"id": "manaviy_zarar_miqdori", "label": "Daʼvogarga yetkazilgan maʼnaviy zarar miqdori", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                            (Toʻlanishi lozim boʻlgan pul mukofotlarini undirish haqida)



Men {davogar_fio} {ish_boshlagan_sana} kunidan {javobgar_nomi} (keyingi oʻrinlarda – javobgar)da {lavozimi} lavozimida ishlab kelyapman.

{intizomiy_jazo_sanasi} kuni ish beruvchining buyrugʻi bilan menga nisbatan intizomiy jazo chorasi qoʻllanilgan. Mazkur intizomiy jazo chorasini qoʻllashda ish beruvchi tomonidan bir qator qonunbuzarliklarga yoʻl qoʻyilganligi uchun men sudga murojaat qildim va natijada Fuqarolik ishlari boʻyicha sudning hal qiluv qarori bilan ish beruvchining yuqoridagi intizomiy jazo qoʻllash haqidagi buyrugʻi bekor qilindi.

Javobgar {intizomiy_jazo_sanasi} dagi menga nisbatan intizomiy jazo qoʻllash haqidagi buyruqdan keyin barcha xodimlarga {bayram_kunlari_nomi} kunlari munosabati bilan ushbu har bir bayram uchun mukofot pullari toʻlagan.

Oʻzbekiston Respublikasi Mehnat kodeksining 299-moddasiga asosan intizomiy jazo qoʻllangan va ushbu jazosi amalda boʻlgan xodimlarga bayram mukofotlari toʻlashga taqiq qoʻyilganligi uchun yuqoridagi bayram mukofotlari menga berilmagan.

Biroq, menga nisbatan {intizomiy_jazo_sanasi} da qoʻllanilgan intizomiy jazo chorasi qonunga xilof ravishda qoʻllanganligi sudda oʻz tasdigʻini topdi va ushbu jazo sud qarori bilan bekor qilindi. Shunday ekan, javobgar yuqorida koʻrsatilgan bayram kunlari munosabati bilan menga toʻlanmagan mukofot pullarini toʻliq ravishda toʻlab berishi lozim.

Men javobgarga {murojaat_sanasi} kuni alohida ariza kiritdim va intizomiy jazo qoʻllash haqidagi buyruq sud qarori bilan bekor qilinganligi sababli, bayram mukofot pullarini toʻlab berishni talab qildim. Lekin, ish beruvchi ushbu mukofot pullarini oʻz ixtiyori bilan toʻlab bermadi.

Javobgarning yuqoridagi gʻayriqonuniy xatti-harakatidan keyin men kuchli ruhiy tushkunlikka tushib, ruhiy azob chekdim va oʻzimni kamsitilgan, xoʻrlangan his qildim. Javobgar tomonidan menga maʼnaviy zarar yetkazilgan deb hisoblayman va uning miqdorini {manaviy_zarar_miqdori} soʻm sifatida baholayman.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



1. Javobgar {javobgar_nomi} dan mening foydamga {bayram_kunlari_nomi} bayrami munosabati bilan ushbu bayram kunlarining har biri uchun toʻlangan mukofot pullarini undirib berishingizni.

2. Javobgar {javobgar_nomi} dan mening foydamga yetkazilgan maʼnaviy zarar uchun {manaviy_zarar_miqdori} soʻm miqdoridagi pul mablagʻlarini undirib berishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },

"FQ-MN-005": {
        "nomi": "Foydalanilmagan mehnat taʼtillari uchun pullik kompensatsiya, kechiktirilgan kunlarga foizlar va maʼnaviy zarar uchun pul undirish toʻgʻrisida da'vo arizasi",
        "jpk": "Mehnat kodeksi 172, 216, 230, 234, 333-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Foydalanilmagan mehnat taʼtillari uchun pullik kompensatsiya, kechiktirilgan kunlarga foizlar va maʼnaviy zarar uchun pul undirish toʻgʻrisida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Daʼvogar Javobgar tashkilotda mehnat qilishni boshlagan sana",
             "type": "date", "required": True},

            # TA'TIL MA'LUMOTLARI
            {"id": "tatil_berilmagan_yillar", "label": "Xodimga yillik mehnat taʼtili berilmagan yillar miqdori",
             "type": "text", "required": True},
            {"id": "tatil_kunlari_miqdori", "label": "Xodimga berilishi lozim boʻlgan mehnat taʼtili kunlari miqdori",
             "type": "text", "required": True},

            # ISHDAN BO'SHASH
            {"id": "ishdan_boshas_sababi", "label": "Xodimning ishdan boʻshash sababi", "type": "text",
             "required": True},
            {"id": "ishdan_boshas_sana", "label": "Xodim bilan mehnat shartnomasi bekor qilingan sana", "type": "date",
             "required": True},

            # MUROJAAT
            {"id": "murojaat_sanasi", "label": "Xodim javobgarga yozma ariza bilan murojaat qilgan sana",
             "type": "date", "required": True},

            # MA'NAVIY ZARAR
            {"id": "manaviy_zarar_miqdori", "label": "Xodim o‘ziga yetkazilgan ma’naviy zararni hisoblagan miqdor",
             "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                   (Foydalanilmagan mehnat taʼtillari uchun pullik kompensatsiya, kechiktirilgan kunlarga 
                              foizlar va maʼnaviy zarar uchun pul undirish toʻgʻrisida)



Men {davogar_fio} {ish_boshlagan_sana} kunidan {javobgar_nomi} (keyingi oʻrinlarda – javobgar)da turli lavozimlarda mehnat qilib kelganman.

Men {ishdan_boshas_sababi} sababli ishdan boʻshashga ariza yozdim va {ishdan_boshas_sana} kuni men bilan tuzilgan mehnat shartnomasi oʻz tashabbusimga koʻra bekor qilindi.

Biroq, mehnat shartnomasi bekor qilingandan keyingi hisob-kitob davrida menga foydalanilmagan mehnat taʼtilimning faqat bir yili uchun pullik kompensatsiya toʻlovlari toʻlandi xolos.

Vaholanki, undan tashqari menga jami {tatil_berilmagan_yillar} yillik ish yillarim uchun ham har yilgi mehnat taʼtillari berilmagan.

Oʻzbekiston Respublikasi Mehnat kodeksining 172-moddasiga koʻra xodim bilan tuzilgan mehnat shartnomasi bekor qilinganda xodim bilan hisob-kitob qilinishi kerak va bunda ish beruvchi xodim tomonidan foydalanilmagan barcha asosiy va qoʻshimcha taʼtillar uchun kompensatsiyalarni toʻlab berishi lozim.

Ushbu Kodeksning 216-moddasiga muvofiq “har yilgi mehnat taʼtili dam olish va ishlash qobiliyatini tiklash uchun ish oʻrni (lavozimi) hamda oʻrtacha ish haqi saqlab qolingan holda xodim ishdan ozod etiladigan, xodimga har yili ish yili davomida beriladigan vaqt davridir”.

Kodeksning 230-moddasi birinchi qismida “har yilgi mehnat taʼtili har yili, ushbu taʼtil berilayotgan ish yili tugaguniga qadar berilishi kerak” deyilgan.

Shuningdek, Kodeksning 234-moddasi birinchi qismiga asosan mehnat shartnomasi bekor qilinganda xodimga barcha foydalanilmagan har yilgi asosiy va qoʻshimcha mehnat taʼtillari uchun kompensatsiya toʻlanadi.

Yuqorida keltirib oʻtilgan qoidalarga koʻra, men bilan mehnat shartnomasi bekor qilingandan keyin, javobgar menga barcha foydalanilmagan mehnat taʼtillarim uchun kompensatsiya toʻlovlarini toʻlab berishi shart edi.

Taraflar oʻrtasida tuzilgan mehnat shartnomasining 5-bandiga asosan javobgar tomonidan {tatil_berilmagan_yillar} yillik ish yilining har bir yili uchun {tatil_kunlari_miqdori} kunidan iborat mehnat taʼtillari berilmagan.

Men javobgarga {murojaat_sanasi} kuni yozma ariza bilan murojaat qilib, yuqoridagi {tatil_berilmagan_yillar} yillik davrdagi foydalanilmagan mehnat taʼtillarim uchun kompensatsiya toʻlovlarini ixtiyoriy ravishda toʻlashni talab qildim. Lekin javobgar shu vaqtga qadar ushbu toʻlovlarni oʻz ixtiyori bilan toʻlamadi.

Mehnat kodeksining 333-moddasiga asosan ish beruvchi ish haqini, taʼtil toʻlovlarini, mehnat shartnomasi bekor qilingandagi toʻlovlarni va (yoki) xodimga toʻlanishi lozim boʻlgan boshqa toʻlovlarni toʻlash muddatini buzgan taqdirda, ularni toʻlov muddatidan keyingi kundan eʼtiboran to haqiqatda hisob-kitob qilingan kunni oʻz ichiga olgan muddatgacha har bir kechiktirilgan kun uchun Oʻzbekiston Respublikasi Markaziy bankining oʻsha vaqtda amalda boʻlgan qayta moliyalashtirish stavkasidan kelib chiqqan holda foizlar (kompensatsiya) bilan birga toʻlashi shart. Xodimga toʻlanishi lozim boʻlgan kompensatsiyaning miqdori Oʻzbekiston Respublikasi Markaziy banki qayta moliyalash stavkasining oʻn foizi miqdorida belgilanadi.

Mazkur qoidaga binoan javobgar menga {tatil_berilmagan_yillar} yillik davrdagi foydalanilmagan mehnat taʼtilim uchun oʻz vaqtida toʻlanmagan kompensatsiya toʻlovlari boʻyicha kechiktirilgan har bir kunga ham foizlar toʻlashi lozim.

Bundan tashqari, javobgarning yuqoridagi harakatsizligi va qonunlarni mensimasligi natijasida men jiddiy ruhiy azob chekdim va oʻzimni kamsitilgan, xoʻrlangan his qildim. Shunga koʻra men javobgar tomonidan menga maʼnaviy zarar yetkazilgan deb hisoblayman va uning miqdorini {manaviy_zarar_miqdori} soʻm sifatida baholayman.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



1. Javobgar {javobgar_nomi} dan mening foydamga {tatil_berilmagan_yillar} yillik ish yili mobaynida foydalanilmagan mehnat taʼtillari uchun kompensatsiya undirib berishingizni.

2. Javobgar {javobgar_nomi} dan ushbu kompensatsiya toʻlovlari kechiktirilganligi uchun {ishdan_boshas_sana} dan shu kunga qadar har bir kun uchun Mehnat kodeksining 333-moddasiga asosan foizlar undirib berishingizni.

3. Javobgar {javobgar_nomi} dan yetkazilgan maʼnaviy zarar uchun {manaviy_zarar_miqdori} soʻm miqdoridagi pul mablagʻlarini undirib berishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-006": {
        "nomi": "Mehnat shartnomasini bekor qilish asosi va taʼrifini oʻzgartirish haqida da'vo arizasi",
        "jpk": "Mehnat kodeksi 161, 568-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mehnat shartnomasini bekor qilish asosi va taʼrifini oʻzgartirish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar ma'lumotlari va ish raqami bo'lsin.
4. "ARIZA" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari boʻyicha sudning nomi", "type": "text", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning manzili", "type": "text", "required": True},

            # ISH RAQAMI
            {"id": "ish_raqami", "label": "Hal qiluv qarori raqami", "type": "text", "required": True},

            # ARIZA SANASI
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # BUYRUQ SANALARI
            {"id": "ishdan_boshatish_buyrugi_sanasi",
             "label": "Javobgar tomonidan Daʼvogarni ishdan bo‘shatish to‘g‘risidagi buyrug‘i sanasi", "type": "date",
             "required": True},
            {"id": "hayfsan_sanasi", "label": "Javobgar tomonidan Daʼvogarga hayfsan qo‘llanilgan sana", "type": "date",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}



                                                            {ish_raqami}-sonli ish yuzasidan



                                                            ARIZA

                                            (Mehnat shartnomasini bekor qilish asosi va 
                                                  taʼrifini oʻzgartirish haqida)



Daʼvogar {davogar_fio} oʻz daʼvo arizasida javobgarning {ishdan_boshatish_buyrugi_sanasi} dagi buyrugʻini bekor qilishni, uni avvalgi lavozimiga tiklashni hamda moddiy va maʼnaviy zarar summalarini undirib berishni soʻragan.

Javobgarning mehnat shartnomasini bekor qilish haqidagi buyrugʻida xodim bilan tuzilgan mehnat shartnomasini ish beruvchi tashabbusiga koʻra – Oʻzbekiston Respublikasi Mehnat kodeksining 161-moddasi ikkinchi qismi 4-bandiga asosan, mehnat majburiyatlarini muntazam ravishda buzganligi munosabati bilan bekor qilinganligi koʻrsatilgan.

Sud jarayonida bu buyruqdan oldingi, yaʼni {hayfsan_sanasi} dagi buyruq bilan daʼvogarga hayfsan intizomiy jazo chorasini qoʻllash belgilangan boʻlib, biroq, ushbu buyruqqa ish beruvchi emas, balki direktor oʻrinbosari imzo qoʻyganligi maʼlum boʻldi. Bizningcha, agar ushbu hayfsan qoʻllash haqidagi buyruq ish beruvchi tomonidan imzolanmagan boʻlsa, sud bu buyruqni qonunga xilof deb topishi va majburiyatlarni muntazam ravishda buzish fakti boʻlmaganligini hisobga olib, xodimni ishga tiklash haqida qaror chiqarishi mumkin.

Bizningcha, xodim bilan tuzilgan mehnat shartnomasini bekor qilish haqidagi buyruqda mehnat shartnomasini bekor qilish asosi va taʼrifi "Oʻzbekiston Respublikasi Mehnat kodeksining 161-moddasi ikkinchi qismi 4-bandiga asosan, mehnat majburiyatlarini muntazam ravishda buzganligi munosabati bilan" deb xato yozilgan boʻlib chiqmoqda.

Biroq, Mehnat kodeksining 568-moddasiga asosan mehnat shartnomasini bekor qilish asoslarining taʼrifi notoʻgʻri deb yoki qonunchilikka muvofiq emas deb topilgan taqdirda, sud ushbu taʼrifni oʻzgartiradi va qarorda mehnat shartnomasini bekor qilish asosini qonunchilikka qatʼiy muvofiq ravishda qonunning tegishli moddasiga (qismiga, bandiga, xatboshiga) havola qilgan holda koʻrsatadi.

Shuningdek, Oliy sud Plenumining 2023-yil 20-noyabrdagi "Sudlar tomonidan mehnat shartnomasini bekor qilishni tartibga soluvchi qonunchilikni qoʻllash amaliyoti toʻgʻrisida"gi 26-sonli qarori 65-bandida agar sud ishga tiklash haqidagi nizoni hal qilishda ish beruvchining mehnat munosabatlarini bekor qilishga asosi boʻlgan deb topsa, ammo mehnat shartnomasini bekor qilish taʼrifi notoʻgʻri yoki amaldagi qonunga mos boʻlmasa, sud taʼrifni oʻzgartiradi va hal qiluv qarorida mehnat shartnomasini bekor qilish sababini qonunga aniq mos holda, qonunning tegishli moddasi (bandi)ga tayangan holda koʻrsatadi deyilgan.

Xodimning yuqoridagi intizomiy qilmishi bir vaqtning oʻzida u bilan tuzilgan mehnat shartnomasini Mehnat kodeksining 161-moddasi ikkinchi qismi 5-bandiga asosan, mehnat majburiyatlarini bir marta qoʻpol ravishda buzganligi munosabati bilan bekor qilishga ham asos boʻla oladi. Mazkur Ichki mehnat tartibi qoidalari avvaldan xodimga tanishtirilgan, ushbu intizomiy qilmish yuzasidan barcha hujjatlar toʻliq rasmiylashtirilgan hamda kasaba uyushmasi qoʻmitasi roziligi ham olingan.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



{ishdan_boshatish_buyrugi_sanasi} dagi "mehnat shartnomasini bekor qilish haqida"gi buyruqning mehnat shartnomasini bekor qilish asosi va taʼrifini "Oʻzbekiston Respublikasi Mehnat kodeksining 161-moddasi ikkinchi qismi 5-bandiga asosan, mehnat majburiyatlarini bir marta qoʻpol ravishda buzganligi munosabati bilan"ga oʻzgartirilsin.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-007": {
        "nomi": "Mehnat daftarchasini vaqtida bermagaligi uchun ushbu davrga o'rtacha ish haqi undirish to'g'risida da'vo arizasi",
        "jpk": "Mehnat kodeksi 171, 319, 320-moddalar, Mehnat daftarchalarni yuritish tartibi toʻgʻrisidagi Yoʻriqnoma 3.1-band, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Mehnat daftarchasini vaqtida bermagaligi uchun ushbu davrga o'rtacha ish haqi undirish to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Daʼvogar Javobgarning tashkilotida ish boshlagan sana", "type": "date",
             "required": True},
            {"id": "ish_tugatgan_sana", "label": "Daʼvogar Javobgarning tashkilotida ishni tugatgan sana", "type": "date",
             "required": True},
            {"id": "lavozimi", "label": "Daʼvogarning ishlagan lavozimi", "type": "text", "required": True},

            # ISHDAN BO'SHASH
            {"id": "ariza_yozilgan_sana", "label": "Daʼvogarning ishdan bo‘shash to‘g‘risida yozgan arizasining sanasi",
             "type": "date", "required": True},
            {"id": "ishdan_boshatilgan_sana", "label": "Daʼvogar Javobgarning buyrug‘i bilan ishdan bo‘shatilgan sana",
             "type": "date", "required": True},
            {"id": "buyruq_raqami", "label": "Daʼvogar ishdan bo‘shatilgan buyruq raqami", "type": "text",
             "required": True},

            # ISH HAQI
            {"id": "ortacha_ish_haqi", "label": "Daʼvogar tomonidan hisoblangan o‘rtacha ish haqi miqdori",
             "type": "text", "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                    (Mehnat daftarchasi kechiktirilgan davr uchun 
                                             ish haqi undirish haqida)



Men {davogar_fio} {ish_boshlagan_sana} dan {ish_tugatgan_sana} ga qadar {javobgar_nomi} (keyingi oʻrinlarda – Javobgar)da {lavozimi} lavozimida ishlab kelganman.

{ariza_yozilgan_sana} kuni oʻz xohishimga koʻra ishdan boʻshash haqida ariza yozdim va {ishdan_boshatilgan_sana} kungi {buyruq_raqami}-sonli buyruq bilan oʻz tashabbusimga koʻra ishdan boʻshaganman va men bilan tuzilgan mehnat shartnomasi bekor qilingan.

Biroq, Javobgar tomoni hozirgi kunga qadar menga mehnat daftarchamni hech qanday sabablarsiz, asossiz ravishda bermasdan kelmoqda.

Men Javobgarning HR boʻyicha menejeriga bir necha bor ogʻzaki ravishda murojaat qildim. Lekin, hali-hanuz Javobgar mehnat daftarchamni bermasdan kelmoqda. Natijada, shu kunga qadar biron-bir ishga rasman mehnat shartnomasi tuzib joylasha olmadim va hech qanday ish haqiga ham, mehnat stajiga ham ega boʻla olmadim.

Oʻzbekiston Respublikasi Mehnat kodeksining 171-moddasiga binoan ish beruvchi mehnat shartnomasi bekor qilingan kuni xodimga uning mehnat daftarchasini yoxud elektron mehnat daftarchasidan koʻchirmani, shuningdek mehnat shartnomasini bekor qilish toʻgʻrisidagi buyruqning koʻchirma nusxasini berishi shart.

Ushbu kodeksining 320-moddasiga koʻra, xodimga mehnat daftarchasi yoxud elektron mehnat daftarchasi koʻchirmasi berilishi ish beruvchi tomonidan kechiktirilganligi natijasida yetkazilgan zarar ish beruvchi tomonidan qoplanishi koʻrsatilgan.

Adliya vazirligi tomonidan 1998-yil 29-yanvarda 402-son bilan davlat roʻyxatidan oʻtkazilgan "Mehnat daftarchalarni yuritish tartibi toʻgʻrisida"gi Yoʻriqnomaning 3.1-bandida "ish beruvchi aybi bilan mehnat daftarchasini berish kechiktirilsa, u holda butun kechiktirilgan davr uchun xodimga oʻrtacha oylik ish haqi toʻlanadi" deyilgan.

Javobgar mehnat daftarchamni berishni {ishdan_boshatilgan_sana} dan hozirga qadar jami kechiktirgan va bu davrga hisoblangan oʻrtacha oylik ish haqim {ortacha_ish_haqi} soʻmni tashkil qiladi.

Bundan tashqari, Mehnat kodeksining 319-moddasida agar ish beruvchining qonunga xilof harakatlari (harakatsizligi) bilan xodimga jismoniy yoki maʼnaviy zarar yetkazilgan boʻlsa, xodimga yetkazilgan maʼnaviy ziyon kompensatsiya qilinishi lozimligi belgilab qo‘yilgan.

402-son Yoʻriqnoma 3.1-bandining davomida yana mana bunday qoida bor: Bunday holda ishdan boʻshash kuni, mehnat daftarchasi berilgan kun hisoblanadi. Ishdan boʻshagan kunining yangi sanasi toʻgʻrisida buyruq berilib, xodimning mehnat daftarchasiga yozib qoʻyiladi. Boʻshagan kuni toʻgʻrisida ilgari kiritilgan yozuv, ushbu Yoʻriqnomaning 2.8-bandida belgilangan tartibda bekor qilinadi.

Shunga koʻra, mening ishdan boʻshagan kunim ham amalda menga mehnat daftarcham beriladigan kun bilan muvofiqlashtirilishi va sud tomonidan Javobgarga mehnat daftarchamdagi avval {ishdan_boshatilgan_sana} da boʻshaganligim haqidagi yozuvni bekor qilib, ishdan boʻshagan kunning yangi sanasini belgilash boʻyicha majburiyat ham yuklatilishi kerak deb hisoblayman.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



1. Javobgar {javobgar_nomi} dan mening foydamga mehnat daftarchamni berish kechiktirilganligi uchun {ortacha_ish_haqi} soʻm ish haqi undirib berishingizni.

2. Javobgar {javobgar_nomi} ga mehnat daftarchamdagi avval {ishdan_boshatilgan_sana} da boʻshaganligim haqidagi yozuvni bekor qilib, mehnat daftarchasida ishdan boʻshagan kunning yangi sanasini belgilash majburiyatini yuklatishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },

"FQ-MN-008": {
        "nomi": "Xizmat tekshiruvi komissiyasining harakatlarini gʻayriqonuniy deb topish hamda xodimni avvalgi lavozimiga tiklash to'g'risida da'vo arizasi",
        "jpk": "Mehnat kodeksi 6, 302-311, 306-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Xizmat tekshiruvi komissiyasining harakatlarini gʻayriqonuniy deb topish hamda xodimni avvalgi lavozimiga tiklash to'g'risida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʻvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʻvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʻvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʻvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʻvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʻvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT SHARTNOMASI
            {"id": "shartnoma_bekor_qilingan_sana", "label": "Da’vogar bilan tuzilgan mehnat shartnomasi bekor qilingan sana",
             "type": "date", "required": True},
            {"id": "buyruq_raqami", "label": "Da’vogar bilan tuzilgan mehnat shartnomasini bekor qilish to‘g‘risidagi buyruq raqami",
             "type": "text", "required": True},

            # XIZMAT TEKSHIRUVI
            {"id": "dalolatnoma_sanasi", "label": "Xizmat tekshiruvi komissiyasi tomonidan tuzilgan dalolatnoma sanasi",
             "type": "date", "required": True},
            {"id": "tekshiruv_buyruq_raqami", "label": "Xizmat tekshiruvi o‘tkazish bo‘yicha buyruq soni", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʻvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                      (Xizmat tekshiruvi komissiyasining harakatlarini gʻayriqonuniy deb topish 
                              hamda xodimni avvalgi lavozimiga tiklash to‘g‘risida)



Daʼvogar {davogar_fio} bilan tuzilgan mehnat shartnomasi javobgar {javobgar_nomi} tomonidan {shartnoma_bekor_qilingan_sana} kungi {buyruq_raqami}-sonli buyrugʻi bilan bekor qilingan.

Mehnat shartnomasi bekor qilinishiga Xizmat tekshiruvi komissiyasining {dalolatnoma_sanasi} sanasidagi dalolatnoma asos sifatida olingan.

Daʼvogarga nisbatan oʻtkazilgan xizmat tekshiruv jarayonini Mehnat kodeksining 302–311-moddalariga qay darajada mos ekanligi oʻrganib chiqildi. Oʻrganish davomida quyidagi qonunbuzarliklar aniqlandi:

Birinchidan, Mehnat kodeksining 303-moddasida "xizmat tekshiruvi oʻtkazish uchun ish beruvchining buyrugʻi bilan xizmat tekshiruvi oʻtkazish boʻyicha komissiya tuziladi (bundan buyon matnda komissiya deb yuritiladi). Komissiya kamida uch nafar aʼzodan iborat boʻlishi kerak, ularning bir nafari komissiyaning raisi boʻladi. Komissiya tarkibiga tashkilotda mavjud boʻlgan taqdirda kasaba uyushmasi qoʻmitasining aʼzosi kiradi" deyilgan.

Mehnat kodeksining 6-moddasida "ish beruvchi tomonidan boshlangʻich kasaba uyushmasi tashkilotining saylab qoʻyiladigan organi (kasaba uyushmasi qoʻmitasi, kasaba uyushmasining tashkilotchisi yoki kasaba uyushmasi guruhining tashkilotchisi) yoki xodimlarning boshqa vakillik organi (bundan buyon matnda kasaba uyushmasi qoʻmitasi deb yuritiladi) bilan kelishgan holda qanday ichki hujjatlar qabul qilinishi mumkinligini belgilaydi" deyilgan. Mazkur qoidaga koʻra kasaba uyushmasi tashkilotining saylab qoʻyiladigan organlari ham, xodimlarning boshqa vakillik organi ham Kodeksning keyingi moddalarida bitta jumla bilan – "kasaba uyushmasi qoʻmitasi" degan jumla bilan ifodalanishi nazarda tutilmoqda. Yaʼni, kasaba uyushmasi qoʻmitasi deganda, tashkilotning xodimlari tomonidan saylangan xodimlar vakili ham tushuniladi.

Biroq, javobgarda xodimlarning vakili mavjud boʻlsada, jamiyat rahbari tomonidan tuzilgan xizmat tekshiruvi komissiyasi tarkibiga tashkilot xodimlarining vakillik organiga saylangan shaxs kiritilmagan.

Ikkinchidan. Mehnat kodeksining 310-moddasi birinchi qismiga koʻra "xizmat tekshiruvi natijalari toʻgʻrisidagi dalolatnoma tegishli qarorni qabul qilish uchun ovoz bergan komissiya aʼzolari tomonidan imzolanishi kerak" deyilgan.

Shuningdek, MK 310-moddasining oxirgi qismida "xizmat tekshiruvi natijalari toʻgʻrisidagi dalolatnoma komissiya toʻplagan boshqa materiallar bilan birga ish beruvchiga komissiya majlisida oʻtkazilgan xizmat tekshiruvi haqida qaror qabul qilinganidan keyin uch ish kunidan kechiktirmay topshirilishi kerak" deyilgan.

Uchinchidan. Mehnat kodeksining 305-moddasida xizmat tekshiruvi oʻtkazish boʻyicha komissiya oʻziga nisbatan xizmat tekshiruvi oʻtkazilayotgan xodimlarga yozma shaklda tushuntirishlar taqdim etishni, shuningdek xizmat tekshiruvi masalalarining mohiyati yuzasidan boshqa axborotni maʼlum qilishni taklif etish huquqiga ega ekanligi koʻrsatilgan.

Mazkur qoidaga asosan komissiya xodimdan xizmat tekshiruvi oʻtkazish chogʻida tushuntirish xati soʻrashi mumkin.

Yuqoridagilardan koʻrinib turibdiki, komissiya tomonidan oʻtkazilgan xizmat tekshiruvi jarayoni gʻayriqonuniy boʻlgan.

Mehnat kodeksining 306-moddasiga asosan ustidan xizmat tekshiruvi oʻtkazilayotgan xodim komissiyaning qarorlari va harakatlari (harakatsizligi) ustidan yakka tartibdagi mehnat nizolari uchun belgilangan tartibda shikoyat qilishga haqlidir.

Qayd etilganlarga koʻra, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



1. Ish beruvchining {tekshiruv_buyruq_raqami}-sonli buyrugʻi bilan tuzilgan xizmat tekshiruvi oʻtkazish boʻyicha komissiyaning daʼvogar {davogar_fio} ning faoliyati boʻyicha oʻtkazilgan xizmat tekshiruviga oid harakatlarini gʻayriqonuniy deb topishingizni.

2. Javobgar {javobgar_nomi} ni daʼvogar {davogar_fio} ni avvalgi lavozimiga tiklashga majbur qilishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-013": {
        "nomi": "Dam olish kunlari ishlagan ish haqi toʻlovlarini hamda yetkazilgan maʼnaviy zararni undirish haqida da'vo arizasi",
        "jpk": "Mehnat kodeksi 200, 209, 263-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Dam olish kunlari ishlagan ish haqi toʻlovlarini hamda yetkazilgan maʼnaviy zararni undirish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Daʼvogar ish boshlagan sana", "type": "date", "required": True},
            {"id": "lavozimi", "label": "Daʼvogarning lavozimi", "type": "text", "required": True},

            # G'AYRIQONUNIY ISHLATISH
            {"id": "gayriqonuniy_boshlangan_sana", "label": "Daʼvogar g‘ayriqonuniy ravishda ishlatib kelinayotgan sana",
             "type": "date", "required": True},
            {"id": "ishlatilgan_kunlar", "label": "Daʼvogar g‘ayriqonuniy ishlatilgan umumiy kunlar miqdori",
             "type": "text", "required": True},

            # MA'NAVIY ZARAR
            {"id": "manaviy_zarar_miqdori", "label": "Daʼvogarga yetkazilgan maʼnaviy zarar miqdori", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                    (Dam olish kunlari ishlagan ish haqi toʻlovlarini 
                                       hamda yetkazilgan maʼnaviy zararni undirish haqida)



Men {davogar_fio} {ish_boshlagan_sana} kunidan {javobgar_nomi} (keyingi oʻrinlarda – javobgar)da {lavozimi} lavozimida ishlab kelyapman.

Oʻzbekiston Respublikasi Mehnat kodeksining 209-moddasiga asosan "dam olish kunlarida va ishlanmaydigan bayram kunlarida ishlash taqiqlanadi, bundan ushbu Kodeksda nazarda tutilgan hollar mustasno. Umuman tashkilotning yoki uning alohida tarkibiy boʻlinmalarining, yakka tartibdagi tadbirkorning keyinchalik normal ishlashi oldindan kutilmagan qaysi ishlarning shoshilinch bajarilishiga bogʻliq boʻlsa, oʻsha ishlarni bajarish zarur boʻlgan taqdirda xodimlarni dam olish kunlari va ishlanmaydigan bayram kunlari ishga jalb etish ularning yozma roziligi bilan amalga oshiriladi" deyilgan.

Biroq, javobgar meni {gayriqonuniy_boshlangan_sana} oyidan beri gʻayriqonuniy ravishda dam olish kunlari ishga jalb qilib, majburiy ravishda ishlatib kelgan. Umumiy hisobda {ishlatilgan_kunlar} kun ishga jalb qilinganman hamda ushbu dam olish kunlari toʻliq ishlaganman. Shunga qaramasdan, javobgar ushbu dam olish kunlari ishlagan davrlarimning birortasini ish vaqti va ish haqi hisoblash tabellariga kiritmagan. Vaholanki, Mehnat kodeksining 200-moddasida "ish beruvchi xodimlarning ishga kelishi va ishdan ketishi hisobga olinishini tashkil etishi shart" deyilgan.

Bundan tashqari, javobgar yuqoridagi dam olish kunlarida ishlaganim uchun shu vaqtga qadar menga hech qanday ish haqi toʻlamagan. Vaholanki, Mehnat kodeksining 263-moddasida dam olish kunlaridagi yoki ishlanmaydigan bayram kunlaridagi ish uchun xodimlarga kamida ikki hissa miqdorida haq toʻlanishi koʻrsatilgan. Maʼlumot sifatida oylik maoshim haqida shtatlar jadvalidan koʻchirma taqdim etyapman.

Men javobgarning yuqoridagi gʻayriqonuniy xatti-harakatlari, jumladan, menga bosim va tazyiq oʻtkazib xohishimga qarshi ravishda dam olish kunlari ishlatgani, qolaversa, ishimga yarasha ish haqi toʻlanmaganligi natijasida men kuchli ruhiy tushkunlikka tushib, ruhiy azob chekdim va oʻzimni kamsitilgan, xoʻrlangan his qildim. Men javobgar tomonidan menga maʼnaviy zarar yetkazilgan deb hisoblayman va uning miqdorini {manaviy_zarar_miqdori} soʻm sifatida baholayman.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



Javobgar {javobgar_nomi} dan mening foydamga {gayriqonuniy_boshlangan_sana} dan hozirga qadar dam olish kunlari ishlagan vaqtlarim uchun Oʻzbekiston Respublikasi Mehnat kodeksi 263-moddasiga asosan kamida ikki hissalik miqdorda ish haqi toʻlovlarini hamda menga yetkazilgan maʼnaviy zarar uchun {manaviy_zarar_miqdori} soʻm pul mablagʻlarini undirib berishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-009": {
        "nomi": "Ish yuritishni tugatish haqida ariza (Mehnatga oid nizolar boʻyicha)",
        "jpk": "Fuqarolik protsessual kodeksi 407, 4079-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish yuritishni tugatish haqida ariza (Mehnatga oid nizolar boʻyicha)" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar ma'lumotlari va ish raqami bo'lsin.
4. "ARIZA" sarlavhasi markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Fuqarolik ishlari bo‘yicha sudning nomi", "type": "text", "required": True},
            {"id": "hal_qiluv_sud_nomi", "label": "Hal qiluv qarori chiqargan sudning nomi", "type": "text",
             "required": True},
            {"id": "hal_qiluv_sana", "label": "Hal qiluv qarori chiqarilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning manzili", "type": "text", "required": True},

            # ISH RAQAMI
            {"id": "ish_raqami", "label": "Hal qiluv qarori raqami", "type": "text", "required": True},

            # ARIZA SANASI
            {"id": "ariza_sana", "label": "Ariza berilgan sana", "type": "date", "required": True},

            # JAVOBGAR
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "tiklanadigan_lavozim", "label": "Daʼvogar tiklanishi nazarda tutilgan lavozim", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}



                                                            {ish_raqami}-sonli ish yuzasidan



                                                            ARIZA

                                                  (Ish yuritishni tugatish haqida)



Fuqarolik ishlari boʻyicha {hal_qiluv_sud_nomi} sudining {hal_qiluv_sana} dagi hal qiluv qaroriga asosan meni {javobgar_nomi} ning {tiklanadigan_lavozim} lavozimiga ishga tiklanishim belgilangan.

Biroq, javobgar tomonidan meni sud qarorida koʻrsatilgan lavozimiga emas, balki boshqa lavozimga tiklash haqida buyruq chiqarilgan.

Yuqoridagilardan koʻrinadiki, javobgar sudning hal qiluv qarorini va ijro varaqasini ijro qilmagan. Shunga koʻra, javobgar kassatsiya shikoyati berishdan avval sudning ishga tiklash haqidagi hal qiluv qarori ijrosini taʼminlamagan.

Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 407-moddasida "xodim bilan tuzilgan mehnat shartnomasi gʻayriqonuniy ravishda bekor qilinganda yoki xodim bir ishdan boshqa ishga gʻayriqonuniy ravishda oʻtkazilganida uni ilgarigi ishiga tiklash toʻgʻrisidagi sudning hal qiluv qarori ustidan kassatsiya shikoyati (protesti) ushbu qarorning ijrosiga doir hujjat ilova qilingan taqdirdagina qabul qilinadi" deyilgan.

Demak, javobgarning kassatsiya shikoyati sud tomonidan xatolik bilan ish yurituvga qabul qilingan.

FPKning 4079-moddasi birinchi qismi 1-bandiga asosan kassatsiya shikoyati (protesti) apellyatsiya tartibida koʻrilmagan yoki ushbu Kodeksga muvofiq kassatsiya tartibida shikoyat qilinmaydigan (protest keltirilmaydigan) sud hujjati ustidan berilgan va u ish yuritishga xatoga yoʻl qoʻyilib qabul qilingan boʻlsa kassatsiya shikoyati boʻyicha ish yuritish tugallanishi kerak.

Yuqoridagilarga asoslanib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 4079-moddasiga asosan,



                                                            SOʻRAYMAN:



{ish_raqami}-sonli ish yuzasidan kiritilgan kassatsiya shikoyati boʻyicha ish yurituvga qabul qilingan fuqarolik ishi yuritishni tugatishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-010": {
        "nomi": "Ish haqi va unga tenglashtirilgan toʻlovlarni undirish haqida da'vo arizasi",
        "jpk": "Mehnat kodeksi 172, 319-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish haqi va unga tenglashtirilgan toʻlovlarni undirish haqida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Daʼvogar Javobgarning tashkilotida ish boshlagan sana", "type": "date",
             "required": True},
            {"id": "ish_tugatgan_sana", "label": "Daʼvogar Javobgarning tashkilotida ishni tugatgan sana", "type": "date",
             "required": True},
            {"id": "lavozimi", "label": "Daʼvogarning ishlagan lavozimi", "type": "text", "required": True},

            # ISHDAN BO'SHASH
            {"id": "buyruq_raqami", "label": "Daʼvogarning ishdan bo‘shatilgan buyruq raqami", "type": "text",
             "required": True},

            # XODIMLAR
            {"id": "buxgalter_fio", "label": "Javobgarning hisob-kitob bo‘yicha buxgalteri F.I.O.", "type": "text",
             "required": True},
            {"id": "hr_fio", "label": "Javobgarning HR bo‘yicha mas’ul xodimi F.I.O.", "type": "text", "required": True},

            # MUROJAAT
            {"id": "murojaat_sanasi", "label": "Daʼvogar tomonidan Javobgarga yozma murojaat qilingan sana",
             "type": "date", "required": True},

            # HISOB-KITOB
            {"id": "foydalanilmagan_yillar", "label": "Daʼvogarning mehnat ta’tilidan foydalanmagan yillari",
             "type": "text", "required": True},
            {"id": "ish_haqi_summasi", "label": "Daʼvogarga to‘lanishi lozim bo‘lgan ish haqi summasi miqdori",
             "type": "text", "required": True},

            # MA'NAVIY ZARAR
            {"id": "manaviy_zarar_miqdori", "label": "Daʼvogar talab qilayotgan ma’naviy zarar miqdori", "type": "text",
             "required": True},

            # JAMI
            {"id": "jami_summa", "label": "Daʼvogarga to‘lanishi lozim bo‘lgan jami summa miqdori", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʻvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                      (Ish haqi va unga tenglashtirilgan toʻlovlarni undirish haqida)



Men {davogar_fio} {ish_boshlagan_sana} dan {ish_tugatgan_sana} ga qadar {javobgar_nomi} (keyingi oʻrinlarda – Javobgar)da {lavozimi} lavozimida ishlab kelganman.

Ish boshlaganimdan beri, oʻzimga yuklatilgan vazifa va topshiriqlarni sidqidildan bajarib, yaxshi natijalarga erishib kelganman. Oʻtgan faoliyatim davrida biror marta ham intizomiy jazoga tortilmaganman. Aksincha, shaxsiy koʻrsatkichlarim tufayli rahbariyat tomonidan ragʻbatlantirilganman.

Boshqa ishga o‘tganligim sababli ishxonamga oʻz xohishimga koʻra ariza yozib, {ish_tugatgan_sana} kungi {buyruq_raqami}-sonli buyruq bilan oʻz tashabbusimga koʻra ishdan boʻshaganman va men bilan tuzilgan mehnat shartnomasi bekor qilingan.

Biroq, Javobgar tomonidan hozirgi kunga qadar mehnat shartnomam bekor qilinganligi munosabati bilan toʻlanishi lozim boʻlgan hisob-kitob summalari hech qanday sabablarsiz, asossiz ravishda toʻlanmasdan kelinmoqda.

Men Javobgarning hisob-kitob boʻyicha buxgalteri {buxgalter_fio} ga va HR xodimi {hr_fio} ga bu haqida bir necha bor ogʻzaki ravishda murojaat qildim. Natija boʻlmagach, {murojaat_sanasi} da rasman yozma ravishda murojaat qildim.

Lekin, hali-hanuz ish beruvchi hisob-kitob summalarini toʻlab bergani ham, murojaatlarimga rasman javob qaytargani ham yoʻq.

Oʻzbekiston Respublikasi Mehnat kodeksining 172-moddasiga koʻra mehnat shartnomasi bekor qilinganda xodim bilan hisob-kitob qilinishi kerak. Hisob-kitob xodimga: oxirigacha olinmagan ish haqini; xodim tomonidan foydalanilmagan barcha asosiy va qoʻshimcha taʼtillar uchun kompensatsiyalarni; agar mehnat toʻgʻrisidagi qonunchilikda yoki mehnat haqidagi boshqa huquqiy hujjatlarda yoxud mehnat shartnomasida boshqa toʻlovlarni toʻlash nazarda tutilgan boʻlsa, ushbu toʻlovlarni toʻlashni oʻz ichiga oladi.

Javobgar menga {ish_tugatgan_sana} sanasigacha boʻlgan mehnatim uchun ish haqi, {foydalanilmagan_yillar} yillardagi ish davrimning foydalanilmagan mehnat taʼtilim uchun kompensatsiya toʻlovlarini toʻlamagan. Mendagi hisob-kitob boʻyicha toʻlanishi lozim boʻlgan summalar {ish_haqi_summasi} soʻmni tashkil qiladi.

Bundan tashqari, Mehnat kodeksining 319-moddasida "agar ish beruvchining qonunga xilof harakatlari (harakatsizligi) bilan xodimga jismoniy yoki maʼnaviy zarar yetkazilgan boʻlsa, xodimga yetkazilgan maʼnaviy ziyon kompensatsiya qilinishi lozim" deyilgan. Javobgar {ish_tugatgan_sana} dan hozirgi kungacha meni sarson qilib kelayotganligi, hech qanday asoslarsiz toʻlovni amalga oshirmayotganligi, ogʻzaki va yozma murojaatlarimga nisatan hech qanday munosabat bildirmaganligi menga qattiq taʼsir qildi hamda bundan men maʼnaviy ziyon ko‘rdim. Shunga koʻra, men Javobgar tomonidan menga yetkazilgan maʼnaviy zarar qiymatini {manaviy_zarar_miqdori} soʻm deb hisobladim.

Yuqorida keltirilgan barcha holatlarni inobatga olib, Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191-moddalariga asosan,



                                                            SOʻRAYMAN:



Javobgar {javobgar_nomi} dan mening foydamga {ish_haqi_summasi} soʻm hisob-kitob summalarini hamda yetkazilgan maʼnaviy zarar uchun {manaviy_zarar_miqdori} soʻm, jami {jami_summa} soʻm pul mablagʻlarini undirib berishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-011": {
        "nomi": "Intizomiy jazoni bekor qilish yuzasidan da'vo arizasi",
        "jpk": "Mehnat kodeksi 301, 313-moddalar, FPK 188, 189, 191, 2701-2705-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Intizomiy jazoni bekor qilish yuzasidan da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʻvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʻvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʻvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʻvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʻvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʻvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT FAOLIYATI
            {"id": "ish_boshlagan_sana", "label": "Da’vogar Javobgar tashkilotda mehnat faoliyatini boshlagan sana",
             "type": "date", "required": True},
            {"id": "lavozimi", "label": "Da’vogarning lavozimi", "type": "text", "required": True},

            # TOPSHIRIQ VA MUROJAAT
            {"id": "topshiriq_sanasi", "label": "Da’vogarga alohida topshiriq berilgan sana", "type": "date",
             "required": True},
            {"id": "murojaat_sanasi", "label": "Da’vogar tomonidan Javobgarga alohida yozma ariza kiritilgan sana",
             "type": "date", "required": True},

            # INTIZOMIY JAZO
            {"id": "jazo_sanasi", "label": "Da’vogarga nisbatan qo‘llanilgan intizomiy jazo sanasi", "type": "date",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʻvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                                          (Ish beruvchining intizomiy jazo qoʻllashga oid 
                                                   harakatlari yuzasidan)



Men {davogar_fio} {ish_boshlagan_sana} kunidan {javobgar_nomi} (keyingi oʻrinlarda – javobgar)da {lavozimi} lavozimida ishlab kelyapman.

Shu vaqtga qadar javobgar bilan tuzilgan mehnat shartnomasi va lavozim yoʻriqnomamda koʻrsatilgan vazifa va funksiyalarni oʻz vaqtida hamda toʻliq bajarib kelganman.

Tashkilot rahbar o‘rinbosarining alohida topshirig‘i bilan {topshiriq_sanasi} da ish vaqtim tugaganiga qaramasdan qo‘shimcha ishlab berdim. Buning natijasida ertasi kuni ishga kech keldim. Shu kuni HR boʻlimi boshligʻi meni chaqirib ishga kech qolib kelganligim yuzasidan tushuntirish xati yozib berishimni talab qildi. Men nima sababdan kech qolganligimni atroflicha keltirib tushuntirish xati yozdim. Biroq HR boʻlimi boshligʻi menga nisbatan intizomiy jazo chorasini qo‘lladi.

Oʻzbekiston Respublikasi Mehnat kodeksining 301-moddasi birinchi qismida "intizomiy qilmish deganda xodim tomonidan oʻz mehnat majburiyatlarini aybli tarzda, gʻayriqonuniy ravishda bajarmaganligi yoki lozim darajada bajarmaganligi (mehnat (lavozim) majburiyatlarining buzilishi) tushuniladi" deyilgan. Shuningdek, ushbu moddaning ikkinchi qismida "agar xodimning oʻz mehnat (lavozim) majburiyatlarini bajarmaganligi yoki lozim darajada bajarmaganligi xodimga bogʻliq boʻlmagan sabablarga koʻra yuz bergan boʻlsa (xodimning oʻz mehnat vazifalarini bajarish uchun ish beruvchi tomonidan zarur shart-sharoitlar taʼminlanmaganligi, fors-major holatlari va hokazolarda), xodimni intizomiy javobgarlikka tortishga yoʻl qoʻyilmaydi" deb koʻrsatilgan.

Mazkur Kodeksning 313-moddasi uchinchi qismiga koʻra intizomiy jazo chorasini qoʻllashda sodir etilgan qilmishning ogʻir-yengilligi, uning sodir etilishi holatlari, xodimning avvalgi ishi va xulq-atvori hisobga olinadi.

Meni ishga kechikib kelishim avvalo, ish beruvchi tomonining xatti-harakatlari, yaʼni bir kun oldin meni gʻayriqonuniy ravishda ishlatganligi va shundan kelib chiqqan kuchli charchoq va toliqish sabab ertalab dam olganligimdan kelib chiqqan. Yaʼni, ishga kechikib kelganligim uzrli sabablarga koʻra yuz bergan, qolaversa, bu holatda menda hech qanday ayb mavjud emas. Bundan tashqari, men shu vaqtga qadar zimmamdagi vazifa va majburiyatlarni oʻz vaqtida bajarib kelganman va mening faoliyatimga nisbatan ish beruvchida shu kunga qadar hech qanday eʼtirozlar bildirilmagan. Xulq-atvorim borasida ham jamoa yoki rahbariyat tomonidan biron-bir eʼtirozlar bildirilmagan.

Men ish beruvchiga {murojaat_sanasi} kuni alohida ariza kiritdim va menga nisbatan chiqarilgan intizomiy jazo qoʻllash haqidagi buyruq gʻayriqonuniy boʻlganligi sababli, uni bekor qilishni talab qildim. Lekin, ish beruvchi buyruqni bekor qilmadi. Shu sababli, sudga murojaat qilishdan boshqa choram qolmadi, chunki bu buyruq agar bekor qilinmasa, men turli ragʻbat va bayram mukofoti pullaridan mahrum boʻlaman. Bundan tashqari, men intizomiy jazoga loyiq boʻlgan biror ish qilmadim.

Yuqoridagilarga va Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191, 2701–2705-moddalariga asoslanib,



                                                            SOʻRAYMAN:



1. Javobgar {javobgar_nomi} direktorining menga nisbatan intizomiy jazo qoʻllashga doir xatti-harakatlarini qonunga xilof deb topishingizni.

2. Javobgarning menga nisbatan chiqarilgan intizomiy jazo qoʻllash haqidagi {jazo_sanasi} dagi buyrugʻini bekor qilishingizni (haqiqiy emas deb topishingizni).



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-012": {
        "nomi": "Ish beruvchining ishga qabul qilishga oid harakatlarini qonunga xilof deb topish va yetkazilgan zararlarni undirish toʻgʻrisida da'vo arizasi",
        "jpk": "Mehnat kodeksi 119, 320-moddalar, FPK 188, 189, 191, 2701-2705-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish beruvchining ishga qabul qilishga oid harakatlarini qonunga xilof deb topish va yetkazilgan zararlarni undirish toʻgʻrisida da'vo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʻvo arizasi berilayotgan sudning nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʻvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʻvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʻvogarning doimiy yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʻvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʻvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi", "type": "text", "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_stir", "label": "Javobgarning STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # TA'LIM
            {"id": "talim_muassasasi", "label": "Da’vogar ta’lim olgan muassasa va yo‘nalish nomi", "type": "text",
             "required": True},

            # MUROJAATLAR
            {"id": "murojaat_sanasi", "label": "Da’vogar ish so‘rab murojaat qilgan sana", "type": "date",
             "required": True},
            {"id": "javob_xati_sanasi", "label": "Javobgar rasmiy javob xati bergan sana", "type": "date",
             "required": True},

            # BANDLIK BO'LIMI
            {"id": "bandlik_xati_sanasi", "label": "Bandlik bo‘limining xati berilgan sana", "type": "date",
             "required": True},
            {"id": "yashirilgan_lavozim", "label": "Javobgar tomonidan yashirilgan lavozim nomi", "type": "text",
             "required": True},
        ],
        "shablon": """
***
                                                            Fuqarolik ishlari boʻyicha {sud_nomi}ga

                                                            Daʻvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            STIR: {javobgar_stir}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



                                                            DAʼVO ARIZASI

                      (Ish beruvchining ishga qabul qilishga oid harakatlarini qonunga xilof deb topish 
                                   va yetkazilgan zararlarni undirish toʻgʻrisida)



Men {davogar_fio} oliy maʼlumotli fuqaroman, {talim_muassasasi} yoʻnalishi boʻyicha muvaffaqiyatli tarzda tamomlaganman.

{murojaat_sanasi} kuni {javobgar_nomi} (keyingi oʻrinlarda – javobgar)ga ish soʻrab murojaat qilganman. Oʻsha vaqtda korxona rahbariyati boʻsh ish yoʻqligini maʼlum qilgach, men yozma ravishda ariza berib, meni ishga qabul qilmaslik sabablarini rasmiy javob xati bilan bildirishlarini soʻraganman. Natijada, {javob_xati_sanasi} kuni mening manzilimga javobgarning rasmiy javob xati kelib tushdi va ushbu xatda hozirgi vaqtda boʻsh ish oʻrni boʻlmaganligi sababli meni ishga qabul qilish imkonsiz ekanligi bildirilgan.

Shundan soʻng, men tumanimizdagi Kambagʻallikni qisqartirish va bandlik boʻlimiga murojaat qildim va menga maʼlum boʻlishicha, javobgarda aslida boʻsh lavozimlar boʻlgan ekan. Bandlik boʻlimining {bandlik_xati_sanasi} dagi xatiga koʻra {yashirilgan_lavozim} lavozimi boʻsh boʻlgan. Mening {talim_muassasasi} yoʻnalishi boʻyicha oliy maʼlumotga ega ekanligim, ushbu boʻsh lavozimlarda ishlashga huquqim borligini toʻliq tasdiqlaydi deb hisoblayman.

Oʻzbekiston Respublikasi Mehnat kodeksining 119-moddasiga asosan ishga qabul qilishni qonunga xilof ravishda rad etishga yoʻl qoʻyilmaydi. Men javobgarning unda mening maʼlumotim va mutaxassisligimga mos boʻsh ish oʻrinlari boʻla turib, ushbu ish oʻrinlarini yashirgan holda ishga qabul qilishni rad etganligini gʻayriqonuniy harakat deb hisoblayman.

Mehnat kodeksining 320-moddasi birinchi qismiga asosan ish beruvchi xodimni mehnat qilish imkoniyatidan gʻayriqonuniy ravishda mahrum etishning barcha hollarida u olmagan ish haqining oʻrnini unga qoplashi shart. Ushbu moddaning ikkinchi qismiga koʻra, agar ish haqi ishga qabul qilish gʻayriqonuniy ravishda rad etilganligi natijasida olinmagan boʻlsa, ish beruvchida bunday majburiyat yuzaga keladi.

Yaʼni, agarda javobgar menga nisbatan ushbu gʻayriqonuniy harakatni sodir etmaganda, men {murojaat_sanasi} kunidan ishga qabul qilingan va bugungi kunga qadar bajargan mehnatim uchun oylik ish haqi olgan boʻlar edim.

Yuqoridagilarga va Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189, 191, 2701–2705-moddalariga asoslanib,



                                                            SOʻRAYMAN:



1. Javobgarning meni ishga qabul qilishni rad etishga oid xatti-harakatlarini qonunga xilof deb topishingizni.

2. Javobgardan mening foydamga ishga qabul qilish gʻayriqonuniy ravishda rad etilganligi natijasida {murojaat_sanasi} dan bugunga qadar olinmagan ish haqi toʻlovlarini undirib berishingizni.



                                                            Daʼvogar: ___________ {davogar_fio}
                                                            (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-014": {
        "nomi": "Ish haqining undirilmay qolgan qismini undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Mehnat kodeksi 244, 253-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish haqining undirilmay qolgan qismini undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar yuridik shaxsning toʻliq nomi", "type": "text",
             "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning joylashgan manzili", "type": "text", "required": True},
            {"id": "javobgar_hisob_raqami", "label": "Hisob raqami", "type": "text", "required": False},
            {"id": "javobgar_stir", "label": "STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_mfo", "label": "MFO raqami (kodi)", "type": "text", "required": False},
            {"id": "javobgar_oked", "label": "OKED raqami (kodi)", "type": "text", "required": False},
            {"id": "javobgar_telefon", "label": "Telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Elektron manzili", "type": "email", "required": False},

            # RAHBAR MA'LUMOTLARI
            {"id": "rahbar_mansabi", "label": "Yuridik shaxs rahbarining mansabi", "type": "text", "required": True},
            {"id": "rahbar_fio", "label": "Yuridik shaxs rahbarining F.I.O.", "type": "text", "required": True},

            # ISHGA QABUL QILISH
            {"id": "ishga_qabul_sana", "label": "Daʼvogar ishga qabul qilingan sana", "type": "date", "required": True},
            {"id": "buyruq_raqami", "label": "Daʼvogarni ishga qabul qilish toʻgʻrisidagi buyruq raqami",
             "type": "text", "required": True},
            {"id": "lavozimi", "label": "Daʼvogar ishlab kelgan lavozimi nomi", "type": "text", "required": True},

            # ISH HAQI MA'LUMOTLARI
            {"id": "tolanishi_lozim_summa", "label": "1 oyda toʻlanishi lozim boʻlgan ish haqi summasi", "type": "text",
             "required": True},
            {"id": "kam_hisoblanish_sababi", "label": "Daʼvogarning ish haqi kam hisoblanishining sabablari",
             "type": "textarea", "required": True},
            {"id": "amalda_tolangan_summa", "label": "Amalda 1 oyda toʻlangan ish haqi summasi", "type": "text",
             "required": True},

            # NOTO'G'RI HISOBLASH DAVRI
            {"id": "notogri_boshlangan_sana", "label": "Ish haqini notoʻgʻri hisoblangan sana (boshlanishi)",
             "type": "text", "required": True},
            {"id": "notogri_tugagan_sana", "label": "Ish haqini notoʻgʻri hisoblangan (yakuniy) sana", "type": "text",
             "required": True},

            # SUMMALAR
            {"id": "tolanishi_lozim_umumiy", "label": "Amalda toʻlanishi lozim boʻlgan ish haqining umumiy miqdori",
             "type": "text", "required": True},
            {"id": "notogri_tolangan_umumiy", "label": "Notoʻgʻri hisoblanib, toʻlab berilgan ish haqi umumiy miqdori",
             "type": "text", "required": True},
            {"id": "jami_summa", "label": "Jami toʻlanishi lozim boʻlgan pul miqdori", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            Hisob raqami: {javobgar_hisob_raqami}
                                                            STIR: {javobgar_stir}
                                                            MFO: {javobgar_mfo}
                                                            OKED: {javobgar_oked}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: {jami_summa} soʻm miqdoridagi toʻlanmay qolgan ish haqini undirish toʻgʻrisida



                                                            DAʼVO ARIZASI



Men {davogar_fio} {javobgar_nomi} {rahbar_mansabi} {rahbar_fio}ning {ishga_qabul_sana} dagi {buyruq_raqami}-sonli buyrugʻi asosida {lavozimi} vazifasiga ishga qabul qilinganman.

Shu kunga qadar mehnat shartnomasida qayd qilingan vazifalarimni hamda ish beruvchining barcha topshiriqlarini amalga oshirgan holda mehnat faoliyati bilan shugʻullanib kelmoqdaman. Menga har oyda {tolanishi_lozim_summa} soʻm oylik ish haqi hisoblanishi lozim boʻlsada, ammo {kam_hisoblanish_sababi} sababli menga amalda {amalda_tolangan_summa} soʻm oylik ish haqi hisoblab kelingan.

Amaldagi Mehnat kodeksining 244-moddasiga muvofiq, ish beruvchi oʻzining moliyaviy holatidan qatʼi nazar, xodimga bajargan ishi uchun haqni belgilangan mehnat haqi shartlariga muvofiq ushbu Kodeksning 253-moddasida koʻrsatilgan muddatlarda toʻlashi shart, yaʼni mehnatga haq toʻlash muddatlari jamoa shartnomasi yoki boshqa lokal normativ hujjatda belgilanadi va har yarim oyda bir martadan kam boʻlishi mumkin emas. Xodimlarning ayrim toifalari uchun alohida hollarda Oʻzbekiston Respublikasi Hukumati tomonidan ish haqi toʻlashning boshqa muddatlari belgilab qoʻyilishi mumkin. Haq toʻlanadigan kun dam olish kuni yoki bayram kuniga toʻgʻri kelib qolsa, mehnat haqi shu kun arafasida toʻlanadi. Jamoa shartnomasida ish beruvchining aybi bilan xodimga haq toʻlash belgilangan muddatlarga nisbatan kechikkanligi uchun javobgarlik nazarda tutilishi mumkin.

Biroq ish beruvchi tomonidan mening {notogri_boshlangan_sana} yildan {notogri_tugagan_sana} yilga qadar boʻlgan mehnat faoliyatim uchun ish haqim notoʻgʻri hisoblanib, kam miqdorda oylik ish haqi toʻlanib kelinmoqda.

Soha mutaxassislarining hisob-kitobiga koʻra, ish haqlarimni hisoblashda xatolikka yoʻl qoʻyilib, koʻrsatilgan davrda ish haqim miqdori {tolanishi_lozim_umumiy} soʻmni tashkil etsada, ish beruvchi tomonidan {notogri_tolangan_umumiy} soʻm miqdorida ish haqi hisoblab, xatolikka yoʻl qoʻyilib, menga jami {jami_summa} soʻm oylik ish haqim toʻlanmasdan kelmoqda.

Yuqorida qayd etilganlarga koʻra, Mehnat kodeksining 244, 253-moddalari, hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan,



                                                            SOʻRAYMAN:



Mening foydamga javobgar {javobgar_nomi} dan {jami_summa} soʻm miqdoridagi ish haqi pullarimni undirib berishingizni.



Ilovalar: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-015": {
        "nomi": "Ish haqini undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Mehnat kodeksi 244, 253-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish haqini undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar yuridik shaxsning toʻliq nomi", "type": "text",
             "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning manzili", "type": "text", "required": True},
            {"id": "javobgar_hisob_raqami", "label": "Hisob raqami", "type": "text", "required": False},
            {"id": "javobgar_stir", "label": "STIR raqami", "type": "text", "required": True},
            {"id": "javobgar_mfo", "label": "MFO raqami (kodi)", "type": "text", "required": False},
            {"id": "javobgar_oked", "label": "OKED raqami", "type": "text", "required": False},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # RAHBAR MA'LUMOTLARI
            {"id": "rahbar_mansabi", "label": "Yuridik shaxs rahbarining mansabi", "type": "text", "required": True},
            {"id": "rahbar_fio", "label": "Yuridik shaxs rahbarining F.I.O.", "type": "text", "required": True},

            # ISHGA QABUL QILISH
            {"id": "ishga_qabul_sana", "label": "Xodim ishga qabul qilingan sana", "type": "date", "required": True},
            {"id": "buyruq_raqami", "label": "Xodimni ishga qabul qilish buyruq raqami", "type": "text",
             "required": True},
            {"id": "lavozimi", "label": "Daʼvogar ishlab kelgan lavozimi nomi", "type": "text", "required": True},

            # ISH HAQI MA'LUMOTLARI
            {"id": "tolanishi_lozim_summa", "label": "Toʻlanmay qolgan ish haqi miqdori", "type": "text",
             "required": True},
            {"id": "tolanmagan_sababi", "label": "Ish haqi toʻlanmagani sababi", "type": "textarea", "required": True},
            {"id": "tolanmagan_boshlangan_sana", "label": "Ish haqi toʻlanmagan sana (boshlanishi)", "type": "text",
             "required": True},
            {"id": "tolanmagan_tugagan_sana", "label": "Ish haqi toʻlanmagan sana (oxirgi)", "type": "text",
             "required": True},
            {"id": "tolanmagan_umumiy_miqdor", "label": "Ish haqining toʻlanmagan umumiy miqdori", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Daʼvo arizaga ilova qilinayotgan hujjatlar roʻyxati", "type": "textarea",
             "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            Hisob raqami: {javobgar_hisob_raqami}
                                                            STIR: {javobgar_stir}
                                                            MFO: {javobgar_mfo}
                                                            OKED: {javobgar_oked}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: {tolanishi_lozim_summa} soʻm toʻlanmagan ish haqini undirish toʻgʻrisida



                                                            DAʼVO ARIZASI



{javobgar_nomi} {rahbar_mansabi} {rahbar_fio}ning {ishga_qabul_sana} yildagi {buyruq_raqami}-sonli buyrugʻi asosida {lavozimi} vazifasiga ishga qabul qilinganman.

Shu kunga qadar mehnat shartnomasida qayd qilingan vazifalarimni hamda ish beruvchining barcha topshiriqlarini amalga oshirgan holda mehnat faoliyati bilan shugʻullanib kelmoqdaman.

Ammo ish beruvchining tushuntirishiga koʻra, {tolanmagan_sababi} sababli menga hisoblangan ish haqi oʻz vaqtida toʻlanmasdan kelmoqda.

Amaldagi Mehnat kodeksining 244-moddasiga muvofiq, ish beruvchi oʻzining moliyaviy holatidan qatʼi nazar, xodimga bajargan ishi uchun haqni belgilangan mehnat haqi shartlariga muvofiq ushbu Kodeksning 253-moddasida koʻrsatilgan muddatlarda toʻlashi shart, yaʼni mehnatga haq toʻlash muddatlari jamoa shartnomasi yoki boshqa lokal normativ hujjatda belgilanadi va har yarim oyda bir martadan kam boʻlishi mumkin emas. Haq toʻlanadigan kun dam olish kuni yoki bayram kuniga toʻgʻri kelib qolsa, mehnat haqi shu kun arafasida toʻlanadi. Jamoa shartnomasida ish beruvchining aybi bilan xodimga haq toʻlash belgilangan muddatlarga nisbatan kechikkanligi uchun javobgarlik nazarda tutilishi mumkin.

Biroq ish beruvchi tomonidan mening {tolanmagan_boshlangan_sana} yildan {tolanmagan_tugagan_sana} yilga qadar boʻlgan mehnat faoliyatim uchun ish haqi umuman toʻlanmagan.

Soha mutaxassislarining hisob-kitobiga koʻra, toʻlanmasdan kelingan ish haqlarim miqdori {tolanmagan_umumiy_miqdor} soʻmni tashkil qilgan boʻlsada, ish beruvchi tomonidan turli xil vajlar asosida oylik maoshim toʻlanmasdan kelinmoqda.

Yuqorida qayd etilganlarga koʻra, Mehnat kodeksining 244, 253-moddalari, hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asosan,



                                                            SOʻRAYMAN:



Mening foydamga javobgar {javobgar_nomi} dan {tolanmagan_umumiy_miqdor} soʻm miqdoridagi ish haqi pullarimni undirishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.



Izoh: Daʼvo ariza vakil orqali berilgan hollarda vakil tomonidan imzolanadi. Vakilning vakolatini tasdiqlovchi ishonchnoma daʼvo arizasiga ilova qilinishi shart.
***
"""
    },
"FQ-MN-016": {
        "nomi": "Ish haqini undirish va toʻlovlar kechikkanligi sababli pul kompensatsiyasi undirish toʻgʻrisida daʼvo arizasi",
        "jpk": "Mehnat kodeksi 244, 253-moddalar, FPK 188, 189, 191-moddalar",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Ish haqini undirish va toʻlovlar kechikkanligi sababli pul kompensatsiyasi undirish toʻgʻrisida daʼvo arizasi" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. Yuqori o'ng tomonda sud nomi, da'vogar va javobgar ma'lumotlari bo'lsin.
4. "DA'VO ARIZASI" va "SO'RAYMAN" sarlavhalari markazda bo'lsin.
5. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
6. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            # SUD MA'LUMOTLARI
            {"id": "sud_nomi", "label": "Daʼvo ariza berilgan sud nomi", "type": "text", "required": True},
            {"id": "ariza_sana", "label": "Daʼvo ariza berilgan sana", "type": "date", "required": True},

            # DA'VOGAR MA'LUMOTLARI
            {"id": "davogar_fio", "label": "Daʼvogarning F.I.O.", "type": "text", "required": True},
            {"id": "davogar_manzil", "label": "Daʼvogarning yashash manzili", "type": "text", "required": True},
            {"id": "davogar_telefon", "label": "Daʼvogarning telefon raqami", "type": "text", "required": True},
            {"id": "davogar_email", "label": "Daʼvogarning elektron manzili", "type": "email", "required": False},

            # JAVOBGAR MA'LUMOTLARI
            {"id": "javobgar_nomi", "label": "Javobgar tashkilotning nomi va tashkiliy-huquqiy shakli", "type": "text",
             "required": True},
            {"id": "javobgar_manzil", "label": "Javobgarning joylashgan manzili", "type": "text", "required": True},
            {"id": "javobgar_telefon", "label": "Javobgarning telefon raqami", "type": "text", "required": False},
            {"id": "javobgar_email", "label": "Javobgarning elektron manzili", "type": "email", "required": False},

            # MEHNAT SHARTNOMASI
            {"id": "ishga_qabul_sana", "label": "Mehnat shartnomasi asosida xodim ishga qabul qilingan sana",
             "type": "date", "required": True},
            {"id": "shartnoma_raqami", "label": "Mehnat shartnomasi raqami", "type": "text", "required": True},
            {"id": "lavozimi", "label": "Mehnat shartnomasi asosida xodimning lavozimi", "type": "text",
             "required": True},

            # ISH HAQI MA'LUMOTLARI
            {"id": "tolanmagan_yil", "label": "Oylik ish haqi pullari toʻlanmagan yil", "type": "text",
             "required": True},
            {"id": "tolanmagan_oylar", "label": "Oylik ish haqi toʻlanmagan oylar", "type": "text", "required": True},
            {"id": "tolanmagan_umumiy_summa", "label": "Toʻlanmagan oylik ish haqining umumiy summasi", "type": "text",
             "required": True},
            {"id": "kechiktirilgan_summa", "label": "Oʻz vaqtida toʻlanmagan ish haqi miqdori", "type": "text",
             "required": True},

            # ILOVA
            {"id": "ilova", "label": "Ilova qilingan hujjatlar roʻyxati", "type": "textarea", "required": False},
        ],
        "shablon": """
***
                                                            {sud_nomi}ga

                                                            Daʼvogar: {davogar_fio}
                                                            Manzil: {davogar_manzil}
                                                            Telefon: {davogar_telefon}
                                                            Elektron manzil: {davogar_email}

                                                            Javobgar: {javobgar_nomi}
                                                            Manzil: {javobgar_manzil}
                                                            Telefon: {javobgar_telefon}
                                                            Elektron manzil: {javobgar_email}



Daʼvo mazmuni: {kechiktirilgan_summa} soʻm ish haqi va {tolanmagan_oylar} soʻm pul kompensatsiyasini undirish toʻgʻrisida



                                                            DAʼVO ARIZA



{javobgar_nomi} rahbarining {ishga_qabul_sana} dagi {shartnoma_raqami}-sonli buyrugʻi asosida men {lavozimi} lavozimiga ishga qabul qilinganman.

Shu kunga qadar mehnat faoliyati bilan shugʻullanib kelmoqdaman.

Biroq ish beruvchi menga toʻlanishi lozim boʻlgan {tolanmagan_yil} yilning {tolanmagan_oylar} oylaridagi ish haqlarimni hanuzgacha bermasdan moliyaviy holatini vaj qilib, paysalga solib kelmoqda. Hozirda javobgarning mendan ish haqi boʻyicha {tolanmagan_umumiy_summa} soʻm qarzdorligi mavjud.

Buning natijasida men moddiy va maʼnaviy zarar koʻrib kelmoqdaman.

Mehnat kodeksining 244-moddasiga muvofiq, ish beruvchi oʻzining moliyaviy holatidan qatʼi nazar, xodimga bajargan ishi uchun haqni belgilangan mehnat haqi shartlariga muvofiq ushbu Kodeksning 253-moddasida koʻrsatilgan muddatlarda toʻlashi shart, yaʼni mehnatga haq toʻlash muddatlari jamoa shartnomasi yoki boshqa lokal normativ hujjatda belgilanadi va har yarim oyda bir martadan kam boʻlishi mumkin emas. Xodimlarning ayrim toifalari uchun alohida hollarda Oʻzbekiston Respublikasi Hukumati tomonidan ish haqi toʻlashning boshqa muddatlari belgilab qoʻyilishi mumkin. Haq toʻlanadigan kun dam olish kuni yoki bayram kuniga toʻgʻri kelib qolsa, mehnat haqi shu kun arafasida toʻlanadi. Jamoa shartnomasida ish beruvchining aybi bilan xodimga haq toʻlash belgilangan muddatlarga nisbatan kechikkanligi uchun javobgarlik nazarda tutilishi mumkin.

Mazkur kodeksning 244-moddasiga muvofiq, mehnat haqi shakli va tizimlari, mukofotlar, qoʻshimcha toʻlovlar, ustamalar, ragʻbatlantirish tarzidagi toʻlovlar jamoa shartnomalarida, shuningdek ish beruvchi tomonidan kasaba uyushmasi qoʻmitasi yoki xodimlarning boshqa vakillik organi bilan kelishib qabul qilinadigan boshqa lokal hujjatlarda belgilanadi.

Korxonaning jamoa shartnomasida ish beruvchining aybi bilan xodimga haq toʻlash belgilangan muddatlarga nisbatan kechikkanligi uchun ish haqining xodim oylik ish haqining bir baravari miqdorida kompensatsiya toʻlanishi nazarda tutilgan boʻlib, korxona rahbari tomonidan ish haqlari berilmaganligi natijasida moddiy zarar koʻrdim.

Yuqorida qayd etilganlarga koʻra, Oʻzbekiston Respublikasining Mehnat kodeksining 244-moddasiga hamda Oʻzbekiston Respublikasi Fuqarolik protsessual kodeksining 188, 189 va 191-moddalariga asoslanib,



                                                            SOʻRAYMAN:



1. Javobgardan mening foydamga {tolanmagan_umumiy_summa} soʻm miqdorida ish haqi undirishingizni.

2. Javobgardan mening foydamga ish haqim kechiktirilganligi tufayli bir oylik ish haqim miqdorida kompensatsiya undirishingizni.



Ilova: {ilova}



                                                            Daʼvogar: ___________ {davogar_fio}
                                                                         (imzo)

                                                            {ariza_sana} yil.
***
"""
    },
"FQ-MN-017": {
        "nomi": "Homiladorlik va tug‘ish ta’tili berish to‘g‘risida buyruq",
        "jpk": "Mehnat kodeksi 404-modda",
        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Homiladorlik va tug‘ish ta’tili berish to‘g‘risida buyruq" hujjatini yoz.
2. Hujjat matnini to'liq, formatlangan holda yoz.
3. "BUYRUQ" sarlavhasi markazda bo'lsin.
4. Mazmun qismida faqat berilgan ma'lumotlarni yoz.
5. Hujjat matnini *** va *** orasiga ol.
""",
        "maydonlar": [
            {"id": "buyruq_sana", "label": "Buyruq chiqarilgan sana", "type": "date", "required": True},
            {"id": "buyruq_soni", "label": "Buyruq soni", "type": "text", "required": True},
            {"id": "buyruq_royxat", "label": "Buyruq ro‘yxat raqami", "type": "text", "required": True},

            {"id": "xodim_fio", "label": "Xodimning to‘liq familiyasi, ismi va otasining ismi", "type": "text",
             "required": True},
            {"id": "xodim_lavozimi", "label": "Xodimning lavozimi", "type": "text", "required": True},

            {"id": "ta_til_boshlanishi", "label": "Ta'til boshlanish sanasi", "type": "date", "required": True},
            {"id": "ta_til_tugashi", "label": "Ta'til tugash sanasi", "type": "date", "required": True},

            {"id": "rahbar_fio", "label": "Tashkilot rahbarining F.I.O.", "type": "text", "required": True},
        ],
        "shablon": """
***
                                                              BU Y R U Q

{ta_til_boshlanishi} yil
{buyruq_soni}-son
Ro'yxat raqami: {buyruq_royxat}



                                                Homiladorlik va tug‘ish ta’tili berish to‘g‘risida



1. {xodim_fio} {xodim_lavozimi} lavozimidagi xodimga {ta_til_boshlanishi} dan {ta_til_tugashi} gacha bo'lgan muddatda homiladorlik va tug‘ish ta’tili berilsin.

2. Ta'til muddati quyidagicha hisoblansin:
   - Homiladorlik ta'tili: 10 kalendar kuni
   - Tug‘ish ta'tili: 50 ish kuni

Asos: {xodim_fio}ning arizasi, tibbiyot muassasasining mehnatga qobiliyatsizlik varaqasi, O‘zbekiston Respublikasi Mehnat kodeksining 404-moddasi.



                                                              Tashkilot rahbari: __________ {rahbar_fio}



Buyruq bilan tanishdim: __________ {xodim_fio}

{ta_til_boshlanishi} yil
***
"""
    },
}
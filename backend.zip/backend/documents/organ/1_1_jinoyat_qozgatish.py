"""
1.1 bo'lim — Jinoyat ishi qo'zg'atish
Barcha hujjat turlari: a dan i gacha
"""

HUJJATLAR = {
    "JQ-A": {
        "harf": "a",
        "nomi": "Jinoyatga oid ma'lumotlar aniqlanganligi yuzasidan bildirgi",
        "jpk": "JPK 322-modda 1-qism, 328-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. Quyidagi QOIDALARGA QAT'IY AMAL QIL:

1. Faqat "Jinoyatga oid ma'lumotlar aniqlanganligi yuzasidan BILDIRGI" hujjatini yoz
2. Shablon tuzilishini O'ZGARTIRMA — yuqori qismda nazarat qiluvchi prokuror va tergovchi ma'lumotlari bo'ladi
3. JPK 322-modda 1-qismi __-bandiga — foydalanuvchi bergan band raqamini qo'y
4. Mazmun qismida faqat BERILGAN ma'lumotlarni yoz, o'ylab qo'shma
5. Oxirida tergovchi lavozimi, unvoni va imzo qismi bo'ladi
6. Hujjat matnini *** va *** orasiga ol

NAMUNA (3-rasmdan):
- Yuqorida o'ng tomonda: nazarat qiluvchi prokuror ma'lumotlari, keyin tergovchi ma'lumotlari
- Sarlavha: "Jinoyatga oid ma'lumotlar aniqlanganligi yuzasidan BILDIRGI"
- Sana va hudud
- JPK 322-modda 1-qismi __-bandi va 328-modda talablariga rioya qilib...
- Voqea mazmuni batafsil
- So'ngida: tergov qadar tekshiruv harakatlari o'tkazilganligi
- Hujjatlarni prokuratura kitobiga qayd etishga ruxsat so'rash
- Imzo qismi: lavozim, unvon, F.I.Sh.
""",

        "maydonlar": [
            {"id": "nazarat_prokuror", "label": "Nazarat qiluvchi prokuror (F.I.O)", "type": "text",
             "required": True},
            {"id": "nazarat_lavozim", "label": "Nazarat qiluvchi prokuror lavozimi va unvoni", "type": "text",
             "required": True},
            {"id": "tergovchi_fio", "label": "Tergovchi F.I.O", "type": "text", "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi va unvoni", "type": "text", "required": True},
            {"id": "jpk_band", "label": "JPK 322-modda 1-qismi nechi-bandi", "type": "text", "required": True},
            {"id": "sana_yil", "label": "Yil", "type": "text", "required": True},
            {"id": "sana_kun_oy", "label": "Kun va oy (masalan: 8 yanvar)", "type": "text", "required": True},
            {"id": "hudud", "label": "Hudud (tuman/shahar)", "type": "text", "required": True},
            {"id": "xabar_manbai", "label": "Xabar manba'i (IIB navbatchilik, ariza va h.k)", "type": "text",
             "required": True},
            {"id": "xabar_sanasi", "label": "Xabar sanasi", "type": "text", "required": False},
            {"id": "voqea_mazmuni", "label": "Voqeaning batafsil mazmuni", "type": "textarea", "required": True},
            {"id": "tekshiruv_harakati", "label": "O'tkazilgan tergov qadar tekshiruv harakatlari", "type": "textarea",
             "required": True},
            {"id": "prokuratura_nomi", "label": "Prokuratura nomi (masalan: Olmazor tuman)", "type": "text",
             "required": True},
        ],

        "shablon": """\
***
                                        {nazarat_lavozim}
                                        {nazarat_prokuror}ga

                                        {tergovchi_lavozim}
                                        {tergovchi_fio} tomonidan


          Jinoyatga oid ma'lumotlar aniqlanganligi yuzasidan
                              BILDIRGI

_____ yil ___________                                    _______________
          (kun, oy)                                           (hudud)

    O'zbekiston Respublikasi JPKning 322-moddasi 1-qismi {jpk_band}-bandi
va 328-modda talablariga rioya qilib, quyidagilarni ma'lum qilaman:

    {xabar_manbai} {xabar_sanasi} yildagi xabariga ko'ra, {voqea_mazmuni}

    {tekshiruv_harakati}

    Yuqoridagilardan to'plangan hujjatlarni {prokuratura_nomi} prokuraturasining
jinoyat haqidagi ariza va xabarlarni ro'yxatga olish kitobiga qayd etishga
ruxsat berishingizni so'rayman.

________________                              ________________
(mansabi, unvoni)                                  (imzo)
                                                  {tergovchi_fio}
***
"""
    },

    "JQ-B": {
        "harf": "b",
        "nomi": "Og'zaki arizani qabul qilish bayonnomasi",
        "jpk": "JPK 324-modda, 329-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Og'zaki arizani qabul qilish BAYONNOMASI" hujjatini yozasan.

QOIDALAR:
1. Hujjat tuzilishini O'ZGARTIRMA — rasmiy shakl qat'iy
2. Foydalanuvchi bergan ma'lumotlarni shablon joylariga qo'y
3. O'ylab qo'shma, berilgan ma'lumotdan chiq
4. Arz qiluvchi ma'lumotlari 7 ta band sifatida yoziladi
5. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan):
- Sarlavha: "Og'zaki arizani qabul qilish BAYONNOMASI"
- Sana (yil, kun, oy) va hudud
- Tergovchi: [prokuratura nomi] prokuraturasi tergovchisi, [unvon] [F.I.Sh.] 
  O'zbekiston Respublikasi JPKning 324-moddasi [qism]-qismi talabiga rioya qilgan holda, fuqaroning og'zaki arizasini qabul qildim:
- 7 ta band: 1.FISh, 2.Tug'ilgan yil/oy/kun, 3.Ma'lumoti, 4.Oilaviy ahvoli, 5.Ish joyi/mansabi, 6.Yashash joyi/telefon, 7.Shaxsini tasdiqlovchi hujjat
- Arizani qabul qilish soat "___:___" da boshlandi
- [Arz qiluvchi F.I.Sh.] bila turib yolg'on xabar bergan taqdirda O'zbekiston Respublikasi JKning 237-moddasi bilan jinoiy javobgarlikka tortilishi haqida ogohlantirildi
- (imzo)
- Arz qiluvchi [F.I.Sh.] quyidagilarni ma'lum qildi: [ariza mazmuni]
- Arizani qabul qilish soat "___:___" da tamomlanindi
- Bayonnomani [kim tomionidan] o'qib eshittiridi. Ariza to'g'ri yozilgan
- Arizani qabul qilishga, bayonnoma mazmuniga qo'shimcha va e'tirozim yo'q
- Arz qiluvchi: (imzo) F.I.Sh.
- Arizani qabul qildim va bayonnoma tuzdim
- (mansabi, unvoni) — (imzo) — F.I.Sh.
""",

        "maydonlar": [
            {"id": "prokuratura_nomi", "label": "Prokuratura nomi (masalan: Mirobod tuman)", "type": "text",
             "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi (masalan: katta tergovchi)", "type": "text",
             "required": True},
            {"id": "tergovchi_unvon", "label": "Tergovchi unvoni (masalan: 1-darajali yurist)", "type": "text",
             "required": True},
            {"id": "tergovchi_fio", "label": "Tergovchi F.I.Sh. (masalan: B.Bekjonov)", "type": "text",
             "required": True},
            {"id": "jpk_qism", "label": "JPK 324-modda nechi-qismi (masalan: 2)", "type": "text", "required": True},
            {"id": "sana_yil", "label": "Yil", "type": "text", "required": True},
            {"id": "sana_kun_oy", "label": "Kun va oy (masalan: 14 mart)", "type": "text", "required": True},
            {"id": "hudud", "label": "Hudud (tuman/shahar)", "type": "text", "required": True},
            {"id": "arz_fio", "label": "Arz qiluvchi F.I.Sh.", "type": "text", "required": True},
            {"id": "arz_tugilgan", "label": "Tug'ilgan yili, oyi, kuni", "type": "text", "required": True},
            {"id": "arz_malumot", "label": "Ma'lumoti", "type": "text", "required": False},
            {"id": "arz_oila", "label": "Oilaviy ahvoli", "type": "text", "required": False},
            {"id": "arz_ish", "label": "Ish joyi va mansabi", "type": "text", "required": False},
            {"id": "arz_manzil", "label": "Yashash joyi va telefon raqami", "type": "text", "required": False},
            {"id": "arz_hujjat", "label": "Shaxsini tasdiqlovchi hujjat (pasport seriya/raqam)", "type": "text",
             "required": False},
            {"id": "boshlash_soat", "label": "Arizani qabul qilish boshlangan vaqt (masalan: 14:30)", "type": "text",
             "required": True},
            {"id": "tugash_soat", "label": "Arizani qabul qilish tugagan vaqt (masalan: 15:30)", "type": "text",
             "required": True},
            {"id": "ariza_mazmuni", "label": "Arizaning mazmuni (arz qiluvchi so'zlari bilan)", "type": "textarea",
             "required": True},
        ],

        "shablon": """\
***
                                                            Og'zaki arizani qabul qilish
                                                                   BAYONNOMASI

_____ yil _____________                                                      _______________
          (kun, oy)                                                              (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} O'zbekiston Respublikasi JPKning 324-moddasi {jpk_qism}-qismi
talabiga rioya qilgan holda, fuqaroning og'zaki arizasini qabul qildim:



    1.  Familiyasi, ismi va otasining ismi          {arz_fio}
    2.  Tug'ilgan yili, oyi va kuni                 {arz_tugilgan}
    3.  Ma'lumoti                                   {arz_malumot}
    4.  Oilaviy ahvoli                               {arz_oila}
    5.  Ish joyi, mansabi                            {arz_ish}
    6.  Yashash joyi, telefon raqami                 {arz_manzil}
    7.  Shaxsini tasdiqlovchi hujjat                 {arz_hujjat}



arizasini qabul qildim.

    Arizani qabul qilish soat "{boshlash_soat}" da boshlandi.

    {arz_fio} bila turib yolg'on xabar bergan taqdirda O'zbekiston
Respublikasi JKning 237-moddasi bilan jinoiy javobgarlikka tortilishi
haqida ogohlantirildi.



                                                                        ________________
                                                                            (imzo)



    Arz qiluvchi {arz_fio} quyidagilarni ma'lum qildi:



{ariza_mazmuni}



    Arizani qabul qilish soat "{tugash_soat}" da tamomlanindi.

    Bayonnomani {tergovchi_fio} o'qib eshittiridi. Ariza to'g'ri yozilgan.
    Arizani qabul qilishga, bayonnoma mazmuniga qo'shimcha va e'tirozim yo'q.



Arz qiluvchi:                                           ________________ {arz_fio}
                                                             (imzo)



Arizani qabul qildim va bayonnoma tuzdim.



{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}                                       (imzo)          {tergovchi_fio}
***
"""
    },

    "JQ-C": {
        "harf": "c",
        "nomi": "OAV ixtiyorida bo'lgan hujjatlarni va xabarni tasdiqlovchi boshqa materiallarni tekshirish uchun taqdim qilish haqida talabnoma",
        "jpk": "JPK 322-modda 1-qism 3-band, 327-modda, 36-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. OAV ga yo'naltiriladigan "TALABNOMA" hujjatini yozasan.

QOIDALAR:
1. Hujjat tuzilishini O'ZGARTIRMA
2. Yuqori o'ng tomonda: OAV nomi va bosh muharriri, keyin tergovchi ma'lumotlari
3. Sarlavha OAV turiga qarab o'zgaradi: gazeta uchun "tahririyat ixtiyorida bo'lgan", internet uchun "agentlik ixtiyorida bo'lgan" deb yoz
4. JPK 322-modda 1-qismi 3-bandi va 327-moddasiga asoslanib yoz
5. Material tavsifi: OAV nomi, sana, son/raqam, maqola sarlavhasi, qaysi voqea haqida
6. Muddat: aniq sana ko'rsatiladi (masalan: 10.12.2017 yilga qadar)
7. JPK 36-modda matni — har doim oxirida bo'ladi
8. Imzo qismi: prokuratura nomi, lavozim, unvon, imzo, F.I.Sh.
9. Hujjat matnini *** va *** orasiga ol

JPK 36-MODDA MATNI (o'zgartirilmaydi):
"O'zbekiston Respublikasi JPKning 36-moddasiga ko'ra, tergovchining o'zi yuritayotgan ish yuzasidan qonunga muvofiq bergan yozma topshiriqlari va chiqargan qarorlari barcha korxonalar, muassasalar, tashkilotlar, mansabdor shaxslar va fuqarolar tomonidan ijro etilishi majburiydir, ularni bajarmaslik javobgarlikni keltirib chiqaradi."
""",

        "maydonlar": [
            {"id": "oav_turi", "label": "OAV turi (gazeta/jurnal/internet sayt/kanal)", "type": "text",
             "required": True},
            {"id": "oav_nomi", "label": "OAV nomi (masalan: Xalq so'zi gazetasi)", "type": "text", "required": True},
            {"id": "oav_rahbari_lavozim", "label": "OAV rahbari lavozimi (masalan: Bosh muharrir)", "type": "text",
             "required": True},
            {"id": "oav_rahbari_fio", "label": "OAV rahbari F.I.Sh. (masalan: O'.Rahmatov)", "type": "text",
             "required": True},
            {"id": "prokuratura_nomi", "label": "Prokuratura nomi (masalan: Yashnobod tuman)", "type": "text",
             "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi (masalan: katta tergovchi)", "type": "text",
             "required": True},
            {"id": "tergovchi_unvon", "label": "Tergovchi unvoni (masalan: 3-darajali yurist)", "type": "text",
             "required": True},
            {"id": "tergovchi_fio", "label": "Tergovchi F.I.Sh. (masalan: B.Bekjonov)", "type": "text",
             "required": True},
            {"id": "nashr_sanasi", "label": "Nashr sanasi (masalan: 30.11.2017)", "type": "text", "required": True},
            {"id": "nashr_raqami", "label": "Son/raqami (masalan: №64 (6758))", "type": "text", "required": False},
            {"id": "maqola_sarlavha", "label": "Maqola/material sarlavhasi", "type": "text", "required": True},
            {"id": "voqea_tavsifi", "label": "Qaysi voqea/hudud haqida (qisqacha)", "type": "textarea",
             "required": True},
            {"id": "muddat_sana", "label": "Taqdim etish muddati (masalan: 10.12.2017)", "type": "text",
             "required": True},
            {"id": "qabul_organ", "label": "Qaerga taqdim etish (masalan: Yashnobod tuman prokuraturasiga)",
             "type": "text", "required": True},
        ],

        "shablon": """\
***
                                                            {oav_nomi}
                                                            {oav_rahbari_lavozim}i
                                                            {oav_rahbari_fio}ga



                                                            {prokuratura_nomi} prokuraturasi
                                                            {tergovchi_lavozim}i
                                                            {tergovchi_unvon}
                                                            {tergovchi_fio} tomonidan




          jinoyat haqidagi xabarni tasdiqlovchi {oav_turi} ixtiyorida
          bo'lgan hujjatlar va boshqa materiallarni tekshirish uchun
                taqdim qilish haqida
                              TALABNOMA



    O'zbekiston Respublikasi JPKning 322-moddasi 1-qismi 3-bandi
va 327-moddasiga asoslanib, {oav_nomi} ning {nashr_sanasi} yildagi
{nashr_raqami}-sonli sonida "{maqola_sarlavha}" sarlavhasi bilan
{voqea_tavsifi} haqida chop etilgan maqola yuzasidan tahririyatga
taqdim qilingan xabarni tasdiqlovchi hujjatlar va materiallarni,
shuningdek, ularni taqdim etgan shaxs haqidagi mavjud ma'lumotlarni
{muddat_sana} yilga qadar {qabul_organ}ga taqdim qilishingizni so'rayman.



    O'zbekiston Respublikasi JPKning 36-moddasiga ko'ra,
tergovchining o'zi yuritayotgan ish yuzasidan qonunga muvofiq
bergan yozma topshiriqlari va chiqargan qarorlari barcha
korxonalar, muassasalar, tashkilotlar, mansabdor shaxslar va
fuqarolar tomonidan ijro etilishi majburiydir, ularni
bajarmaslik javobgarlikni keltirib chiqaradi.



{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}                                       (imzo)          {tergovchi_fio}
***
"""
    },

    "JQ-D": {
        "harf": "d",
        "nomi": "Aybni bo'yniga olish haqidagi arz bayonnomasi",
        "jpk": "JPK 113-modda, 324-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Aybni bo'yniga olish haqidagi arz BAYONNOMASI" hujjatini yozasan.

QOIDALAR:
1. Hujjat tuzilishini O'ZGARTIRMA
2. JPK 113-modda va 324-modda talablariga rioya qilinadi
3. Arz qiluvchi MA'LUMOTLARI 7 ta band sifatida yoziladi
4. Arz qiluvchi o'z aybini o'zi bo'yniga olib kelgan — shu holat aks ettiriladi
5. Qabul qilingan joy: prokuratura xizmat xonasi yoki boshqa joy ko'rsatiladi
6. Ariza mazmunida arz qiluvchi so'zlari birinchi shaxsdan yoziladi (Men...)
7. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan):
- Sarlavha: "Aybni bo'yniga olish haqidagi arz BAYONNOMASI"
- Sana (yil, kun, oy) va hudud
- Tergovchi: [prokuratura] prokuraturasi [lavozim]i, [unvon] [F.I.Sh.] 
  [prokuratura]sidagi xizmat xonasida O'zbekiston Respublikasi JPKning 113, 324-moddalari talablariga ko'ra o'z aybini bo'yniga olib kelgan:
- 7 ta band: 1.FISh, 2.Tug'ilgan yil/oy/kun, 3.Ma'lumoti, 4.Oilaviy ahvoli, 5.Ish joyi/mansabi, 6.Yashash joyi/telefon, 7.Shaxsini tasdiqlovchi hujjat
- "ning arizasini qabul qildim."
- Arzi qabul qilish soat "___" da boshlandi
- Fuqaro [F.I.Sh.] quyidagilarni ma'lum qildi: [ariza mazmuni birinchi shaxsdan]
- Arizani qabul qilish soat "___" da tamomlanindi
- Bayonnoma o'qib eshittirildi, to'g'ri yozilgan, qo'shimcha va e'tirozim yo'q
- Arz qiluvchi: (imzo) F.I.Sh.
- Arizani qabul qildim va bayonnoma tuzdim
- Prokuratura nomi, lavozim, unvon, imzo, F.I.Sh.
""",

        "maydonlar": [
            {"id": "prokuratura_nomi", "label": "Prokuratura nomi (masalan: Bog'ot tuman)", "type": "text",
             "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi (masalan: katta tergovchi)", "type": "text",
             "required": True},
            {"id": "tergovchi_unvon", "label": "Tergovchi unvoni (masalan: 1-darajali yurist)", "type": "text",
             "required": True},
            {"id": "tergovchi_fio", "label": "Tergovchi F.I.Sh. (masalan: B.Bekjonov)", "type": "text",
             "required": True},
            {"id": "sana_yil", "label": "Yil", "type": "text", "required": True},
            {"id": "sana_kun_oy", "label": "Kun va oy (masalan: 15 fevral)", "type": "text", "required": True},
            {"id": "hudud", "label": "Hudud (tuman/shahar)", "type": "text", "required": True},
            {"id": "arz_fio", "label": "Arz qiluvchi F.I.Sh.", "type": "text", "required": True},
            {"id": "arz_tugilgan", "label": "Tug'ilgan yili, oyi, kuni", "type": "text", "required": True},
            {"id": "arz_malumot", "label": "Ma'lumoti", "type": "text", "required": False},
            {"id": "arz_oila", "label": "Oilaviy ahvoli", "type": "text", "required": False},
            {"id": "arz_ish", "label": "Ish joyi va mansabi", "type": "text", "required": False},
            {"id": "arz_manzil", "label": "Yashash joyi va telefon raqami", "type": "text", "required": False},
            {"id": "arz_hujjat", "label": "Shaxsini tasdiqlovchi hujjat", "type": "text", "required": False},
            {"id": "boshlash_soat", "label": "Arz qabul qilish boshlangan vaqt (masalan: 10:20)", "type": "text",
             "required": True},
            {"id": "tugash_soat", "label": "Arz qabul qilish tugagan vaqt (masalan: 10:55)", "type": "text",
             "required": True},
            {"id": "ariza_mazmuni", "label": "Arz mazmuni (birinchi shaxsdan: Men...)", "type": "textarea",
             "required": True},
        ],

        "shablon": """\
***
                                                            Aybni bo'yniga olish haqidagi arz
                                                                   BAYONNOMASI

_____ yil _____________                                                      _______________
          (kun, oy)                                                              (hudud)



    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} {prokuratura_nomi} prokuraturasidagi xizmat xonasida
O'zbekiston Respublikasi JPKning 113, 324-moddalari talablariga ko'ra
o'z aybini bo'yniga olib kelgan:



    1.  Familiyasi, ismi va otasining ismi          {arz_fio}
    2.  Tug'ilgan yili, oyi va kuni                 {arz_tugilgan}
    3.  Ma'lumoti                                   {arz_malumot}
    4.  Oilaviy ahvoli                               {arz_oila}
    5.  Ish joyi, mansabi                            {arz_ish}
    6.  Yashash joyi, telefon raqami                 {arz_manzil}
    7.  Shaxsini tasdiqlovchi hujjat                 {arz_hujjat}



ning arizasini qabul qildim.

    Arzni qabul qilish soat {boshlash_soat} da boshlandi.



    Fuqaro {arz_fio} quyidagilarni ma'lum qildi:



"{ariza_mazmuni}"



    Arzni qabul qilish soat {tugash_soat} da tamomlanindi.

    Bayonnoma o'qib eshittirildi, to'g'ri yozilgan, arzni qabul qilish
va bayonnoma mazmuniga qo'shimcha va e'tirozim yo'q.



Arz qiluvchi:                                           ________________ {arz_fio}
                                                             (imzo)



Arzni qabul qildim va bayonnoma tuzdim.



{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}                                       (imzo)          {tergovchi_fio}
***
"""
    },

    "JQ-E": {
        "harf": "e",
        "nomi": "Jinoyat ishini qo'zg'atish haqida qaror",
        "jpk": "JPK 15, 321, 322, 330, 331, 336, 345-moddalar",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atish haqida QAROR" hujjatini yozasan.

QOIDALAR:
1. Hujjat tuzilishini O'ZGARTIRMA — rasmiy shakl qat'iy
2. ANIQLADIM va QAROR QILDIM qismlari KATTA HARFLAR bilan yoziladi
3. ANIQLADIM qismida: voqea holati batafsil, dalillar, ekspertiza natijalari
4. QAROR QILDIM qismida: 4 ta band majburiy
5. JPK moddalari to'liq ko'rsatiladi: 15, 321, 322-modda "__"-bandi, 330-modda 1-bandi, 331, 336-moddalar, 345-modda __ qismi
6. JK modda: raqam, qism va band aniq ko'rsatiladi
7. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan):
- Sarlavha: "Jinoyat ishini qo'zg'atish haqida QAROR"
- Sana va hudud
- [Prokuror lavozimi, unvoni, F.I.Sh.] fuqaro [F.I.Sh.] ning noqonuniy harakatlari yuzasidan to'plangan materiallar bilan tanishib, quyidagilarni
- A N I Q L A D I M: [voqea batafsil, sana, joy, nima bo'lgani, qaysi organlar tekshirgani, ekspertiza natijalari]
- Mazur holatda jinoyat alomatlari mavjudligi hamda dastlabki tergov harakatlari o'tkazilishi majburiyligini inobatga olib, JPK 15, 321, 322-modda "__"-bandi, 330-modda 1-bandi, 331, 336-moddalar, 345-modda __ qismini qo'llab,
- Q A R O R   Q I L D I M:
  1. Fuqaro [F.I.Sh.] ga nisbatan JKning [modda]-moddasi [qism]-qismi bilan jinoyat ishi qo'zg'atilsin.
  2. Ish bo'yicha dastlabki tergovni olib borish [tergovchi lavozimi] [F.I.Sh.] ga topshirilsin.
  3. Qaror to'g'risida manfaatdor tomolarga ma'lum qilinib, JPK 338-moddasiga asosan yuqori turuvchi prokurorga shikoyat qilishga haqli ekanligi tushuntirilsin.
  4. Qaror nusxasi [prokuror] prokurorga yuborilsin.
- Imzo qismi: prokuratura nomi, lavozim, unvon, imzo, F.I.Sh.
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",   "label": "Prokuratura nomi (masalan: Mirobod tuman)",       "type": "text",     "required": True},
            {"id": "prokuror_lavozim",   "label": "Prokuror lavozimi (masalan: prokuror)",           "type": "text",     "required": True},
            {"id": "prokuror_unvon",     "label": "Prokuror unvoni (masalan: adliya maslahatchisi)", "type": "text",     "required": True},
            {"id": "prokuror_fio",       "label": "Prokuror F.I.Sh. (masalan: A.Ahmedov)",          "type": "text",     "required": True},
            {"id": "sana_yil",           "label": "Yil",                                            "type": "text",     "required": True},
            {"id": "sana_kun_oy",        "label": "Kun va oy (masalan: 25 sentyabr)",               "type": "text",     "required": True},
            {"id": "hudud",              "label": "Hudud (tuman/shahar)",                           "type": "text",     "required": True},
            {"id": "ayblanuvchi_fio",    "label": "Ayblanuvchi fuqaro F.I.Sh.",                     "type": "text",     "required": True},
            {"id": "jpk_322_band",       "label": "JPK 322-modda nechi-bandi (masalan: 4)",         "type": "text",     "required": True},
            {"id": "jpk_345_qism",       "label": "JPK 345-modda nechi-qismi (masalan: 1)",         "type": "text",     "required": True},
            {"id": "voqea_holati",       "label": "Voqea holati batafsil (sana, joy, nima bo'lgani, dalillar)", "type": "textarea", "required": True},
            {"id": "jk_modda",           "label": "JK modda raqami (masalan: 219)",                 "type": "text",     "required": True},
            {"id": "jk_qism",            "label": "JK modda qismi (masalan: 1)",                   "type": "text",     "required": True},
            {"id": "tergovchi_lavozim",  "label": "Tergovchiga topshirish — lavozimi",              "type": "text",     "required": True},
            {"id": "tergovchi_fio",      "label": "Tergovchiga topshirish — F.I.Sh.",               "type": "text",     "required": True},
            {"id": "yuqori_prokuror",    "label": "Yuqori prokuror (shikoyat uchun, masalan: tuman)", "type": "text",   "required": True},
        ],

        "shablon": """\
          Jinoyat ishini qo'zg'atish haqida
                     Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {prokuror_lavozim}i, {prokuror_unvon}
{prokuror_fio} fuqaro {ayblanuvchi_fio} ning noqonuniy xatti-harakatlari
yuzasidan to'plangan materiallar bilan tanishib, quyidagilarni

                        A N I Q L A D I M:

{voqea_holati}

    Mazkur holatda jinoyat alomatlari mavjudligi hamda dastlabki tergov
harakatlari o'tkazilishi majburiyligini inobatga olib, O'zbekiston
Respublikasi JPKning 15-moddasi, 321-moddasi, 322-moddasi {jpk_322_band}-bandi,
330-modda 1-bandi, 331, 336-moddalar, 345-moddasining {jpk_345_qism}-qismini
qo'llab,

                    Q A R O R   Q I L D I M:

    1. Fuqaro {ayblanuvchi_fio} ga nisbatan O'zbekiston Respublikasi
JKning {jk_modda}-modda {jk_qism}-qismi bilan jinoyat ishi qo'zg'atilsin.

    2. Ish bo'yicha dastlabki tergovni olib borish {prokuratura_nomi}
prokuraturasi {tergovchi_lavozim}i {tergovchi_fio} ga topshirilsin.

    3. Ushbu qaror to'g'risida manfaatdor tomolarga ma'lum qilinib,
O'zbekiston Respublikasi JPKning 338-moddasiga asosan qaror ustidan
{yuqori_prokuror} prokurorga shikoyat qilishga haqli ekanligi
tushuntirilsin.

    4. Qaror nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{prokuratura_nomi} prokuraturasi
{prokuror_lavozim}i
{prokuror_unvon}               (imzo)          {prokuror_fio}
"""
    },

    "JQ-F": {
        "harf": "f",
        "nomi": "Jinoyat ishi qo'zg'atilgani, shikoyat qilish huquqi va tartibi to'g'risida xabarnoma",
        "jpk": "JPK 338-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "XABARNOMA" hujjatini yozasan.

QOIDALAR:
1. Hujjat tuzilishini O'ZGARTIRMA
2. Yuqori qismda: kimga (manzil + F.I.Sh.) ko'rsatiladi
3. Mazmun: qachon, kim tomonidan, qaysi organ, qaysi modda bilan ish qo'zg'atilgani
4. Tergovga qadar tekshiruv harakatlari o'tkazilganligi qayd etiladi
5. JPK 338-modda bo'yicha shikoyat huquqi tushuntiriladi
6. Imzo qismi: prokuratura nomi, lavozim, unvon, imzo, F.I.Sh.
7. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Mirobod namunasi):
- Yuqorida: fuqaro to'liq manzili va F.I.Sh.ga
- Sarlavha: XABARNOMA
- [Prokuratura] tomonidam, [tergov organi] [shaxs F.I.Sh.] ning [voqea tavsifi] holati yuzasidan tergovga qadar tekshiruv harakatlari o'tkazildi.
- O'tkazilgan tekshiruv harakatlari natijasiga ko'ra, [prokuratura] tomonidan [sana] yilda Sizga nisbatan JKning [modda]-moddasi [qism]-qismi bilan jinoyat ishi qo'zg'atildi, dastlabki tergov harakatlari olib borilmoqda.
- Ushbu qarordan norozi bo'lsangiz, JPK 338-modasiga asosan qaror ustidan yuqori turuvchi prokurorga shikoyat qilish huquqiga ega ekanligingizni tushuntiraman.
- Imzo: prokuratura nomi, lavozim, unvon, imzo, F.I.Sh.
""",

        "maydonlar": [
            {"id": "qabul_qiluvchi_manzil", "label": "Kimga (fuqaro manzili to'liq)",                  "type": "textarea","required": True},
            {"id": "qabul_qiluvchi_fio",    "label": "Fuqaro F.I.Sh. (kimga yuborilmoqda)",            "type": "text",    "required": True},
            {"id": "prokuratura_nomi",       "label": "Prokuratura nomi (masalan: Mirobod tuman)",      "type": "text",    "required": True},
            {"id": "prokuror_lavozim",       "label": "Prokuror lavozimi",                             "type": "text",    "required": True},
            {"id": "prokuror_unvon",         "label": "Prokuror unvoni",                               "type": "text",    "required": True},
            {"id": "prokuror_fio",           "label": "Prokuror F.I.Sh.",                              "type": "text",    "required": True},
            {"id": "tergov_organ",           "label": "Tekshiruv o'tkazgan organ (masalan: Bosh prokuratura huzuridagi Majburiy ijro byurosining Mirobod tuman bo'limi)", "type": "text", "required": True},
            {"id": "shaxs_fio",              "label": "Tekshiruv o'tkazilgan shaxs F.I.Sh.",           "type": "text",    "required": True},
            {"id": "voqea_tavsifi",          "label": "Voqea tavsifi (qisqacha)",                      "type": "textarea","required": True},
            {"id": "qozgatish_sanasi",       "label": "Ish qo'zg'atilgan sana",                       "type": "text",    "required": True},
            {"id": "jk_modda",               "label": "JK modda raqami",                               "type": "text",    "required": True},
            {"id": "jk_qism",                "label": "JK modda qismi",                                "type": "text",    "required": True},
            {"id": "yuqori_prokuror",        "label": "Yuqori turuvchi prokuror (masalan: yuqori turuvchi)", "type": "text", "required": True},
        ],

        "shablon": """\
                         {qabul_qiluvchi_manzil}
                         {qabul_qiluvchi_fio}ga


                          XABARNOMA

    {prokuratura_nomi} prokuraturasi tomonidan, {tergov_organ}
{shaxs_fio} ning {voqea_tavsifi} holati yuzasidan tergovga qadar
tekshiruv harakatlari o'tkazildi.
    O'tkazilgan tergovga qadar tekshiruv harakatlari natijasiga ko'ra,
{prokuratura_nomi} prokuraturasi tomonidan {qozgatish_sanasi} yilda
Sizga nisbatan O'zbekiston Respublikasi JKning {jk_modda}-moddasi
{jk_qism}-qismi bilan jinoyat ishi qo'zg'atildi, dastlabki tergov
harakatlari olib borilmoqda.
    Ushbu qarordan norozi bo'lsangiz, O'zbekiston Respublikasi
JPKning 338-modasiga asosan qaror ustidan {yuqori_prokuror} prokurorga
shikoyat qilish huquqiga ega ekanligingizni tushuntiraman.

{prokuratura_nomi} prokuraturasi
{prokuror_lavozim}i
{prokuror_unvon}               (imzo)          {prokuror_fio}
"""
    },

    "JQ-G": {
        "harf": "g",
        "nomi": "Jinoyat ishini qo'zg'atish va ish yurituviga olish haqida qaror",
        "jpk": "JPK 15, 36, 321, 322, 330, 331, 336, 345, 350-moddalar",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atish va ish yurituviga olish haqida QAROR" hujjatini yozasan.

QOIDALAR:
1. Bu JQ-E dan farqi: tergovchi o'zi ish yurituviga oladi (prokuraturaga topshirmaydi)
2. ANIQLADIM va QAROR QILDIM katta harflar bilan
3. QAROR QILDIM da 4 ta band: 1) jinoyat ishi qo'zg'atilsin 2) ish yurituvga olib, tergov harakatlari boshlansin 3) shikoyat huquqi tushuntirilsin 4) qaror nusxasi prokurorga yuborilsin
4. JPK: 15, 36, 321, 322-"__"-bandi, 330-modda 1-bandi, 331, 336, 345, 350-moddalar
5. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Chilonzor namunasi):
- Sarlavha: "Jinoyat ishini qo'zg'atish va ish yurituviga olish haqida QAROR"
- Sana, hudud
- [Prokuratura] tergovchisi, [unvon] [F.I.Sh.] fuqaro [F.I.Sh.] ning [voqea] holati yuzasidan to'plangan hujjatlar bilan tanishib, quyidagilarni
- A N I Q L A D I M: [voqea batafsil]
- JPK moddalari ro'yxati (15, 36, 321, 322-"__"-band, 330-1-band, 331, 336, 345, 350) ni qo'llab
- Q A R O R   Q I L D I M: 4 band
- Prokuratura nomi, lavozim, unvon, imzo, F.I.Sh.
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi (masalan: Chilonzor tuman)",      "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni (masalan: 1-darajali yurist)",   "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "sana_yil",          "label": "Yil",                                             "type": "text",     "required": True},
            {"id": "sana_kun_oy",       "label": "Kun va oy",                                       "type": "text",     "required": True},
            {"id": "hudud",             "label": "Hudud",                                           "type": "text",     "required": True},
            {"id": "ayblanuvchi_fio",   "label": "Ayblanuvchi fuqaro F.I.Sh.",                      "type": "text",     "required": True},
            {"id": "voqea_holati",      "label": "Voqea holati batafsil",                           "type": "textarea", "required": True},
            {"id": "jpk_322_band",      "label": "JPK 322-modda nechi-bandi",                       "type": "text",     "required": True},
            {"id": "jk_modda",          "label": "JK modda raqami",                                 "type": "text",     "required": True},
            {"id": "jk_qism",           "label": "JK modda qismi",                                  "type": "text",     "required": True},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror (masalan: tuman)",                "type": "text",     "required": True},
        ],

        "shablon": """\
     Jinoyat ishini qo'zg'atish va ish yurituviga olish haqida
                          Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} fuqaro {ayblanuvchi_fio} ning holati yuzasidan to'plangan
hujjatlar bilan tanishib, quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    Ushbu hodisada jinoyat alomatlari mavjudligini va bunday holatda
dastlabki tergov o'tkazish majburiy ekanligini nazarda tutib,
O'zbekiston Respublikasi JPKning 15, 36, 321, 322-moddasi
{jpk_322_band}-bandi, 330-modda 1-bandi, 331, 336, 345 va
350-moddalarini qo'llab,

                  Q A R O R   Q I L D I M:

    1. {ayblanuvchi_fio} ga nisbatan O'zbekiston Respublikasi
JKning {jk_modda}-moddasi {jk_qism}-qismi bilan jinoyat ishi
qo'zg'atilsin.

    2. Mazkur jinoyat ishini ish yurituvga olib, dastlabki tergov
harakatlari olib borishga kirishilsin.

    3. Ushbu qaror to'g'risida manfaatdor tomolarga ma'lum qilinib,
O'zbekiston Respublikasi JPKning 338-modasiga asosan qaror ustidan
{yuqori_prokuror} prokurorga shikoyat qilishga haqli ekanligi
tushuntirilsin.

    4. Qarorning nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}
"""
    },

    "JQ-H": {
        "harf": "h",
        "nomi": "Jinoyat ishini qo'zg'atish va dastlabki tergovni tergovchilar guruhiga topshirish haqida qaror",
        "jpk": "JPK 15, 321, 322, 330, 331, 336, 345, 350, 354, 382-moddalar",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atish va dastlabki tergovni tergovchilar guruhiga topshirish haqida QAROR" hujjatini yozasan.

QOIDALAR:
1. Bu hujjat JQ-G dan farqi: tergovni guruhga topshiriladi
2. ANIQLADIM qismida: jinoyat murakkabligi, ko'p mehnat talab etishi asoslanadi
3. QAROR QILDIM da 5 ta band: 1) jinoyat ishi qo'zg'atilsin + JK modda 2) guruh tarkibi (rahbar + a'zolar) 3) ish yurituvga olish va guruh rahbarligiga topshirish 4) shikoyat huquqi 5) qaror nusxasi prokurorga
4. JPK: 15, 321, 322-"__"-bandi, 330-1-bandi, 331, 336, 345, 350, 354, 382-moddalar
5. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Namangan viloyat namunasi):
- Sarlavha: "Jinoyat ishini qo'zg'atish va dastlabki tergovni tergovchilar guruhiga topshirish haqida QAROR"
- Sana, hudud
- [Bo'lim nomi] [lavozim] [F.I.Sh.] fuqaro [F.I.Sh.] ning vafot etganligi holati bo'yicha to'plangan hujjatlar bilan tanishib...
- A N I Q L A D I M: [voqea batafsil + murakkablik asoslash]
- JPK moddalari
- Q A R O R   Q I L D I M: 5 band
  Band 2: Jinoyat ishi bo'yicha [rahbar lavozimi] [rahbar F.I.Sh.] rahbarligidagi va a'zolari [a'zo lavozimi] [a'zo F.I.Sh.] lardan iborat tarkibda tergov guruhi tuzilsin
  Band 3: Jinoyat ishini o'z ish yurituviga olish tergov guruhi rahbari [F.I.Sh.] ga topshirilsin
- Imzo qismi
""",

        "maydonlar": [
            {"id": "bolim_nomi",        "label": "Bo'lim nomi (masalan: Namanagan viloyat prokuraturasining o'ta og'ir jinoyatlarni tergov qilish bo'limi)", "type": "text", "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi (masalan: boshlig'i)",            "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni (masalan: adliya maslahatchisi)",   "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                                  "type": "text",     "required": True},
            {"id": "sana_yil",          "label": "Yil",                                                "type": "text",     "required": True},
            {"id": "sana_kun_oy",       "label": "Kun va oy",                                          "type": "text",     "required": True},
            {"id": "hudud",             "label": "Hudud",                                              "type": "text",     "required": True},
            {"id": "ayblanuvchi_fio",   "label": "Ayblanuvchi/jabrlanuvchi fuqaro F.I.Sh.",            "type": "text",     "required": True},
            {"id": "voqea_holati",      "label": "Voqea holati batafsil (murakkablikni asoslab)",      "type": "textarea", "required": True},
            {"id": "jpk_322_band",      "label": "JPK 322-modda nechi-bandi",                          "type": "text",     "required": True},
            {"id": "jk_modda",          "label": "JK modda raqami",                                    "type": "text",     "required": True},
            {"id": "jk_qism",           "label": "JK modda qismi",                                     "type": "text",     "required": True},
            {"id": "jk_band",           "label": "JK modda bandi (masalan: a,j yoki i)",               "type": "text",     "required": False},
            {"id": "guruh_rahbar_lavozim","label": "Guruh rahbari lavozimi",                           "type": "text",     "required": True},
            {"id": "guruh_rahbar_fio",  "label": "Guruh rahbari F.I.Sh.",                              "type": "text",     "required": True},
            {"id": "guruh_azolari",     "label": "Guruh a'zolari (lavozim va F.I.Sh., vergul bilan)", "type": "textarea", "required": True},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror (masalan: viloyat)",                 "type": "text",     "required": True},
        ],

        "shablon": """\
  Jinoyat ishini qo'zg'atish va dastlabki tergovni
    tergovchilar guruhiga topshirish haqida
                    Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {bolim_nomi} {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} fuqaro {ayblanuvchi_fio} ning holati bo'yicha
to'plangan hujjatlar bilan tanishib, quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    Mazkur hodisada jinoyat alomatlari mavjudligini va bunday holatda
dastlabki tergov o'tkazish majburiy ekanligini, jinoyat ishi tergovini
ko'p mehnat talab etishi, murakkabligini e'tiborga olgan holda, jinoyat
ishi qo'zg'atib, tergov harakatlari olib borish hamda jinoyat ishi
yuzasidan malakali hodimlardan iborat tergov guruhi tuzish lozim bo'ladi.
    Binobarin, O'zbekiston Respublikasi JPKning 15, 321, 322-moddasi
{jpk_322_band}-bandi, 330-modda 1-bandi, 331, 336, 345, 350, 354 va
382-moddalarini qo'llab,

                  Q A R O R   Q I L D I M:

    1. Mazkur holat yuzasidan O'zbekiston Respublikasi JKning
{jk_modda}-moddasi {jk_qism}-qismi "{jk_band}" bandi bilan jinoyat
ishi qo'zg'atilsin.

    2. Jinoyat ishi bo'yicha {guruh_rahbar_lavozim}i {guruh_rahbar_fio}
rahbarligidagi va a'zolari {guruh_azolari} lardan iborat tarkibda
tergov guruhi tuzilsin.

    3. Jinoyat ishini o'z ish yurituviga olish tergov guruhi rahbari
{guruh_rahbar_fio} ga topshirilsin.

    4. Mазkur qaror to'g'risida manfaatdor tomolarga ma'lum qilinib,
O'zbekiston Respublikasi JPKning 338-modasiga asosan qaror ustidan
{yuqori_prokuror} prokurorga shikoyat qilishga haqli ekanligi
tushuntirilsin.

    5. Qarorning nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{bolim_nomi}
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}
"""
    },

    "JQ-I": {
        "harf": "i",
        "nomi": "Jinoyat ishini qo'zg'atish, ish yurituvga olish, shaxsni gumon qilinuvchi tariqasida jalb qilish va ushlab turish haqida qaror",
        "jpk": "JPK 15, 220, 221, 321, 322, 331, 336, 350, 359, 360-moddalar",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atish, ish yurituvga olish, shaxsni gumon qilinuvchi tariqasida ishda ishtirok etish uchun jalb qilish va ushlab turish to'g'risida QAROR" hujjatini yozasan.

QOIDALAR:
1. Bu eng murakkab qaror — 4 ta harakatni birlashtiradi
2. ANIQLADIM: voqea batafsil + gumон qilish asoslari + JK modda va qism
3. JPK: 220, 221-moddasi "__"-bandi, 15, 321, 331, 336, 350, 359 va 360-moddalar
4. QAROR QILDIM da 6 ta band:
   1) jinoyat ishi qo'zg'atilsin + JK modda
   2) ish yurituvga olib, tergov harakatlari boshlansin
   3) gumon qilinuvchi [F.I.Sh., tug'ilgan sanasi, manzil] ni gumон qilinuvchi tariqasida jalb qilish + JK modda
   4) Qaror e'lon qilinib, JPK 48-modda (gumон qilinuvchi huquqlari) va 229-modda (ushlab turish huquqlari) tushuntirilsin
   5) Qaror nusxasi ushlab turish chorasi uchun IIB boshlig'iga yuborilsin
   6) Qaror nusxasi prokurorga yuborilsin
5. Oxirida: "Ushbu qaror menga 20__ yil __ da e'lon qilindi hamda JPK 48-moddasi va 229-moddasidagi gumон qilinuvchi va ushlab turuluvchining huquq va majburiyatlari, shuningdek, qaror ustidan __ prokurorga shikoyat qilishga haqliligim tushuntirildi. Gumон qilinuvchi: (imzo) F.I.Sh. / Himoyachi: (imzo) F.I.Sh."
6. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Mirobod namunasi, A.Valiev):
- Sarlavha: to'liq nom (qo'zg'atish + ish yurituvga olish + jalb qilish + ushlab turish)
- Sana, hudud
- ANIQLADIM: voqea batafsil
- JPK 220, 221-"__"-bandi, 15, 321, 331, 336, 350, 359 va 360-moddalar
- QAROR QILDIM: 6 band
- Imzo: prokuratura, lavozim, unvon
- Pastda: gumон qilinuvchi va himoyachi imzolari
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",   "label": "Prokuratura nomi (masalan: Mirobod tuman)",       "type": "text",     "required": True},
            {"id": "tergovchi_lavozim",  "label": "Tergovchi lavozimi",                             "type": "text",     "required": True},
            {"id": "tergovchi_unvon",    "label": "Tergovchi unvoni (masalan: 1-darajali yurist)",  "type": "text",     "required": True},
            {"id": "tergovchi_fio",      "label": "Tergovchi F.I.Sh.",                              "type": "text",     "required": True},
            {"id": "sana_yil",           "label": "Yil",                                            "type": "text",     "required": True},
            {"id": "sana_kun_oy",        "label": "Kun va oy",                                      "type": "text",     "required": True},
            {"id": "hudud",              "label": "Hudud",                                          "type": "text",     "required": True},
            {"id": "gumon_fio",          "label": "Gumon qilinuvchi F.I.Sh.",                       "type": "text",     "required": True},
            {"id": "gumon_tugilgan",     "label": "Tug'ilgan sanasi va joyi",                       "type": "text",     "required": True},
            {"id": "gumon_manzil",       "label": "Yashash manzili",                                "type": "text",     "required": True},
            {"id": "voqea_holati",       "label": "Voqea holati batafsil (gumон asoslari bilan)",   "type": "textarea", "required": True},
            {"id": "jpk_221_band",       "label": "JPK 221-modda nechi-bandi (masalan: 2,3)",       "type": "text",     "required": True},
            {"id": "jk_modda",           "label": "JK modda raqami",                                "type": "text",     "required": True},
            {"id": "jk_qism",            "label": "JK modda qismi",                                 "type": "text",     "required": True},
            {"id": "jk_band",            "label": "JK modda bandi (masalan: a,j)",                  "type": "text",     "required": False},
            {"id": "yuqori_prokuror",    "label": "Yuqori prokuror (masalan: tuman)",               "type": "text",     "required": True},
            {"id": "himoyachi_fio",      "label": "Himoyachi F.I.Sh. (agar mavjud bo'lsa)",         "type": "text",     "required": False},
        ],

        "shablon": """\
  Jinoyat ishini qo'zg'atish, ish yurituvga olish, shaxsni
  gumon qilinuvchi tariqasida ishda ishtirок etish uchun
         jalb qilish va ushlab turish to'g'risida
                          Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} fuqarolar ning holati bo'yicha to'plangan materiallar
bilan tanishib, quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    Binobarin, O'zbekiston Respublikasi JPKning 220-moddasi,
221-moddasi {jpk_221_band}-bandlari, 15, 321, 331, 336, 350, 359 va
360-moddalarini qo'llab,

                  Q A R O R   Q I L D I M:

    1. Mazkur holat yuzasidan O'zbekiston Respublikasi JKning
{jk_modda}-moddasi {jk_qism}-qismi "{jk_band}" bandlari bilan jinoyat
ishi qo'zg'atilsin.

    2. Mazkur jinoyat ishini ish yurituvga olib, dastlabki tergov
harakatlari olib borishga kirishilsin.

    3. Ushbu jinoyat ishi bo'yicha {gumon_tugilgan} yilda tug'ilgan,
{gumon_manzil} da yashоvchi {gumon_fio} ni O'zbekiston Respublikasi
JKning {jk_modda}-moddasi {jk_qism}-qismi "{jk_band}" bandlarida
nazarda tutilgan jinoyatni sodir etganlikda gumон qilinuvchi tariqasida
ishda ishtirок etish uchun jalb qilinsin va unga majburlov chorasi —
ushlab turish qo'llanilsin.

    4. Mазkur qaror {gumon_fio} ga e'lon qilinib, unga gumон
qilinuvchining huquq va majburiyatlari hamda qaror ustidan
{yuqori_prokuror} prokurorga shikoyat qilishga haqli ekanligi
tushuntirilsin.

    5. Qarorning nusxasi ushlab turish chorasini ijro etish uchun
tuman IIB boshlig'iga yuborilsin.

    6. Qarorning nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}

──────────────────────────────────────────────────────────────
    Ushbu qaror menga 20__ yil "___" ___________ da e'lon
qilindi hamda O'zbekiston Respublikasi JPKning 48-moddasi dagi
gumон qilinuvchining va 229-moddasi dagi ushlab turuluvchining
huquq va majburiyatlari, shuningdek, qaror ustidan {yuqori_prokuror}
prokurorga shikoyat qilishga haqliligim tushuntirildi.

Gumон qilinuvchi:    ________________ {gumon_fio}
                          (imzo)

Himoyachi:           ________________ {himoyachi_fio}
                          (imzo)
"""
    },
}
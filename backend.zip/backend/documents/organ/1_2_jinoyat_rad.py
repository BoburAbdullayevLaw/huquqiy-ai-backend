"""
1.2 bo'lim — Jinoyat ishini qo'zg'atishni rad qilish
"""

HUJJATLAR = {
    "JR-A": {
        "harf": "a",
        "nomi": "Jinoyat ishini qo'zg'atishni rad qilish haqida qaror",
        "jpk": "JPK 83-modda, 330-modda 2-bandi, 333-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atishni rad qilish haqida QAROR" hujjatini yozasan.

QOIDALAR:
1. ANIQLADIM va QAROR QILDIM katta harflar bilan
2. ANIQLADIM: voqea batafsil + tekshiruv harakatlari + rad qilish sababi
3. JPK 83-moddasi "___"-bandida nazarda tutilgan holatlar aniqlanganligini nazarda tutib va JPK 330-moddasi 2-bandi va 333-moddasi ni qo'llab
4. QAROR QILDIM da 4 ta band:
   1) [holat] sababli jinoyat ishi qo'zg'atish rad qilinsin
   2) Rad etilganligi va rad sabablari to'g'risida [F.I.Sh.] ga ma'lum qilinib, JPK 333-modasiga asosan qaror ustidan [prokuror]ga shikoyat qilishga haqli ekanligi tushuntirilsin
   3) Hodisa joyidan olingan va prokuraturada saqlanayotgan [narsalar tavsifi] [F.I.Sh.] ga qaytarib berilsin (yoki: materiallar boshqa organga yuborilsin)
   4) Qarorning nusxasi [prokuror]ga yuborilsin
5. Oxirida: "Ushbu qaror menga 20__ yil "___" ___ da e'lon qilindi. Qaror ustidan ___ prokurorga shikoyat qilishga haqli ekanligim tushuntirildi. (imzo) F.I.Sh."
6. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Mirobod namunasi, Zh.Javlonov):
- Sarlavha: "Jinoyat ishini qo'zg'atishni rad qilish haqida QAROR"
- Sana, hudud
- [Prokuratura] tergovchisi, [unvon] [F.I.Sh.] fuqaro [F.I.Sh.] ning [voqea] holati bo'yicha to'plangan materiallar bilan tanishib
- ANIQLADIM: voqea batafsil, tekshiruv harakatlari, ekspertiza natijalari, rad sababi
- JPK 83-modda __-bandi + 330-modda 2-bandi + 333-modda
- QAROR QILDIM: 4 band
- Imzo: prokuratura, lavozim, unvon
- Pastda: e'lon qilinishi va imzo
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi (masalan: Mirobod tuman)",       "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni (masalan: 1-darajali yurist)",   "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "sana_yil",          "label": "Yil",                                             "type": "text",     "required": True},
            {"id": "sana_kun_oy",       "label": "Kun va oy",                                       "type": "text",     "required": True},
            {"id": "hudud",             "label": "Hudud",                                           "type": "text",     "required": True},
            {"id": "shaxs_fio",         "label": "Tekshiruv o'tkazilgan fuqaro/hodisa F.I.Sh.",     "type": "text",     "required": True},
            {"id": "voqea_holati",      "label": "Voqea holati batafsil (rad sabablari bilan)",     "type": "textarea", "required": True},
            {"id": "jpk_83_band",       "label": "JPK 83-modda nechi-bandi (masalan: 1)",           "type": "text",     "required": True},
            {"id": "rad_sababi",        "label": "Rad qilish sababi qisqacha (masalan: jinoyat tarkibi yo'q)", "type": "text", "required": True},
            {"id": "xabardor_fio",      "label": "Kimga ma'lum qilinsin (F.I.Sh. yoki tashkilot)", "type": "text",     "required": True},
            {"id": "qaytarish_narsalar","label": "Qaytariladigan narsalar (agar bo'lsa)",           "type": "text",     "required": False},
            {"id": "qaytarish_kimga",   "label": "Narsalar kimga qaytarilsin",                      "type": "text",     "required": False},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror (masalan: tuman)",                "type": "text",     "required": True},
        ],

        "shablon": """\
     Jinoyat ishini qo'zg'atishni rad qilish haqida
                       Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} fuqaro {shaxs_fio} ning holati bo'yicha to'plangan
materiallar bilan tanishib, quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    Binobarin, O'zbekiston Respublikasi JPKning 83-moddasi
{jpk_83_band}-bandida nazarda tutilgan holatlar aniqlanganligini
nazarda tutib va O'zbekiston Respublikasi JPK 330-moddasi 2-bandi
va 333-moddасини qo'llab,

                  Q A R O R   Q I L D I M:

    1. {shaxs_fio} ning holati yuzasidan {rad_sababi}
sababli jinoyat ishini qo'zg'atish rad qilinsin.

    2. Jinoyat ishini qo'zg'atish rad qilinganligi va rad qilish
asoslari to'g'risida {xabardor_fio} ga ma'lum qilinib, unga
O'zbekiston Respublikasi JPKning 333-modasiga asosan ushbu qaror
ustidan {yuqori_prokuror} prokurorga shikoyat qilishga haqli
ekanligi tushuntirilsin.

    3. Hodisa joyidan olingan va prokuraturada saqlanayotgan
{qaytarish_narsalar} {qaytarish_kimga} ga qaytarib berilsin.

    4. Qarorning nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}

──────────────────────────────────────────────────────────────
    Ushbu qaror menga 20__ yil "___" ___________ da e'lon
qilindi. Qaror ustidan {yuqori_prokuror} prokurorga shikoyat
qilishga haqli ekanligim tushuntirildi.

                                   ________________ (F.I.Sh.)
                                        (imzo)
"""
    },

    "JR-B": {
        "harf": "b",
        "nomi": "Jinoyat ishi qo'zg'atish rad etilganligi to'g'risidagi xabarnoma",
        "jpk": "JPK 333-modda, 83-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. Rad etish haqidagi "XABARNOMA" hujjatini yozasan.

QOIDALAR:
1. Hujjat qisqa va rasmiy
2. Yuqorida: fuqaro manzili va F.I.Sh.
3. Mazmun: ariza/xabar yuzasidan tekshiruv o'tkazilgani, natijada JPK 83-modda __-bandiga asosan rad qilinganligi
4. JPK 333-modasiga asosan shikoyat huquqi tushuntiriladi
5. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Mirobod, V.Aliev namunasi):
- Yuqorida: fuqaro to'liq manzili va F.I.Sh. ga
- XABARNOMA sarlavhasi
- Sizning [ariza/xabar] yuzasidan [prokuratura] tomonidan tergovga qadar tekshiruv harakatlari o'tkazildi.
- O'tkazilgan tekshiruv harakatlari natijasiga ko'ra, [kimning] harakatlarida jinoyat tarkibi mavjud emasligi sababli, JPK 83-moddasi __-bandiga asosan jinoyat ishi qo'zg'atish rad qilindi.
- Sizga, JPK 333-modasiga asosan, tergovga qadar tekshiruv harakatlari yakunidan norozi bo'lsangiz, jinoyat ishi qo'zg'atishning rad qilinganl to'g'risidagi qaror ustidan [prokuror] prokurorga shikoyat qilishga haqli ekanligingizni ma'lum qilaman.
- Imzo: prokuratura, lavozim, unvon, imzo, F.I.Sh.
""",

        "maydonlar": [
            {"id": "qabul_manzil",      "label": "Kimga (fuqaro to'liq manzili)",                   "type": "textarea", "required": True},
            {"id": "qabul_fio",         "label": "Fuqaro F.I.Sh.",                                  "type": "text",     "required": True},
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi (masalan: Mirobod tuman)",       "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "ariza_tavsifi",     "label": "Ariza/xabar tavsifi (masalan: Davlat solik inspeksiyasi hodimlarining harakatlaridan norozi bo'lib yozgan arizangiz)", "type": "textarea", "required": True},
            {"id": "tekshirilgan_shaxs","label": "Tekshirilgan shaxs/tashkilot",                   "type": "text",     "required": True},
            {"id": "jpk_83_band",       "label": "JPK 83-modda nechi-bandi",                        "type": "text",     "required": True},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror (masalan: Mirobod tuman)",        "type": "text",     "required": True},
        ],

        "shablon": """\
                    {qabul_manzil}
                    {qabul_fio}ga


                        X A B A R N O M A

    Sizning {ariza_tavsifi} yuzasidan {prokuratura_nomi}
prokuraturasi tomonidan tergovga qadar tekshiruv harakatlari
o'tkazildi.
    O'tkazilgan tergovga qadar tekshiruv harakatlari natijasiga
ko'ra, {tekshirilgan_shaxs} ning harakatlarida jinoyat taркibi
mavjud emasligi sababli, O'zbekiston Respublikasi JPKning
83-moddasi {jpk_83_band}-bandiga asosan jinoyat ishi qo'zg'atish
rad qilindi.
    Sizga, O'zbekiston Respublikasi JPKning 333-modasiga asosan,
tergovga qadar tekshiruv harakatlari yakunidan norozi bo'lsangiz,
jinoyat ishi qo'zg'atishning rad qilinganl to'g'risidagi qaror
ustidan {yuqori_prokuror} prokurorga shikoyat qilishga haqli
ekanligingizni ma'lum qilaman.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}
"""
    },

    "JR-C": {
        "harf": "c",
        "nomi": "OAV tomonidan e'lon qilingan jinoyat haqidagi xabar yuzasidan o'tkazilgan tekshiruv natijasiga ko'ra jinoyat ishini qo'zg'atish rad qilinganligi to'g'risidagi xabarni matbuotda e'lon qilish yuzasidan talabnoma",
        "jpk": "JPK 83-modda, 309-modda, 333-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. OAV ga rad etilganligi haqidagi "TALABNOMA" hujjatini yozasan.

QOIDALAR:
1. Bu hujjat faqat OAV tomonidan e'lon qilingan xabar yuzasidan tekshiruv o'tkazilganda yoziladi
2. Yuqori o'ngda: OAV nomi, yuridik manzili, bosh muharrir F.I.Sh.
3. Sarlavha ko'p qatorli — to'liq yoziladi
4. Mazmun: prokuratura tomonidan OAV da chop etilgan maqola yuzasidan tergovga qadar tekshiruv o'tkazildi, natijada jinoyat tarkibi yo'q deb rad qilindi, qaror haqida gazetada maqola chop etishni ta'minlash so'raladi
5. ESLATMA qismi: JPK 309-modda matni — kursiv va qalin — majburiy
6. Hujjat matnini *** va *** orasiga ol

TUZILISH (rasmdan - Xalq so'zi namunasi):
- Yuqori o'ng: OAV nomi, yuridik manzili, bosh muharrir F.I.Sh.ga
- Sarlavha: "Oommaviy axborot vositasi tomonidan e'lon qilingan jinoyat haqidagi xabar yuzasidan o'tkazilgan tekshiruv natijasiga ko'ra jinoyat ishini qo'zg'atish rad qilinganligi to'g'risidagi xabarni matbuotda e'lon qilish yuzasidan TALABNOMA"
- [Prokuratura] tomonidan "[OAV nomi]" ning [sana] yildagi [son]-sonli raqamida "[maqola sarlavhasi]" nomli sarlavha bilan [mavzu] haqida chop etilgan maqola yuzasidan tergovga qadar tekshiruv harakatlari o'tkazildi.
- O'tkazilgan tekshiruv harakatlari natijasiga ko'ra, [tekshirilgan shaxs/tashkilot] ning harakatlarida [rad sababi] sababli JPK 83-moddasining __-bandiga asosan jinoyat ishi qo'zg'atish rad qilindi.
- Yuqoridagilarga asosan, mazkur qabul qilingan qaror haqida gazetada maqola chop etilishini ta'minlashingizni so'rayman.
- ESLATMA: JPK 309-modda matni (qalin-kursiv)
- Imzo: prokuratura, lavozim, unvon, imzo, F.I.Sh.
""",

        "maydonlar": [
            {"id": "oav_nomi",          "label": "OAV nomi (masalan: Xalq so'zi gazetasi)",          "type": "text",     "required": True},
            {"id": "oav_manzil",        "label": "OAV yuridik manzili",                              "type": "text",     "required": False},
            {"id": "oav_muharrir",      "label": "Bosh muharrir F.I.Sh.",                            "type": "text",     "required": True},
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi (masalan: Mirobod tuman)",        "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                               "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                 "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                                "type": "text",     "required": True},
            {"id": "nashr_sanasi",      "label": "Maqola nashr sanasi (masalan: 30.11.2017)",        "type": "text",     "required": True},
            {"id": "nashr_soni",        "label": "Son/raqami (masalan: 64 (6758))",                  "type": "text",     "required": False},
            {"id": "maqola_sarlavha",   "label": "Maqola sarlavhasi",                                "type": "text",     "required": True},
            {"id": "maqola_mavzu",      "label": "Maqola mavzusi (qaysi organ/shaxs haqida)",        "type": "textarea", "required": True},
            {"id": "tekshirilgan",      "label": "Tekshirilgan shaxs/tashkilot",                     "type": "text",     "required": True},
            {"id": "rad_sababi",        "label": "Rad sababi (masalan: jinoyat tarkibi mavjud emas)", "type": "text",    "required": True},
            {"id": "jpk_83_band",       "label": "JPK 83-modda nechi-bandi",                         "type": "text",     "required": True},
        ],

        "shablon": """\
                    {oav_nomi}
                    {oav_manzil}
                    {oav_muharrir}ga


    Оmmaviy axborot vositasi tomonidan e'lon qilingan jinoyat
    haqidagi xabar yuzasidan o'tkazilgan tekshiruv natijasiga ko'ra
    jinoyat ishini qo'zg'atish rad qilinganligi to'g'risidagi
      xabarni matbuotda e'lon qilish yuzasidan
                     T A L A B N O M A

    {prokuratura_nomi} prokuraturasi tomonidan "{oav_nomi}" ning
{nashr_sanasi} yildagi {nashr_soni}-sonli raqamida "{maqola_sarlavha}"
nomli sarlavha bilan {maqola_mavzu} haqida chop etilgan maqola
yuzasidan tergovga qadar tekshiruv harakatlari o'tkazildi.
    O'tkazilgan tergovga qadar tekshiruv harakatlari natijasiga
ko'ra, {tekshirilgan} ning harakatlarida {rad_sababi} sababli
O'zbekiston Respublikasi JPKning 83-moddasi {jpk_83_band}-bandiga
asosan jinoyat ishi qo'zg'atish rad qilindi.
    Yuqoridagilarga asosan, mazkur qabul qilingan qaror haqida
gazetada maqola chop etilishini ta'minlashingizni so'rayman.

                          ESLATMA

    O'zbekiston Respublikasi JPKning 309-modda talablariga ko'ra,
sodir bo'layotgan qo'pol qonun buzilishlar haqida chop etilgan
maqola yuzasidan qabul qilingan qaror haqida tegishli oommaviy
axborot vositalari bir oy ichida xabar berishlari shart.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}
"""
    },
    "JR-D": {
        "harf": "d",
        "nomi": "Jinoyat ishini qo'zg'atishni rad qilish haqida qaror (huquq buzilishi, JPK 334-modda)",
        "jpk": "JPK 83-modda, 330-modda 2-bandi, 333, 334-moddalar",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atishni rad qilish haqida QAROR" hujjatini yozasan.
Bu holat — fuqaro huquqlari buzilganligi (mehnat, uy-joy, oilaviy) yoki tashkilot manfaatlari buzilganligi, lekin jinoiy tarkib yo'q.

QOIDALAR:
1. JPK 83-moddasi "___"-bandi, 330-modda 2-bandi, 333 va 334-moddalar
2. QAROR QILDIM da 5 ta band:
   1) rad qilinsin — sabab ko'rsatib
   2) Fuqaro [kimi, qanday huquqbuzarlik] to'g'risidagi materiallar [qanday chora] ko'rish uchun [qaerga, kimga] yuborilsin
   3) Rad qilinganligi va asoslari to'g'risida [kimga] ma'lum qilinib, JPK 333-modda + shikoyat huquqi tushuntirilsin
   4) [Qaerdan, kimdan] olingan va [qaerda] saqlanayotgan [narsalar/hujjatlar] ga nisbatan ko'riladigan choralar
   5) Qaror nusxasi prokurorga yuborilsin
3. Pastki izoh: JPK 344-modda yoki 334-modda matni (kimga yuborilishi haqida)
4. Hujjat matnini *** va *** orasiga ol
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi",                                "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "sana_yil",          "label": "Yil",                                             "type": "text",     "required": True},
            {"id": "sana_kun_oy",       "label": "Kun va oy",                                       "type": "text",     "required": True},
            {"id": "hudud",             "label": "Hudud",                                           "type": "text",     "required": True},
            {"id": "voqea_holati",      "label": "Voqea holati batafsil",                           "type": "textarea", "required": True},
            {"id": "jpk_83_band",       "label": "JPK 83-modda nechi-bandi",                        "type": "text",     "required": True},
            {"id": "rad_sababi",        "label": "Rad sababi qisqacha",                             "type": "text",     "required": True},
            {"id": "fuqaro_kim",        "label": "Kimning harakati tekshirildi (fuqaro/tashkilot)", "type": "text",     "required": True},
            {"id": "huquqbuzarlik",     "label": "Qanday huquqbuzarlik (mehnat, uy-joy va h.k)",   "type": "text",     "required": True},
            {"id": "yuborish_chora",    "label": "Qanday chora ko'rish uchun yuborilsin",           "type": "text",     "required": True},
            {"id": "yuborish_qaer",     "label": "Qaerga/kimga yuborilsin",                         "type": "text",     "required": True},
            {"id": "xabardor_fio",      "label": "Kimga ma'lum qilinsin",                           "type": "text",     "required": True},
            {"id": "qaytarish_narsalar","label": "Qaytariladigan narsalar/hujjatlar",               "type": "text",     "required": False},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror",                                 "type": "text",     "required": True},
        ],

        "shablon": """\
     Jinoyat ishini qo'zg'atishni rad qilish haqida
                       Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} holat bo'yicha to'plangan materiallar bilan tanishib,
quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    Binobarin, O'zbekiston Respublikasi JPKning 83-moddasi
"{jpk_83_band}"-bandi, 330-moddasi 2-bandi, 333 va 334-moddalarini
qo'llab

                  Q A R O R   Q I L D I M:

    1. {rad_sababi} sababli jinoyat ishini qo'zg'atish rad qilinsin.

    2. Fuqaro {fuqaro_kim} ning {huquqbuzarlik} to'g'risidagi
materiallar {yuborish_chora} ko'rish uchun {yuborish_qaer} ga
yuborilsin.

    3. Jinoyat ishini qo'zg'atishning rad qilinganl va rad qilish
asoslari to'g'risida {xabardor_fio} ga ma'lum qilinib, unga
O'zbekiston Respublikasi JPK 333-modasiga asosan ushbu qaror
ustidan {yuqori_prokuror} prokurorga shikoyat qilishga haqli
ekanligi tushuntirilsin.

    4. {qaytarish_narsalar} ga nisbatan ko'riladigan choralar
belgilansin.

    5. Qarorning nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}

──────────────────────────────────────────────────────────────
    Ushbu qaror menga 20__ yil "___" ___________ da e'lon
qilindi. Qaror ustidan {yuqori_prokuror} prokurorga shikoyat
qilishga haqli ekanligim tushuntirildi.

                                   ________________ (F.I.Sh.)
                                        (imzo)
"""
    },

    "JR-E": {
        "harf": "e",
        "nomi": "Xabarnoma — muddati o'tganligi sababli jinoyat ishi qo'zg'atish rad etilganligi to'g'risida",
        "jpk": "JPK 84-modda 1-qism 1-band, 333-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. Muddati o'tganligi sababli rad etilganligi haqidagi "XABARNOMA" hujjatini yozasan.

QOIDALAR:
1. Bu xabarnoma — shaxs JK moddasi bilan jinoyat belgilari bo'lsa-da, muddati o'tganligi sababli rad etilgan holat uchun
2. Yuqorida: fuqaro manzili va F.I.Sh.
3. Mazmun:
   - [prokuratura] tomonidan [shaxs F.I.Sh.] ning [voqea] yuzasidan tergovga qadar tekshiruv o'tkazildi
   - Tekshiruv natijasiga ko'ra, harаkatlarida JKning [modda]-moddasi [qism]-qismida nazarda tutilgan jinoyat alomatlari mavjud bo'lsa-da, ushbu jinoyat uchun javobgarlikka tortish muddati o'tganligi sababli, [sana] yilda JPK 84-moddasining 1-qismi 1-bandiga asosan, ayblilик masalasiz hal qilinmasdan turib jinoyat ishi qo'zg'atish rad qilindi
   - JPK 333-modasiga asosan shikoyat huquqi, xabarnomani olgan kundan boshlab
4. Oxirida: sana va chiqish raqami (masalan: 20__ yil "__" ___ chiqish №15/____)
5. Hujjat matnini *** va *** orasiga ol
""",

        "maydonlar": [
            {"id": "qabul_manzil",      "label": "Kimga (fuqaro to'liq manzili)",                   "type": "textarea", "required": True},
            {"id": "qabul_fio",         "label": "Fuqaro F.I.Sh.",                                  "type": "text",     "required": True},
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi",                                "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "tekshirilgan_fio",  "label": "Tekshirilgan shaxs F.I.Sh. va voqea tavsifi",    "type": "textarea", "required": True},
            {"id": "jk_modda",          "label": "JK modda raqami",                                 "type": "text",     "required": True},
            {"id": "jk_qism",           "label": "JK modda qismi",                                  "type": "text",     "required": True},
            {"id": "rad_sanasi",        "label": "Rad etilgan sana",                                "type": "text",     "required": True},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror (masalan: Mirobod tuman)",        "type": "text",     "required": True},
            {"id": "chiqish_raqam",     "label": "Chiqish raqami (masalan: 15/___)",                "type": "text",     "required": False},
        ],

        "shablon": """\
                    {qabul_manzil}
                    {qabul_fio}ga


                        X A B A R N O M A

    {prokuratura_nomi} prokuraturasi tomonidan {tekshirilgan_fio}
yuzasidan tergovga qadar tekshiruv harakatlari o'tkazildi.
    O'tkazilgan tergovga qadar tekshiruv harakatlari natijasiga
ko'ra, harakatlaringizda O'zbekiston Respublikasi JKning
{jk_modda}-moddasi {jk_qism}-qismida nazarda tutilgan jinoyat
alomatlari mavjud bo'lsa-da, biroq ushbu jinoyat uchun
javobgarlikka tortish muddati o'tganligi sababli, {rad_sanasi}
yilda O'zbekiston Respublikasi JPKning 84-moddasi 1-qismi
1-bandiga asosan, ayblilиk masalangiz hal qilinmasdan jinoyat
ishi qo'zg'atish rad qilindi.
    Sizga, O'zbekiston Respublikasi JPKning 333-modasiga asosan,
qarordan norozi bo'lsangiz jinoyat ishini qo'zg'atishni rad
qilinganl to'g'risidagi qaror ustidan ushbu xabarnomani olgan
kundan boshlab {yuqori_prokuror} prokurorga shikoyat qilishga
haqli ekanligingizni tushuntiraman.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}

20__ yil "___" ___________
chiqish №{chiqish_raqam}
"""
    },

    "JR-F": {
        "harf": "f",
        "nomi": "Amnistiya aktiga asosan jinoyat ishi qo'zg'atishni rad etish haqida sudga iltimosnoma kiritishni so'rab takdimnoma kiritish to'g'risida qaror",
        "jpk": "JPK 84-modda 1-qism 2-band, 330-modda 2-bandi, 333, 587-588-moddalar",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Amnistiya aktiga asosan jinoyat ishi qo'zg'atishni rad etish haqida sudga iltimosnoma kiritishni so'rab takdimnoma kiritish to'g'risida QAROR" hujjatini yozasan.

QOIDALAR:
1. Bu eng murakkab rad turi — ayblilik masalasiz emas, amnistiya qo'llab rad etiladi
2. ANIQLADIM: shaxs haqida to'liq ma'lumot (tug'ilgan sana, manzil, millat, ma'lumot, oila, ish joyi), sodir etilgan jinoyat, amnistiya akti ma'lumotlari
3. QAROR QILDIM da 2 ta band:
   1) Tekshiruv materiallari bo'yicha [sana] yil [kun] kuni tug'ilgan, [to'liq anketa] [F.I.Sh.] ning ayblilиk masalasini hal qilmasdan turib, unga nisbatan [amnistiya akti sana va raqami] qarorning [N]-bandini qo'llab, mazkur qarorning [M]-bandiga asosan jinoyat ishini qo'zg'atishni rad qilish to'g'risida sudga iltimosnoma kiritishni so'rab [prokuratura] prokurorига takdimnoma kiritilsin.
   2) Mazkur qaror manfaatdor tomolarga ma'lum qilinsin.
4. Oxirida: e'lon qilinishi va fuqaro imzosi
5. Hujjat matnini *** va *** orasiga ol
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi",                                "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "sana_yil",          "label": "Yil",                                             "type": "text",     "required": True},
            {"id": "sana_kun_oy",       "label": "Kun va oy",                                       "type": "text",     "required": True},
            {"id": "hudud",             "label": "Hudud",                                           "type": "text",     "required": True},
            {"id": "tekshiruv_raqam",   "label": "Tekshiruv materiallari raqami (masalan: 15/1091)", "type": "text",   "required": False},
            {"id": "fuqaro_fio",        "label": "Fuqaro to'liq F.I.Sh.",                           "type": "text",     "required": True},
            {"id": "fuqaro_tugilgan",   "label": "Tug'ilgan sana va joyi",                          "type": "text",     "required": True},
            {"id": "fuqaro_manzil",     "label": "Yashash manzili",                                 "type": "text",     "required": True},
            {"id": "fuqaro_millat",     "label": "Millati",                                         "type": "text",     "required": False},
            {"id": "fuqaro_malumot",    "label": "Ma'lumoti",                                       "type": "text",     "required": False},
            {"id": "fuqaro_oila",       "label": "Oilaviy ahvoli",                                  "type": "text",     "required": False},
            {"id": "fuqaro_ish",        "label": "Ish joyi va lavozimi",                            "type": "text",     "required": False},
            {"id": "voqea_holati",      "label": "Voqea holati va jinoyat tavsifi batafsil",        "type": "textarea", "required": True},
            {"id": "jk_modda",          "label": "JK modda raqami",                                 "type": "text",     "required": True},
            {"id": "jk_qism",           "label": "JK modda qismi",                                  "type": "text",     "required": True},
            {"id": "amnistiya_sana",    "label": "Amnistiya akti sanasi va raqami",                 "type": "text",     "required": True},
            {"id": "amnistiya_band",    "label": "Amnistiya qarorining nechi-bandi qo'llanadi",     "type": "text",     "required": True},
            {"id": "qaror_band",        "label": "Amnistiya qarorining rad uchun nechi-bandi",      "type": "text",     "required": True},
            {"id": "yuqori_prokuror",   "label": "Takdimnoma yuboriluvchi prokuror",                "type": "text",     "required": True},
        ],

        "shablon": """\
  Amnistiya aktiga asosan jinoyat ishi qo'zg'atishni rad etish
  haqida sudga iltimosnoma kiritishni so'rab takdimnoma kiritish
                      to'g'risida
                        Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} to'plangan materiallar bilan tanishib, quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    O'zbekiston Respublikasi JKning {jk_modda}-moddasi {jk_qism}-qismida
nazarda tutilgan jinoyat, JKning 15-modasiga ko'ra ijtimoiy xavfi katta
bo'lmagan jinoyatlar turkumiga kirishligini hamda {fuqaro_fio} ning
unga nisbatan {amnistiya_sana} yildagi amnistiya aktini qo'llab, jinoyat
ishi qo'zg'atishni rad kilib, jinoiy javobgarlikdan ozod qilishni so'rab
bergan arizasi shuningdek, unga nisbatan mazkur amnistiya aktini
qo'llashga monеlik qiluvchi holatlar mavjud emasligini inobatga olib,
{fuqaro_fio} ning ayblilik masalasini hal qilmasdan turib, jinoyat ishi
qo'zg'atishni rad kilib, {amnistiya_sana} yildagi amnistiya aktiga asosan
jinoiy javobgarlikdan ozod qilish to'g'risida {yuqori_prokuror}
prokurorига takdimnoma kiritish lozim.
    Yuqoridagilarga ko'ra hamda JPKning 84-moddasi 1-qismi 2-bandi,
330-moddasi 2-bandi, 333-moddasi va 587-588-moddalarini qo'llab,

                  Q A R O R   Q I L D I M:

    1. {tekshiruv_raqam}-sonli tergovga qadar tekshiruv materiallari
bo'yicha {fuqaro_tugilgan} yilda tug'ilgan, {fuqaro_manzil} da
yashоvchi, millati {fuqaro_millat}, {fuqaro_malumot} ma'lumotli,
{fuqaro_oila}, {fuqaro_ish} {fuqaro_fio} ning ayblilиk masalasini
hal qilmasdan turib, unga nisbatan {amnistiya_sana} yildagi amnistiya
to'g'risidagi qarorning {amnistiya_band}-bandini qo'llab, mazkur
qarorning {qaror_band}-bandiga asosan jinoyat ishini qo'zg'atishni
rad qilish to'g'risida sudga iltimosnoma kiritishni so'rab
{yuqori_prokuror} prokuroriga takdimnoma kiritilsin.

    2. Mazkur qaror manfaatdor tomolarga ma'lum qilinsin.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}

──────────────────────────────────────────────────────────────
    Ushbu qaror menga 20__ yil "___" ___________ kuni e'lon
qilindi. Uning mazmuni va mohiyati tushuntirildi.

Fuqaro:              ________________ {fuqaro_fio}
                          (imzo)
"""
    },
    "JR-G": {
        "harf": "g",
        "nomi": "Jinoyat ishini qo'zg'atishni rad qilish haqida qaror (JPK 84-modda, ayblillik masalasiz)",
        "jpk": "JPK 36, 84-modda 1-qism, 330-modda 2-bandi, 333-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. "Jinoyat ishini qo'zg'atishni rad qilish haqida QAROR" yozasan.
Bu qaror JPK 84-modda 1-qismining turli bandlari asosida — ayblillik masalasini hal qilmasdan turib.

JPK 84-MODDA 1-QISM BANDLARI:
- 3-band: ayblanuvchi/sudlanuvchi vafot etgan (yaqin qarindoshlari rozi bo'lsa bundan mustasno)
- 4-band: shaxsga nisbatan aynan shu ayblov bo'yicha sudning qonuniy kuchga kirgan hukmi bor
- 6-band: ish faqat jabrlanuvchining shikoyati bilan qo'zg'atiladigan holatlarda uning shikoyati yo'q
- 8-band: boshqa maxsus holat

QOIDALAR:
1. ANIQLADIM: voqea batafsil, tekshiruv natijalari, rad sababi
2. JPK 36, 84-modda 1-qismi __-bandi, 330-modda 2-bandi, 333-modda
3. QAROR QILDIM da 3 ta band:
   1) [tekshiruv raqami] bo'yicha [shaxs to'liq ma'lumotlari] ning [holat] munosabati bilan JPK 84-moddasi 1-qismi __-bandiga asosan jinoyat ishi qo'zg'atish rad etilsin
   2) Rad qilinganligi va asoslari to'g'risida manfaatdor tomolarga ma'lum qilinib, shikoyat huquqi tushuntirilsin
   3) Qaror nusxasi prokurorga yuborilsin
4. Oxirida fuqaro imzosi
5. Hujjat matnini *** va *** orasiga ol
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi",                                "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "sana_yil",          "label": "Yil",                                             "type": "text",     "required": True},
            {"id": "sana_kun_oy",       "label": "Kun va oy",                                       "type": "text",     "required": True},
            {"id": "hudud",             "label": "Hudud",                                           "type": "text",     "required": True},
            {"id": "tekshiruv_raqam",   "label": "Tekshiruv materiallari raqami (masalan: 15/1234)","type": "text",     "required": False},
            {"id": "shaxs_fio",         "label": "Tekshirilgan shaxs to'liq F.I.Sh.",               "type": "text",     "required": True},
            {"id": "shaxs_tugilgan",    "label": "Tug'ilgan sanasi va joyi",                        "type": "text",     "required": True},
            {"id": "shaxs_manzil",      "label": "Yashash manzili",                                 "type": "text",     "required": True},
            {"id": "shaxs_lavozim",     "label": "Ish joyi va lavozimi",                            "type": "text",     "required": False},
            {"id": "voqea_holati",      "label": "Voqea holati batafsil",                           "type": "textarea", "required": True},
            {"id": "jk_modda",          "label": "JK modda raqami (tekshiruv o'tkazilgan)",          "type": "text",     "required": True},
            {"id": "jk_qism",           "label": "JK modda qismi",                                  "type": "text",     "required": True},
            {"id": "jpk_84_band",       "label": "JPK 84-modda 1-qism nechi-bandi (3, 4, 6, 8...)", "type": "text",     "required": True},
            {"id": "rad_sababi",        "label": "Rad sababi (masalan: vafot etganligi, sud hukmi mavjud, shikoyat yo'q)", "type": "text", "required": True},
            {"id": "xabardor_fio",      "label": "Kimga ma'lum qilinsin (fuqaro F.I.Sh.)",          "type": "text",     "required": True},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror (masalan: Mirobod tuman)",        "type": "text",     "required": True},
        ],

        "shablon": """\
     Jinoyat ishini qo'zg'atishni rad qilish haqida
                       Q A R O R

_____ yil _____________                                    _______________
           (kun, oy)                                            (hudud)

    {prokuratura_nomi} prokuraturasi {tergovchi_lavozim}i, {tergovchi_unvon}
{tergovchi_fio} {tekshiruv_raqam}-sonli materiallar bilan tanishib,
quyidagilarni

                      A N I Q L A D I M:

{voqea_holati}

    Binobarin, O'zbekiston Respublikasi JPKning 36, 84-moddasi
1-qismi {jpk_84_band}-bandi, 330-moddasi 2-bandi va 333-moddасини
qo'llab,

                  Q A R O R   Q I L D I M:

    1. {tekshiruv_raqam}-sonli tergovga qadar tekshiruv materiallari
yuzasidan {shaxs_tugilgan} yilda tug'ilgan, {shaxs_manzil} da
yashоvchi, {shaxs_lavozim} {shaxs_fio} ning {rad_sababi}
munosabati bilan JPK 84-moddasi 1-qismi {jpk_84_band}-bandiga
asosan jinoyat ishi qo'zg'atish rad etilsin.

    2. Jinoyat ishini qo'zg'atishning rad qilinganl va rad qilish
asoslari to'g'risida manfaatdor tomolarga ma'lum qilinib, ularga
ushbu qaror yuzasidan {yuqori_prokuror} prokurorga shikoyat qilishga
haqli ekanligi tushuntirilsin.

    3. Qarorning nusxasi {yuqori_prokuror} prokurorga yuborilsin.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}

──────────────────────────────────────────────────────────────
    Ushbu qaror menga 20__ yil "___" ___________ kuni e'lon
qilindi. Uning mazmuni va mohiyati tushuntirildi.

Fuqaro:              ________________ {xabardor_fio}
                          (imzo)
"""
    },

    "JR-H": {
        "harf": "h",
        "nomi": "Xabarnoma — JPK 84-modda asosida ayblillik masalasiz jinoyat ishi qo'zg'atish rad etilganligi to'g'risida",
        "jpk": "JPK 84-modda 1-qism, 333-modda",

        "ai_prompt": """
Sen tajribali yurist yordamchisan. JPK 84-modda asosida rad etilganligi haqidagi "XABARNOMA" yozasan.

QOIDALAR:
1. Yuqorida: qaerga (prokuratura) va kimga (fuqaro F.I.Sh.)
2. Mazmun:
   - [holat/hodisa/xabar] bo'yicha tekshiruv tamomlanidi
   - Mazkur [holat] bo'yicha [kimning] sodir etgan qilmishida JKning [modda]-moddasi [qism]-qismi "[band]" bandida nazarda tutilgan jinoyat belgilari mavjud bo'lsada, [rad sabablari]
   - [sana] da JPK 84-moddasi 1-qismi "[band]" bandida nazarda tutilgan holat aniqlanganligi sababli, uni ayblillik masalasi hal qilinmasdan jinoyat ishi qo'zg'atish rad qilindi
   - (Agar boshqa choralarga yuborilgan bo'lsa ko'rsatish)
   - JPK 333-modasiga asosan shikoyat huquqi — xabarnomani olgan vaqtdan boshlab
3. Hujjat matnini *** va *** orasiga ol
""",

        "maydonlar": [
            {"id": "prokuratura_nomi",  "label": "Prokuratura nomi",                                "type": "text",     "required": True},
            {"id": "tergovchi_lavozim", "label": "Tergovchi lavozimi",                              "type": "text",     "required": True},
            {"id": "tergovchi_unvon",   "label": "Tergovchi unvoni",                                "type": "text",     "required": True},
            {"id": "tergovchi_fio",     "label": "Tergovchi F.I.Sh.",                               "type": "text",     "required": True},
            {"id": "qabul_fio",         "label": "Kimga yuborilmoqda (fuqaro F.I.Sh.)",             "type": "text",     "required": True},
            {"id": "voqea_tavsifi",     "label": "Qanday hodisa/holat/xabar bo'yicha tekshiruv",   "type": "text",     "required": True},
            {"id": "tekshirilgan_fio",  "label": "Kimning harakati tekshirildi (F.I.Sh.)",          "type": "text",     "required": True},
            {"id": "jk_modda",          "label": "JK modda raqami",                                 "type": "text",     "required": True},
            {"id": "jk_qism",           "label": "JK modda qismi",                                  "type": "text",     "required": True},
            {"id": "jk_band",           "label": "JK modda bandi",                                  "type": "text",     "required": False},
            {"id": "rad_sababi",        "label": "Rad sababi (masalan: shikoyat arizasi berishdan bosh tortganligi)", "type": "textarea", "required": True},
            {"id": "rad_sanasi",        "label": "Rad etilgan sana",                                "type": "text",     "required": True},
            {"id": "jpk_84_band",       "label": "JPK 84-modda 1-qism nechi-bandi",                 "type": "text",     "required": True},
            {"id": "boshqa_chora",      "label": "Boshqa choralarga yuborilganmi (agar bo'lsa)",    "type": "text",     "required": False},
            {"id": "yuqori_prokuror",   "label": "Yuqori prokuror",                                 "type": "text",     "required": True},
        ],

        "shablon": """\
                    {prokuratura_nomi} prokuraturasiga
                    {qabul_fio}ga


                        X A B A R N O M A

    {voqea_tavsifi} bo'yicha tekshiruv tamomlanidi.
    Mazkur holat bo'yicha {tekshirilgan_fio} sodir etgan qilmishida
O'zbekiston Respublikasi JKning {jk_modda}-moddasi {jk_qism}-qismi
"{jk_band}" bandida nazarda tutilgan jinoyat belgilari mavjud bo'lsada,
{rad_sababi}
    {rad_sanasi} da O'zbekiston Respublikasi JPKning 84-moddasi
1-qismi "{jpk_84_band}" bandida nazarda tutilgan holat aniqlanganligi
sababli, uni ayblillik masalasi hal qilinmasdan jinoyat ishi qo'zg'atish
rad qilindi.
    {boshqa_chora}
    Sizga O'zbekiston Respublikasi JPKning 333-modasiga asosan,
mazkur qarordan norozi bo'lsangiz, jinoyat ishini qo'zg'atishni rad
qilinganligi to'g'risidagi qaror yuzasidan, ushbu xabarnomani olgan
vaqtdan boshlab {yuqori_prokuror} prokurorga shikoyat qilishga haqli
ekanligingizni ma'lum qilaman.

{prokuratura_nomi} prokuraturasi
{tergovchi_lavozim}i
{tergovchi_unvon}               (imzo)          {tergovchi_fio}
"""
    },
}
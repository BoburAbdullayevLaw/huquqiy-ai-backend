# documents/organ/__init__.py
"""
Organ hodimlar uchun protsessual hujjatlar
"""

import importlib
import os

ORGAN_HUJJATLARI = {}

# Barcha .py fayllarni import qilish
for file in os.listdir(os.path.dirname(__file__)):
    if file.endswith('.py') and not file.startswith('__'):
        module_name = file[:-3]  # .py olib tashlash
        try:
            module = importlib.import_module(f'.{module_name}', package=__name__)
            if hasattr(module, 'HUJJATLAR'):
                ORGAN_HUJJATLARI.update(module.HUJJATLAR)
                print(f"  👮 {module_name}.py: {len(module.HUJJATLAR)} ta hujjat")
        except Exception as e:
            print(f"  ⚠️ {module_name}.py yuklanmadi: {e}")

print(f"\n  👮 Organ jami: {len(ORGAN_HUJJATLARI)} ta hujjat")